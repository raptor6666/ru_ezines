################################  CONFIG PART  ##################################
$accesslog = "/var/log/httpd/access.log";
$errorlog = "/var/log/httpd/error.log";

$wwwdir = "/var/www/html/";
$cgidir = "/var/www/cgi-bin/";

$checkfile = "index.html";  # check this file, is it changed (defaced)? 

$bakupdir = "/var/backup/"; # here situated backup of site (for backup)
$movecgidir = "/tmp/cgi/";  # if site will be hacked, $cgidir wlll moved here 

$interval = 10; # check every X secs
$maskname = "hacker"; # ids's process name

$mailprog = "mail";
$mailto = "root"; # on alert mailto

@alert=("information","warining","SECURITY HOLE!");

$fingerquery = 1;  # query finger info on attack 

$backuplogs = 1;  # security first!
$accessbak = "/tmp/.xald"; 
$errorbak = "/tmp/.xalz";

#################################################################################

# "bad" requests

@keywordz=(
"echo ",
"ls ",
"uname ",
"|",
"../",               
"%00"
);

# deface text keywordz 

@defaced=(
"hacked",
"owned",
"defaced"
);