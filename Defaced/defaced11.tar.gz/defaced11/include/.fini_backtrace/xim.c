/* priv8 defaced staff ware 4.  esp 2 defaced 11 issue

   Linux/x86
    ������� ������ �� ��������, � ������ ������� ������ ������ _fini
*/
#include <stdio.h>
#include <fcntl.h>
#include <elf.h>

unsigned char sig1[] = "\x83\xec\x04";
unsigned char sig2[] = "\x5a\x5b\x5d\xc3";

#define SKIP2   0x10
#define BACK2   0x07


int check_offs(int fd)
{
    unsigned char a;

    lseek(fd, SKIP2, 1);

    read(fd, &a, 1);
    if (a != sig2[0]) return 0;
    
    read(fd, &a, 1);
    if (a != sig2[1]) return 0;
    
    read(fd, &a, 1);
    if (a != sig2[2]) return 0;
    
    return 1;
}


int main(int argc, char *argv[])
{
    int i,fd;
    unsigned int offs;
    unsigned char a;

    if (argc < 2)
    {
        printf("usage: %s <file>\n", argv[0]);
        return 0;
    }
    
    if (argc > 2)
    {
        sscanf(argv[2],"%x", &offs);
        offs -= 0x08048000;
        printf("theory addr = 0x%x\n", offs);
    }
    
    fd = open(argv[1], O_RDONLY);
    
    if (fd < 0)
    {
        perror("open");
        return 0;
    }
    
    i = offs = 0;
    
    while( read(fd, &a, 1) == 1)
    {
        offs++;

        if (a == sig1[i]) i++;
        else i = 0;

        if (i == 3)
        {
            if (check_offs(fd)) break;
            offs += 17;
            i = 0;
        }
    }

    offs -= BACK2;

    if (i != 3)
        printf("<_fini> not found\n");
    else
        printf("offset <_fini>: 0x%x\n", offs);

    close(fd);
    return 0;
}
