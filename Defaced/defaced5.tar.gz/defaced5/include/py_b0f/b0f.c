/* b0f.c */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
char buffah[500];

  if (argc > 1){
        strcpy(buffah, argv[1]);
        return 0;
  }

}
