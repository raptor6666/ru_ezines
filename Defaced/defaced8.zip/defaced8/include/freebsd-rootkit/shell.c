#include <stdio.h>

int main()
{
  unsigned short pid;
  char *argz[] = {"sh", 0};

  pid = fork();
  
  if (pid > 0)
  {
    printf("got pid %i\n", pid);
    waitpid(pid, 0, 0);
    return 0;
  }
  
  setgid(0x21);
  execve("/bin/sh", &argz, 0);
  return 0;
}