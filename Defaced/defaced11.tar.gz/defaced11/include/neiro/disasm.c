#include <stdio.h>
#include <fcntl.h>

#define LOG_FILE    "_disasm.log"

struct x86_tbl_rec
{
    unsigned char op;
    unsigned char op2;
    unsigned char op3;
    unsigned int len:4;
};

#include "disasm.h"

int main(int argc, char *argv[])
{
    FILE *log;
    int i, fd;
    unsigned short lib=0, ind[6];
    unsigned int disp, addr, offs;
    unsigned char a,b;

    if (argc <3)
    {
	printf("usage: %s <file> <offset> [<is_lib>]\n", argv[0]);
	return 0;
    }

    if (argc > 3)
	lib++;
    
    fd = open(argv[1], O_RDONLY);

    log = fopen(LOG_FILE, "w");

    sscanf(argv[2], "%x", &addr);
    
    if (lib)    
	lseek(fd, addr, 0);
    else
	lseek(fd, addr - 0x08048000, 0);

    offs = 0;
    memset(&ind, 0, 2*6);

    while( read(fd, &a, 1) == 1)
    {
	if (a == 0)
	{
	    read(fd, &b, 1);
	    if (b == 0) break; 
	    lseek(fd, -1, 1);
	}
	
	for (i=0; i < sizeof(opcode_lst)/sizeof(struct x86_tbl_rec); i++)
	{
	    if (opcode_lst[i].op != a) continue;

	    if (opcode_lst[i].op2 != 0)
	    {
		read(fd, &b, 1);
		lseek(fd, -1, 1);

		if (opcode_lst[i].op2 != b) continue;
	    }

	    if (opcode_lst[i].op2 != 0 && opcode_lst[i].op3 != 0)
	    {
		lseek(fd, 1, 1);
		read(fd, &b, 1);
		lseek(fd, -2, 1);

		if (opcode_lst[i].op3 != b) continue;
	    }

	    ind[0] = ind[1];
	    ind[1] = ind[2];
	    ind[2] = ind[3];
	    ind[3] = ind[4];
	    ind[4] = ind[5];
	    ind[5] = i;

	    lseek(fd, opcode_lst[i].len-1, 1);

	    fprintf(log, "%x  skip %i bytes (0x%x, 0x%x, 0x%x)\n",
		offs+addr, opcode_lst[i].len, opcode_lst[i].op, 
		opcode_lst[i].op2, opcode_lst[i].op3);
	    fflush(log);
	    
	    offs += opcode_lst[i].len-1;
	    if (opcode_lst[i].op == 0 && opcode_lst[i].len == 0)
    		exit(0);
		
	    break;
	}

	if (i == sizeof(opcode_lst)/sizeof(struct x86_tbl_rec))
	    break;
	
	offs++;
    }

    printf("%x\n", addr+offs);
    printf("%x\n", a);
    printf("0x%x:%i\n", opcode_lst[ind[0]].op, opcode_lst[ind[0]].len);
    printf("0x%x:%i\n", opcode_lst[ind[1]].op, opcode_lst[ind[1]].len);
    printf("0x%x:%i\n", opcode_lst[ind[2]].op, opcode_lst[ind[2]].len);
    printf("0x%x:%i\n", opcode_lst[ind[3]].op, opcode_lst[ind[3]].len);
    printf("0x%x:%i\n", opcode_lst[ind[4]].op, opcode_lst[ind[4]].len);
    printf("0x%x:%i\n", opcode_lst[ind[5]].op, opcode_lst[ind[5]].len);

    close(log);
    close(fd);
    return 0;
}
