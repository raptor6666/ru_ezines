#include <stdio.h>
#include <fcntl.h>

unsigned char sig[] = "\x8b\x80";

int main()
{
    int i, st, fd, gid;
    unsigned char p;

    fd = open("/dev/kmem", O_RDONLY);        

    lseek(fd, _OFFSET, 0);
    
    st = 0;
    for (i=0; i < 20; i++)
    {
	read(fd, &p, 1);
	if (p == 0xc3) break;
	
	if (p == sig[st]) st++;
	else st = 0;
	
	if (st == 2) break;
    }

    if (st < 2) return 0;

    read(fd, &gid, 4);
    printf("Gid offset: 0x%x\n", gid);

    close(fd);
    return 0;
}


