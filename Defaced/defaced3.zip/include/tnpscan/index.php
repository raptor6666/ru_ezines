<html>
<head>
<title>[tN] backend</title>
<meta http-equiv="??????????-???" content="text/html; charset=windows-1251">
<link rel="stylesheet" href="styles.css" type="text/css">
</head>



<body bgColor=black leftMargin=0 topMargin=0 marginheight="0" marginwidth="0" TEXT="#999999">
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr> 
    <td valign="top"> 
      <div align="center">
        <table width="100%" border="0">
          <tr bgcolor="#666666"> 
            <td><div align="center"><strong>port sc4nner</strong></div></td>
          </tr>
          <tr> 
            <td width="33%" height="82"> <div align="center"> 
                <form action="pscan.php" method="post" name="form3" target="_blank">
                  <div align="center"> 
                    <input name="hostname" type="text" id="hostname">
                    <br>
                    <br>
                    <br>
                    <input type="submit" name="Submit3" value="!sc4n n0w!">
                  </div>
                </form>
              </div></td>
          </tr>
        </table>
      </div></td>
    <td></td>
    <td></td>
  </tr>
  <tr> 
    <td height="14"> <div align="right"><b class="smallgreen">[ <a href="http://nteam.ru/" class="wlink">http://nteam.ru/</a> 
        ] 2003 (c) [tN]</b></div></td>
    <td height="14">&nbsp;</td>
    <td height="14">&nbsp;</td>
  </tr>
</table>
</body>
</html>