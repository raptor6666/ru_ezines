#include <stdio.h>
#include <fcntl.h>

int main(int argc, char *argv[])
{
    int fd, addr=0;
    unsigned char buf[512];

    sscanf(argv[1], "%x", &addr);

    fd = open("/dev/kmem", O_RDWR);
    lseek(fd, addr, 0);
    
    memset(&buf, 0x43, 64);
    buf[63] = 0;
//    write(fd, &buf, 64);    
        
    lseek(fd, addr, 0);
    memset(&buf, 0, 512);
    read(fd, &buf, 64);
    printf("%s\n", buf);

    close(fd);    
    return 0;
}

