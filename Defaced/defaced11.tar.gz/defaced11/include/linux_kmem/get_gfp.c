#include <stdio.h>
#include <fcntl.h>

int main()
{
    int i, fd, gfp;
    unsigned char p;
    
    fd = open("/dev/kmem", O_RDONLY);
     
    lseek(fd, _OFFSET, 0);
    for (i=0; i < 20; i++)
    {
        read(fd, &p, 1);
	
	if (p == 0x68) break;	
    }
     
    if (i == 20) return 0; // not found
    read(fd, &gfp, 4);
    printf("GFP_KERNEL = 0x%x\n", gfp);
    
    close(fd);
    return 0;
}

