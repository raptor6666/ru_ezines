#include <stdio.h>

int main()
{
    char *p;
    
    p = malloc(15);
    printf("works\n");
    free(p);
    return 0;
}
