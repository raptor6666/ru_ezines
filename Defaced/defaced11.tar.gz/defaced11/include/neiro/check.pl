#!/usr/bin/perl

@phile = `cat file`;
chomp @phile;

if ($#phile < 1)
{
    print "BLYA\n";
    exit;
}

$IS_LIB = $phile[1];
$PROG = $phile[0];

@argz = `cat status`;
chomp @argz;

($ch[1], $len[1]) = split(/:/, $argz[7]);
($ch[2], $len[2]) = split(/:/, $argz[6]);
($ch[3], $len[3]) = split(/:/, $argz[5]);
($ch[4], $len[4]) = split(/:/, $argz[4]);
($ch[5], $len[5]) = split(/:/, $argz[3]);
($ch[6], $len[6]) = split(/:/, $argz[2]);

if ($IS_LIB)
{
    $addr = hex($argz[0]);
} else {
    $addr = hex($argz[0]);
}

if ($argz[7] eq "0xc3:1" && $argz[1] eq "0")
{
    print "Done\n";
    `echo DONE > complete`;
    exit; 
}

$i = 0;
while ($i < 7)
{
    $adrs = sprintf("%x", $addr);
    print "try $adrs\n";
    $tst = `objdump -d $PROG | grep $adrs:`;
    print "$tst\n";
    chomp $tst;

    if (length($tst) > 2)
    { $i = 12; }

    $i++;
    if ($i < 7)
    {
	$addr -= $len[$i]; 
	print "minus $len[$i]\n";
    }
}

printf("i=%i  addr = 0x%x\n", $i, $addr);

$ls=`objdump -d $PROG | grep $adrs:`;
chomp $ls;

@test = split(/\t/, $ls);
$ls = $test[1];

$ops = "";
$ls =~ s/([a-f0-9][a-f0-9])\s/ $ops .= "$1 " /ge;
@op_r = split(/ /, $ops);

$op_r[0] = "0x$op_r[0]";

$lena = $#op_r + 1;

if ($lena > 1)
{
    if ($lena > 2)
    {
	if ($op_r[2] eq "00")
	{
	    $op_r[2] = 0;
        } else {
    	    $op_r[2] = "0x$op_r[2]";
	}
    }

    if ($op_r[1] eq "00")
    {
        $op_r[1] = 0;
    } else {
	$op_r[1] = "0x$op_r[1]";
    }
}

$lena = $#op_r+1;

if ($lena == 7)
{
    print "EXTRA LEN CHECK\n";
    
    $xtr = `objdump -d $PROG | grep -1 $adrs: | tail -1`;
    chomp $xtr;
    ($a1, $a2) = split(/:/, $xtr);
    $xtr = $a2;
    
    ($b1, $b2, $b3) = split(/\t/, $xtr);
    $xtr = $b2;
    
#    $xtr =~ s/\s+/ /g;
    @xtra = split(/ /, $xtr);

#    print "len xtra = $#xtra; len xtra2 = $#xtra2\n";

#    if ($#xtra == $#xtra2 + 2)
    if ($b3 eq "")
    {
	print "found long isnt $xtr\n";
	$lena += $#xtra+1;
    }
}

print "len = $lena\n";

if ($i == 13)  # true unknown op
{
    add_op();
    exit;
}

#

@data = `cat disasm.txt`;
chomp @data;

if ($lena > $len[$i])
{
    open(FD,">disasm.h");

    foreach $rec (@data)
    {
	if ($rec =~ m/{0x$op_r[0], 0/)
	{
	    print FD "{0x$op_r[0], 0x$op_r[1], 0, $lena},\n";
	} elsif ($rec =~ m/0, $len[$i]}/)
	{
	    print FD "{0x$op_r[0], 0x$op_r[1], 0, $lena},\n";
	} else {
	    print FD "{0x$op_r[0], 0x$op_r[1], 0x$op_r[2], $lena},\n";
	}

	print FD "$rec\n";
    }

    close(FD);
}

if ($lena < $len[$i])
{
    print "change len for op $op_r[0] from $len[$i] to $lena\n";
    open(FD,">disasm.h");

    foreach $rec (@data)
    {
	if ($rec !~ m/^{0x$op_r[0]/ || $rec !~ m/$len[$i]}/)
	    { print FD "$rec\n"; next; }

	if ($lena < 6)
	{
	    print FD "{0x$op_r[0], 0, 0, $lena},\n";
	} else {
	    print FD "{0x$op_r[0], 0x$op_r[1], 0, $lena},\n";
	}
    }
    close(FD);
}

if ($lena == $len[$i])
{ exec("echo DONE > complete"); }

exit;

sub add_op()
{
    @data = `cat disasm.txt`;
    chomp @data;

    print "new = {$op_r[0], $op_r[1], $op_r[2], $lena},\n";
    
    open(FD, ">disasm.txt");

    # write all other lines
    $i = 0;
    foreach $line (@data)
    {
	if ($line !~ m/{$op_r[0]/)
	{ 
	    print FD "$line\n"; 
	} else {
	    $dat2[$i] = $line;
	    $i++;
	}
    }

    if ($i == 0)
    {
	new_add();
	close(FD);	
	exit;
    }

    print "new array len = $i (0x, 0x, 0x)\n";
    
    $i = 0;    
    # {0xa, 0xb, 0xc}    
    foreach $line (@dat2)
    {
	if ($lena < 3 || $line !~ m/{$op_r[0], $op_r[1], $op_r[2], /)
	{ 
	    if ($line !~ m/, 0,/)
	    { 
		print FD "$line\n"; 
	    } else {
		$dat3[$i] = $line;
		$i++;	
	    }
	    
	    next; 
	}
	
	if ($line =~ m/, $lena}/)
	{ 
	    print FD "$line\n";
	    last;
	} else {
	    print "ERROR - two eq rec with diff lens $line vs ($lena)\n";
	    $c = `echo ASS > complete`;
	    exit;
	}
    }    

    if ($i == 0)
    {
	new_add();
	close(FD);
	exit;
    }

    print "new array len = $i (0x, 0x, 0)\n";
    $i = 0;

    # {0xa, 0xb, 0}    
    foreach $line (@dat3)
    {
	if ($lena < 2 || $line !~ m/{$op_r[0], $op_r[1], 0, /)
	{
	    if ($line !~ m/, 0, 0/)
	    {
		print FD "$line\n";
	    } else {
		$dat4[$i] = $line;
		$i++;
	    }
	    
	    next;
	}	

	$nlen = get_len($line);

	if ($nlen == $lena)
	{
	    print "line $line\n";
	    print "EQUAL\n";
	    print FD "$line\n";
	    close(FD);
	    exit;	    
	} 
	
	if ($lena > $nlen)
	{
	    print FD "{$op_r[0], $op_r[1], $op_r[2], $lena},\n";
	    print FD "$line\n";
	} else {
	    print FD "{$op_r[0], $op_r[1], 0, $lena},\n";
	}
	last;
    }

    if ($i == 0)
    {
	new_add();
	close(FD);
	exit;
    }

    print "new array len = $i (0x, 0, 0)\n";

    if ($i > 1)
    {
	print @dat4;
	close(FD);
	$c = `echo $i > complete`;
	exit;
    }

    # $i should be == 1

    $nlen = get_len($dat4[0]);
    print "nlen=$nlen lena=$lena\n";
    
    if ($lena > $nlen)
    {
	print FD "{$op_r[0], $op_r[1], 0, $lena},\n";
	print FD "$dat4[0]\n";
    } else {
	print FD "{$op_r[0], 0, 0, $lena},\n";
    }

    close(FD);
    return 0;
}


sub get_len()
{
    $t = shift @_;
    ($a,$b,$c,$d) = split(/,/, $t);
    
    $d =~ s/ //;
    $d =~ s/[{,}]//;
    
    return $d;
}


sub new_add()
{
    if ($lena > 6)
    {
	print FD "{$op_r[0], $op_r[1], $op_r[2], $lena},\n";
    }

    if ($lena > 4 && $lena < 7)
    {
	print FD "{$op_r[0], $op_r[1], 0, $lena},\n";
    } 
    
    if ($lena < 5)
    {
	if ($op_r[0] ne "0x00")
	{
	    print FD "{$op_r[0], 0, 0, $lena},\n";
	} else {
	    print FD "{$op_r[0], $op_r[1], 0, $lena},\n";
	}    
    }    

    return 0;
}
