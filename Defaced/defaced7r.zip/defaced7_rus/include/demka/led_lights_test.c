#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <linux/kd.h>

int main()
{
  int i, wtty;

  wtty = open("/dev/tty0", O_RDWR);

/*  step-by-step to the left 
  while(1){  
    usleep(800);
    ioctl(wtty, KDSETLED, LED_NUM);
    usleep(600);
    ioctl(wtty, KDSETLED, LED_CAP | LED_NUM);
    usleep(800);
    ioctl(wtty, KDSETLED, LED_CAP);
    usleep(600);
    ioctl(wtty, KDSETLED, LED_SCR | LED_CAP);
    usleep(800);
    ioctl(wtty, KDSETLED, LED_SCR);
    usleep(600);
    ioctl(wtty, KDSETLED, LED_SCR | LED_NUM);
  }
*/

/*  go to the left, go to the right
  while(1){  
    usleep(95000);
    ioctl(wtty, KDSETLED, LED_NUM);
    usleep(95000);
    ioctl(wtty, KDSETLED, LED_CAP);
    usleep(95000);
    ioctl(wtty, KDSETLED, LED_SCR);
  }
*/

/* dumb sequenser
  while(1){  
    ioctl(wtty, KDSETLED, 0);
    usleep(300000);
    ioctl(wtty, KDSETLED, LED_NUM);
    usleep(350000);
    ioctl(wtty, KDSETLED, LED_NUM | LED_CAP);
    usleep(200000);

    ioctl(wtty, KDSETLED, 0);
    usleep(300000);
    ioctl(wtty, KDSETLED, LED_NUM);
    usleep(350000);
    ioctl(wtty, KDSETLED, LED_NUM | LED_CAP);
    usleep(200000);

    ioctl(wtty, KDSETLED, 0);
    usleep(300000);
    ioctl(wtty, KDSETLED, LED_NUM);
    usleep(350000);
    ioctl(wtty, KDSETLED, LED_NUM | LED_CAP);
    usleep(200000);

    usleep(300000);
    ioctl(wtty, KDSETLED, LED_NUM);
    usleep(300000);
    ioctl(wtty, KDSETLED, LED_NUM | LED_CAP);
    usleep(215000);
    ioctl(wtty, KDSETLED, LED_NUM | LED_CAP | LED_SCR);
    usleep(500000);
    ioctl(wtty, KDSETLED, LED_NUM | LED_CAP);
    usleep(300000);
  }
*/  

  while(1){
    
    ioctl(wtty, KDSETLED, 0);
    usleep(300000);
    ioctl(wtty, KDSETLED, LED_NUM);
    usleep(20000);
    ioctl(wtty, KDSETLED, LED_NUM | LED_CAP);
    usleep(50000);    
    ioctl(wtty, KDSETLED, LED_NUM | LED_CAP | LED_SCR);
    usleep(300000);
    ioctl(wtty, KDSETLED, 0);
    usleep(250000);
    ioctl(wtty, KDSETLED, LED_NUM);
    usleep(25000);
    ioctl(wtty, KDSETLED, LED_NUM | LED_CAP);
    usleep(55000);    
    ioctl(wtty, KDSETLED, LED_NUM | LED_CAP | LED_SCR);
    usleep(200000);  
    ioctl(wtty, KDSETLED, 0);
    usleep(150000);
    ioctl(wtty, KDSETLED, LED_NUM);
    usleep(25000);
    ioctl(wtty, KDSETLED, LED_NUM | LED_CAP);
    usleep(55000);    
    ioctl(wtty, KDSETLED, LED_NUM | LED_CAP | LED_SCR);
    usleep(400000);
    
  }    

}

