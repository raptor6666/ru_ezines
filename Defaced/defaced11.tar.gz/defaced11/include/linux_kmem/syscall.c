#include <stdio.h>
#include <fcntl.h>

int main()
{
    int i, fd, addr;
    
    fd = open("/dev/kmem", O_RDWR);

    lseek(fd, _OFFS, 0);

    for (i=0; i < 16; i++)
    {
	read(fd, &addr, 4);
	printf("syscall %i : 0x%x\n", i, addr);
    }
    
    close(fd);
    return 0;
}

