// wipe.cpp : Defines the entry point for the console application.
//


#include <stdio.h>
#include <windows.h>

unsigned char scheme [7] =
{ 0x35, 0xCA, 0x97, 0x68, 0xAC, 0x53, 0x77 };

void FillFile (HANDLE hFile, DWORD dwLen, unsigned char Value) {
  DWORD Len;
  char  Buffer[4096];

  memset(Buffer,Value,sizeof(Buffer));
  SetFilePointer (hFile,0,NULL,FILE_BEGIN);

  while (dwLen > 0) {
    Len = (dwLen>sizeof(Buffer))?sizeof(Buffer):dwLen;
    WriteFile (hFile,Buffer,Len,&Len,NULL);
    dwLen -= Len;
  }

  FlushFileBuffers (hFile);
}

void WipeFile (char *name) {
  HANDLE hFile;
  DWORD  dwSize;
  int i;

  hFile = CreateFile (name,GENERIC_WRITE,0,NULL,OPEN_EXISTING,FILE_FLAG_SEQUENTIAL_SCAN,NULL);
  if (hFile == INVALID_HANDLE_VALUE) {
    return;
  }
  dwSize = GetFileSize (hFile,NULL);
  
  for (i=0;i<sizeof (scheme) / sizeof (scheme[0]); i++)
	  FillFile (hFile, dwSize, scheme[i]);

  SetFilePointer (hFile,0,NULL,FILE_BEGIN);
  SetEndOfFile (hFile);
  CloseHandle (hFile);
  DeleteFile (name);
}

int main(int argc, char* argv[])
{
	if (argc < 2){
		printf ("usage %s fileame\n", argv[0]);
		exit (0);
	}
	WipeFile (argv[1]);
	return 0;
}

