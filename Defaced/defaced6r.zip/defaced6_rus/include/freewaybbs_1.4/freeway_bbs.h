
/* term colors: */

#define NORM    "\033[1;00m"
#define GREY    "\033[1;30m"
#define RED     "\033[1;31m"
#define GREEN   "\033[1;32m"
#define YELLOW  "\033[1;33m"
#define BLUE    "\033[1;34m"
#define PURPLE  "\033[1;35m"
#define MILK    "\033[1;36m"
#define WHITE   "\033[1;37m"

/* some defz 4 logging */

#define write2log(x,y);    logfile = fopen(LOGFILE,"a"); \
                        fprintf(logfile,x,y); fclose(logfile); 

#define mesg2log(x,y,z);   logfile = fopen(LOGFILE,"a"); \
                        fprintf(logfile,x,y,z); fclose(logfile);

/***************** CHAT PROTOCOL DEFZ ******************/

// server-side cmdz

#define   SERV_MESG     0
#define   SERV_PING     1
#define   SERV_CON      2
#define   SERV_FUCK     3
#define   SERV_WHOZ     4
#define   SERV_DATA     5
#define   SERV_FILE     6

// client-side cmdz

#define   SERV_JOIN    16
#define   SERV_PART    17
#define   SERV_ERR     20
#define   SERV_OK      21
#define   SERV_BAK     22
#define   SERV_PRP     23

// SERV_ERR argz:

#define   UPLOAD_DENY   1
#define   UPLOAD_BUSY   2
#define   UPLOAD_FLER   3
#define   UPLOAD_DONE   4

/*******************************************************/

#ifdef _ICMP_ECHO

  // to use via ICMP_ECHO
struct phoenix_proto {

 char type[1];  // icmp_type
 char code[1];  // icmp_code
 short  chksum;
 char  src[1];  // source addr
 char  uid[1];  // user id
 char  cmd[1];  // command
 char  arg[1];  // argument

};

#endif

#ifdef _DNS
/*

  0         8        16             32
  +---------+---------+-------+--------+       UDP header
  i   cmd   i   arg   i    dst_port    i
  +---------+---------+----------------+
  i      length       i    check sum   i
  +-------------------+----------------+

  +---------+---------+----------------+       DNS header
  i   src   i   uid   i      zeroed    i
  +---------+---------+----------------+
  i      htons(1)     i      zeroed    i
  +-------------------+----------------+
  i     zeroed        i      zeroed    i
  +---------+---------+----------------+
  i datalen i our MAD DATA!! ......... i
  +---------+-----------------+--------+
  i ......................... i  zero  i
  +-------------------+-------+--------+
  i     htons(1)      i   htons(1)     i
  +-------------------+----------------+

*/

  // to use via DNS
struct phoenix_proto {

  char cmd[1];    // 0x00 udp_src
  char arg[1];    // 0x01 udp_src
  short dst_port; // 53
  short len;
  short chksum;
  char src[1];    // 0x00 dns_id
  char uid[1];    // 0x01 dns_id
  short junk;   // this flags must be 0 in requests
  short qd_cnt; // == 1
  short an_cnt; // == 0
  short ns_cnt; // == 0
  short ar_cnt; // == 0
  char datalen[1];  // datalen
};


struct pseudo_hdr {

  unsigned long src;
  unsigned long dst;
  char z[1];
  char proto[1];
  short len;    

};

#endif

/******************************************************/

unsigned int con, ping, uploader, phsize;
FILE *logfile;

/* Serv offsets:
    0x00    primary server address
    0x01    secondary server    
*/  

char serv[2]="\x00\x00";
char addr[4];             // local ppp-interface address
char gate[4];
char *packet;             // pointer to incoming ip-packet
char *text;               // pointer to chat message
struct phoenix_proto *ph; // pointer to phoenix-hdr
struct sockaddr_in  if1;
char buf[MAX_MESG_SIZE];
char f_buf[MAX_FILE_SEGMENT];

char file_2_send[256];
struct stat upl;
time_t fox;

/* defintion functions after main() */
void on_timeout();
void start_server();
void use_server();


ushort ma_chksum(u_short *addr, short len)
{
  register int sum = 0;
  unsigned short answer = 0;
  register unsigned short *w = addr;
  register int nleft = len;

  while (nleft > 1)
  {
     sum += *w++;
     nleft -= 2;
  }

  if (nleft == 1)
  {
     *(u_char *) (&answer) = *(u_char *) w;
     sum += answer;
  }

  sum = (sum >> 16) + (sum & 0xffff);
  sum += (sum >> 16);		
  answer = ~sum;		
  return (answer);
}


#ifdef _ICMP_ECHO
void net_send(void* str, unsigned int size)
{
  char *pack;
  struct phoenix_proto *ph0;

  pack = (char *)malloc(28+size);
  ph0 = (struct phoenix_proto *)(pack+20);

  memset(pack,0,28+size);  
  memcpy(pack+12,&addr,3);      // src_addr
  memset(pack+15,ph->src[0],1); // src_addr
  memcpy(pack+16,&gate,4); // dst_addr
  memset(pack,0x45,1);     // ihl + ver
  memset(pack+8,0xff,1);   // ttl
  memset(pack+9,0x01,1);   // icmp_proto
  memcpy(pack+28,str,size);
  ph0->type[0] = 8;
  ph0->src[0] = addr[3];
  ph0->uid[0] = ph->uid[0];
  
  if (ph->cmd[0] == SERV_WHOZ) ph0->cmd[0] = SERV_WHOZ;
  if (ph->cmd[0] == SERV_DATA) ph0->cmd[0] = SERV_DATA;

  ph0->arg[0] = ph->arg[0];
  ph0->chksum = ma_chksum((short *)(pack+20),size+8);

  if (sendto(con,pack,28+size,0,(struct sockaddr *)&if1,16) < 0){
    perror("fuck ");
    free(pack);
    exit(1);
  }

  free(pack);
  return;
}


void net_send_cmd()
{
  ushort i;
  char *pack;
  struct phoenix_proto *ph0;

  pack = (char *)malloc(28);
  ph0 = (struct phoenix_proto *)(pack+20);

  memset(pack,0,28);
  memcpy(pack+12,&addr,3);
  memset(pack+15,ph->src[0],1); // src_addr
  memcpy(pack+16,&gate,4);  // dst_addr
  memset(pack,0x45,1);      // ihl + ver
  memset(pack+8,0xff,1);    // ttl
  memset(pack+9,0x01,1);    // icmp_proto

  ph0->type[0] = 0x08;
  ph0->src[0] = addr[3];
  ph0->cmd[0] = ph->cmd[0];
  ph0->arg[0] = ph->arg[0];
  ph0->uid[0] = ph->uid[0];
  ph0->chksum = ma_chksum((ushort *)(pack+20),8);

  if (ping == 2){ // in the beginin'
  
    for (i = 1;i <= 255;i++){
      memset(pack+15,i,1);
      sendto(con, pack, 28, 0, (struct sockaddr *)&if1, 16);
      if (i == 70 || i == 135 || i == 200) sleep(1);
             // bypassing kernel flood protection >;PpPPppPP
    }


    free(pack);
    close(con);
    exit(1);
 
  } else {

    if (sendto(con, pack, 28,0,(struct sockaddr *)&if1,16) < 0){
      perror("fuck ");
      free(pack);
      exit(1);
    }
  }

  free(pack);
  return;
}
#endif


#ifdef _DNS
void net_send(void* str, unsigned int size)
{
  char *pack;
  struct phoenix_proto *ph0;
  struct pseudo_hdr *phdr;
  unsigned short t;

  pack = (char *)malloc(HDR_SIZE+size);
  ph0 = (struct phoenix_proto *)(pack+20);
  memset(pack,0,HDR_SIZE+size);

  memcpy(pack+12,&addr,3);      // src_addr
  memset(pack+15,ph->src[0],1); // src_addr
  memcpy(pack+16,&gate,4); // dst_addr
  memset(pack,0x45,1);     // ihl + ver
  memset(pack+8,0xff,1);   // ttl
  memset(pack+9,0x11,1);   // udp_proto
  memcpy(pack+HDR_SIZE-1,str,size);
  memset(pack+HDR_SIZE+size-1,1,1);
  memset(pack+HDR_SIZE+size+1,1,1);

  ph0->dst_port = htons(53);
  ph0->len = htons(HDR_SIZE+size);
  ph0->src[0] = addr[3];
  ph0->uid[0] = ph->uid[0];

  phdr = (struct pseudo_hdr *)malloc(size+HDR_SIZE-8);
  memcpy(phdr,pack+12,8);
  phdr->z[0] = 0;
  phdr->proto[0] = htons(17);
  phdr->len = htons(HDR_SIZE+size-20);
  if (ph->cmd[0] == SERV_WHOZ) ph0->cmd[0] = SERV_WHOZ;
  if (ph->cmd[0] == SERV_DATA) ph0->cmd[0] = SERV_DATA;

  ph0->arg[0] = ph->arg[0];
  ph0->qd_cnt = htons(1);
  t = size;
  t %= 256;
  ph0->datalen[0] = t;

  memcpy(phdr+12,pack+20, sizeof(phdr)-12);
  ph0->chksum = htons(ma_chksum((short *)phdr,HDR_SIZE+size-8));

  if (sendto(con,pack,sizeof(pack),0,(struct sockaddr *)&if1,16) < 0){
    perror("fuck ");
    free(phdr);
    free(pack);
    exit(1);
  }

  free(phdr);
  free(pack);
  return;
}



void net_send_cmd()
{
  char *pack;
  struct phoenix_proto *ph0;
  struct pseudo_hdr *phdr;
  ushort i;

  pack = (char *)malloc(HDR_SIZE+2);
  ph0 = (struct phoenix_proto *)(pack+20);
  memset(pack,0,HDR_SIZE+2);  

  memset(pack,0x45,1);     // ihl + ver
  memset(pack+8,0xff,1);   // ttl
  memset(pack+9,0x11,1);   // udp_proto
  memcpy(pack+12,&addr,3);      // src_addr
  memset(pack+15,ph->src[0],1); // src_addr
  memcpy(pack+16,&gate,4); // dst_addr
  memset(pack+37,0x63,2);  // domain ".cc"
  memset(pack+HDR_SIZE-1,1,1);
  memset(pack+HDR_SIZE-3,1,1);

  phdr = (struct pseudo_hdr *)malloc(HDR_SIZE-6);
  memcpy(phdr,pack+12,8);
  phdr->z[0] = 0;
  phdr->proto[0] = htons(17);
  phdr->len = htons(HDR_SIZE-18);

  ph0->dst_port = htons(53);
  ph0->len = HDR_SIZE+2;
  ph0->src[0] = addr[3];
  ph0->uid[0] = ph->uid[0];
  ph0->cmd[0] = ph->cmd[0];
  ph0->arg[0] = ph->arg[0];
  ph0->qd_cnt = htons(1);
  ph0->datalen[0] = 2;

  memcpy(phdr+12,pack+20,HDR_SIZE-10);

  if (ping == 2){ // in the beginin'
  
    for (i = 1;i <= 255;i++){
      memset(pack+15,i,1);
      memset(phdr+3,i,1);
      ph0->chksum = htons(ma_chksum((short *)phdr,HDR_SIZE-6));
      sendto(con, pack, HDR_SIZE+2, 0, (struct sockaddr *)&if1, 16);
      if (i == 70 || i == 135 || i == 200) sleep(1);
             // bypassing kernel flood protection >;PpPPppPP
    }
  } else ph0->chksum = htons(ma_chksum((short *)phdr,HDR_SIZE-6));

  if (sendto(con,pack,sizeof(pack),0,(struct sockaddr *)&if1,16) < 0){
    perror("fuck ");
    free(pack);
    free(phdr);
    exit(1);
  }

  free(phdr);
  free(pack);
  return;
}

#endif



uint init_sock()
{
  int sock, val = 1;

  if ((sock = socket(AF_INET,SOCK_RAW,PHOENIX_PROTO))<0){
    perror("fuck on socket() ");
    exit(1);
  }

  if (setsockopt(sock,IPPROTO_IP,IP_HDRINCL,(char *)&val,sizeof(val)) < 0){
    perror("fuck on setsockopt() ");
    exit(1);
  }

  return sock;
}



void check_cmd()
{
  unsigned short i,t;
  char *ptr,uladdr[4];

  if (strncmp(buf,"/quit",5) == 0){

    printf("%s<< Good-Bye! >>%s\n",YELLOW,NORM);
    time(&fox);
    write2log("Session closed: %s",ctime(&fox));
    fclose(logfile);
    
    if (serv[0] != 0 && serv[0] != addr[3]){
        ph->src[0] = serv[0];
        ph->cmd[0] = SERV_FUCK;
        ph->arg[0] = 0;
        ph->uid[0] = MYID;
        net_send_cmd();
    }
    
    close(con);
    exit(0);
  }

  if (strncmp(buf,"/serv",5) == 0){
    i = serv[0];
    i %= 256;
    printf("%sPrimary server:%s %i\n", GREY, WHITE, i);
    write2log("  Primary server: %i\n",i);
    i = serv[1];
    i %= 256;
    printf("%sSecondary server:%s %i\n", GREY,WHITE,i);
    write2log("  Secondary server: %i\n",i);

    return;
  }

  if (strncmp(buf,"/updt",5) == 0){
    printf("%sSending updated info...%s\n",YELLOW,WHITE);
    ph->src[0] = serv[0];
    ph->cmd[0] = SERV_CON;
    ph->arg[0] = 0;
    ph->uid[0] = MYID;
    net_send_cmd();

    return;
  }

  if (strncmp(buf,"/ping",5) == 0){

    if (serv[0] == 0){
      printf("%s You are server!%s\n",YELLOW,WHITE);
      return;
    }

    signal(SIGALRM, on_timeout);
    alarm(MAX_TIMEOUT);
    ph->cmd[0] = SERV_PING;
    ph->arg[0] = 0;
    ph->src[0] = serv[0];
    ph->uid[0] = MYID;
    net_send_cmd();
    printf("%sPING->%s\n",PURPLE,MILK);
    logfile = fopen(LOGFILE,"a");
    fprintf(logfile,"PING->\n");
    fclose(logfile);
    ping = 1;
    return;

  }


  if (strncmp(buf,"/whois",6) == 0){
  
    printf("%sGeting list of online users...%s\n",YELLOW,WHITE);

    if (serv[0] == 0 || serv[0] == addr[3]){

      for (i=1; i < USERS_CNT; i++){      

        printf("  %s  %i\n", usr_list[MYID].nick, addr[3]);
        if (usr_list[i].kaddr[0] != 0){
	         t = usr_list[i].kaddr[0];
	         t %= 256;
	         printf("  %s  %i\n",usr_list[i].nick, t);
	       }
	
      }

    } else {
      ph->uid[0] = MYID;
      ph->src[0] = serv[0];
      ph->cmd[0] = SERV_WHOZ;
      ph->arg[0] = 0;
      net_send_cmd();      
    }
    
    return;
  }


  if (strncmp(buf,"/help",5) == 0){

    printf("%s\t\t --=== %s FreeWAY BBS 1.4 %s ===-- \n",GREY,MILK,GREY);
    printf("\t%s ping  \t  %scheck connection status\n",WHITE,NORM);
    printf("\t%s serv\t  %sprint servers list\n",WHITE,NORM);
    printf("\t%s updt\t  %supdate address on server\n",WHITE,NORM);
    printf("\t%s send\t  %ssend file to any user\n",WHITE,NORM);
    printf("\t%s whois\t %s get list of online users\n",WHITE,NORM);
    printf("\t%s warn\t  %ssend important message\n",WHITE,NORM);
    printf("\t%s help  \t  %sthis cruft ((c) netcat )\n",WHITE,NORM);
    printf("\t%s quit  \t  %sgo to hell%s\n\n",WHITE,NORM,WHITE);
    return;

  }


  if (strncmp(buf,"/send",5) == 0){

    write(1,"user address (look 'whois'): ",29);
    t = read(0,&uladdr,4);

    if (t == 0 || t > 255){
      printf("bad addr\n");
      return;
    }

    ph->src[0] = atoi(&uladdr);

    write(1,"path to file: ",14);
    memset(&file_2_send,0,256);
    read(0,&file_2_send,256);
    file_2_send[strlen(file_2_send)-1] = 0;

    if (stat((char *)&file_2_send,(struct stat *)&upl) < 0){
      perror("fuck ");
      return;
    }

    if (upl.st_size > 1024*256){
      printf("file too big (more than 256 kb)!\n");
      memset(&upl,0,sizeof(upl));
      return;
    }

    printf("sending request...\n");

    uploader = 1;

    ph->uid[0] = MYID;
    ph->cmd[0] = SERV_FILE;
    ph->arg[0] = 0;
    net_send_cmd();
    return;
  }


  if (strncmp(buf,"/warn ",6) == 0){
    if ((strlen(buf) - 6) == 0) return;

    ptr = (char *)&buf;
    ph->uid[0] = MYID;
    ph->arg[0] = 0x0a;
    ph->src[0] = serv[0];

    if (serv[0] == addr[3] || serv[0] == 0){

      for (i=1; i < USERS_CNT; i++){
         if (i != MYID && usr_list[i].kaddr[0] != 0){
	          ph->src[0] = usr_list[i].kaddr[0];
	          net_send(ptr+6, strlen(buf) - 7);
         }
      }

    } else net_send(ptr+6, strlen(buf) - 7);

    return;
  }

  printf("%s Unknown cmd ! (try '\x2fhelp')%s\n",YELLOW,WHITE);
  return;
}

