//
//  main.cpp
//  mach-o infector
//
//  Created by Pest on 27.11.14.
//  Copyright (c) 2014 coru.ws. All rights reserved.
//


#ifndef __my__main__
#define __my__main__

#include <stdio.h>

#endif /* defined(__my__main__) */
