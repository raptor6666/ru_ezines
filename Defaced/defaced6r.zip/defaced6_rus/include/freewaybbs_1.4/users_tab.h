
// we keep all user infaz in memory - its faster!

struct users {

 unsigned char kaddr[1];  // user address in subnet
 char* nick;              // pointer to nickname

} usr_list[] = {

{ 0x00 , "test"},     //  0    test
{ 0x00 , "dumbass"},  //  1    dumbass
{ 0x00 , "nigg4"},    //  2    nigg4
{ 0x00 , "restam4n"}, //  3    restam4n
// etc
};

