#include <stdio.h>

int main()
{
    int i;
    i = syscall(219, 0);
    printf("ret %i 0x%x\n", i, i);
    return 0;
}
