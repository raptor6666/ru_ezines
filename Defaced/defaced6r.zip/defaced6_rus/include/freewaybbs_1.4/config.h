/*

  in some cases maybe you need to change timeouts (i.e. if gate sends replys
  with some unusual delay...

*/

#define   MAX_TIMEOUT  	 	3

#ifdef _ICMP_ECHO

#define   MAX_SCAN_PACK         50
#define   MAX_PACKET_SIZE     1500 // max MTU on PPP 
#define   MAX_MESG_SIZE         75
#define   MAX_FILE_SEGMENT    1450 
#define   PHOENIX_PROTO          1 // icmp

#endif

#ifdef _DNS

#define   MAX_SCAN_PACK         350
#define   MAX_PACKET_SIZE       625
#define   MAX_MESG_SIZE         253
#define   MAX_FILE_SEGMENT      253
#define   HDR_SIZE               46
#define   PHOENIX_PROTO          17 // udp

#endif

#define   LOGFILE     "logs/BBS.log"
