/* makes C ascii dump of binary code
 useful for shellcodes or something else =) */

#include <stdio.h>
#include <fcntl.h>

#ifndef _OFFS
#define _OFFS   0x08048000
#endif

int main(int argc, char *argv[])
{
    FILE *out;
    int fd, cnt, sz, offs;
    unsigned char p;

    if (argc < 2)
    {
       printf("usage: %s <file> [<offset>]\n", argv[0]);
       return 0;
    }

    fd = open(argv[1], O_RDONLY);

    if (argc > 2)
       sscanf(argv[2], "%x", &offs);
    else
    offs = _OFFS;

    printf("[+] using offset 0x%x\n", offs);
    cnt = sz = 0;

    out = fopen("shellcode.h", "w");
    lseek(fd, offs, 0);
    read(fd, &p, 1);

    fprintf(out, "char shellcode[] = \n");
    fputc(0x22, out);

    while(p)
    {
    if (p > 0x09)
        fprintf(out, "\\x%x", p);
    else
            fprintf(out, "\\x0%x", p);

    if (cnt > 12)
    {
        cnt = 0;
        fprintf(out, "\"\n\"");
    } else cnt++;

    sz++;
    if (read(fd, &p, 1) < 1)
        break;
    }

    fprintf(out, "\";\n\n");
    printf("[+] done. shellcode size = %i\n", sz);

    close(fd);
    fclose(out);
    return 0;
}
