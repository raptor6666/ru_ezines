#include <stdio.h>

int main()
{
    setgid(17);
    
    execl("/bin/sh", "sh", 0);
    
    return 0;
}
