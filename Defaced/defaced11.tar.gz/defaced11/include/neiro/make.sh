#!/bin/sh

rm -f status disasm disasm.h
cat > disasm.h << _EOF
struct	x86_tbl_rec  opcode_lst[] =
{
_EOF
cat disasm.txt >> disasm.h
echo "};" >> disasm.h
echo >> disasm.h
gcc -o disasm disasm.c
