void WINAPI ServiceHandler(DWORD dwCode);
BOOL BeginWork(void);

BOOL log_WriteData(char* szLogMsg);
BOOL log_DeInit(void);
BOOL log_Initialize(void);

SERVICE_STATUS_HANDLE	ssHandle;
SERVICE_STATUS			sStatus;
SOCKET					sock;

int						client_port = 9000;
char*					serviceName = "SysDrv";
