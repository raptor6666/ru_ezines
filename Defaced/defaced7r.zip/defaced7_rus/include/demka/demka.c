/*
    system requirements:
    
    - os linux
    - /dev/fb0 aka framebuffer device
    - /dev/audio aka PCM audio interface
    - 1024 x 768 * 16bit resolution recommended

    how-to kill sound:
    - type in shell "killall -9 demo cat"
        yeah, it's ugly but code better if u need

*/

#define AUDIO_ON

#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <linux/fb.h>
#include <linux/soundcard.h>


int main()
{
  int i, k, pid, fbdev, pic;
  char a[2048];
  void *screen, *pix;
  unsigned long offset, scroffs = 0, scr_size = 0;
  struct fb_var_screeninfo inf;
  struct fb_fix_screeninfo ff0;

#ifdef AUDIO_ON
  pid = fork();
  
  if (pid == 0){ 

    memset(&i, 0xff, sizeof(i));
    pic = open("/dev/mixer", O_RDONLY);
//    ioctl(pic, SOUND_MIXER_WRITE_PCM, &i);
//    ioctl(pic, SOUND_MIXER_WRITE_VOLUME, &i);
    while(1) system("cat zz.au > /dev/audio"); 
    close(pic);
    kill(getppid(), 9);
    exit(1);
  }
#endif

  fbdev = open("/dev/fb0", O_RDWR);

  ioctl(fbdev, FBIOGET_VSCREENINFO, &inf);
  ioctl(fbdev, FBIOGET_FSCREENINFO, &ff0);

  printf("line len: %i\n", ff0.line_length);
  pic = open("dmb.bmp", O_RDONLY);

  scr_size = 2048 * inf.yres;
  printf("screen buffer info: %d x %d * %d\n", inf.xres, inf.yres, 
   inf.bits_per_pixel);


  if ((screen = mmap(0, scr_size, PROT_READ | PROT_WRITE, MAP_SHARED,
  fbdev, 0)) == NULL){
    perror("mmap");
    exit(1);
  }

  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
  memset(screen, 0, scr_size);   // fill screen with black color
  write(fbdev, screen, scr_size);
  
  scroffs = 0;
  write(1,"...feel the digital streams...",32);

  /* move the camera */

  while(1){

  for (k = 0; k < 1500; k++){

    pix = screen + 2048*75;

    for (i = 1; i < 310; i++){
       lseek(pic, -6000*i + scroffs, SEEK_END);
       read(pic, &a, 2048);
       memcpy(pix, &a, 2048);
       memcpy(pix + 2048, &a, 2048);
       pix += 2*2048;
    }

    scroffs+=2;
    if (i%2) sleep(1);
  }

  for (k = 0; k < 1500; k++){

    pix = screen + 2048*75;

    for (i = 1; i < 310; i++){
       lseek(pic, -6000*i + scroffs, SEEK_END);
       read(pic, &a, 2048);
       memcpy(pix, &a, 2048);
       memcpy(pix + 2048, &a, 2048);
       pix += 2*2048;
    }

    scroffs-=2;
    if (i%2) sleep(1);
  }
  
  } // end of loop

  munmap(screen, scr_size);
  close(fbdev);
  close(pic);
  exit(0);
 // not reached
}
