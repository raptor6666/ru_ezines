#!/usr/bin/perl -w
#
# index.htm runner. PoizOn 2005. Special for mazafaka.ru e-zine
#
use strict;

my $path=shift;
my $view=undef;

my $browser=`which mozilla`;
chomp($browser);
if(-e $browser) {
 $view=$browser;
print $view,"\n";
exec("$view file://$path/content/index.html");
exit 0;
}
$browser=`which opera`;
chomp($browser);
if(-e $browser) {
 $view=$browser;
print $view,"\n";
exec("$view file://$path/content/index.html");
exit 0;
}
$browser=`which konqueror`;
chomp($browser);
if(-e $browser) {
 $view=$browser;
print $view,"\n";
exec("$view file://$path/content/index.html");
exit 0;
}
$browser=`which galeon`;
chomp($browser);
if(-e $browser) {
 $view=$browser;
print $view,"\n";
exec("$view file://$path/content/index.html");
exit 0;
}
$browser=`which screem`;
chomp($browser);
if(-e $browser) {
 $view=$browser;
print $view,"\n";
exec("$view file://$path/content/index.html");
exit 0;
}

unless(defined $view) {
system('clear');
print "Not found any browser on you PC\n";
START:
print "Where is your Internet browsing program?[show me full path to program]:";
$browser=<STDIN>;
chomp($browser);
if(-e $browser) {
$view=$browser;} else { goto START; }

exec("$view file://$path/content/index.html");
}
exit 0;


