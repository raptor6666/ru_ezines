#!/usr/bin/perl

#  DEFACED @ ZINE TEST PROJECT
#
#   small IDS for httpd based on perl
#  just idea, not release
#

##### INIT #####
require "conf.pl";

&InitLin;

for($i=0;$i<=60;$i++){ $maskname=$maskname."\x00"; } $0 = $maskname;

##### MAIN #####

while(1){ 

    $msgna=`wc -l $accesslog | awk \x7b' print \$1 '\x7d`;
    $msgne=`wc -l $errorlog | awk \x7b' print \$1 '\x7d`;

chomp $msgna;
chomp $msgne;

$cata = $msgna - $linesa;
$cate = $msgne - $linese;

    if ($cata < 0){ 
	&LookChanges("a");
	&Alert1($accesslog); 
	&InitLin("a");

    } elsif ($cata > 0){ 
	
	&AntiDeface($accesslog);
	
	system("cp $accesslog $accessbak");
	@newdataa = `tail -$cata $accesslog`;
	&Check("a");
	$linesa = $msgna;

    }


    if ($cate < 0){ 
	&LookChanges("e");
        &Alert1($errorlog); 
	&InitLin("e");
    
    } elsif ($cate > 0){ 
    
	&AntiDeface($errorlog);
	
	system("cp $errorlog $errorbak");
	@newdatae = `tail -$cata $accesslog`;
	&Check("e");
	$linese = $msgne;

    }
    
sleep($interval);
}
################################################## SUBS

sub InitLin{
$id = shift(@_);
chomp $id;

if ($id eq "a"){ 

    $linesa = `wc -l $accesslog | awk \x7b' print \$1 '\x7d`;
    chomp $linesa;
    
} elsif ($id eq "e"){

    $linese = `wc -l $errorlog | awk \x7b' print \$1 '\x7d`;
    chomp $linese;
    
} else {

    $chksize = `wc -l ${wwwdir}${checkfile} | awk \x7b' print \$1'\x7d`;

    $linesa = `wc -l $accesslog | awk \x7b' print \$1 '\x7d`;	
    $linese = `wc -l $errorlog | awk \x7b' print \$1 '\x7d`;
    
    chomp $linesa;
    chomp $linese;
}

}

sub Alert1{
$ff = shift(@_);

$subj = $alert[0];

open(MSG1,">alert1");
print MSG1 "Maybe it\'s not important, but size of file \"$ff\" WAS DECREASED! \n";
print MSG1 "\x2d\x2d\x2d\x2d\x2d\n your HTTPD protection system\n\n\n";
print MSG1 "$#changes\n";
print MSG1 @changes;
close(MSG1);

system("cat alert1 | $mailprog $mailto -s $subj; rm -f alert1");
}

sub Alert2{
($ff,$logstr) = @_;

$subj = $alert[1];

open(MSG2,">alert2");
print MSG2 "WARNING! These record in file $ff looks like attack or cgi-scan:\n";
print MSG2 "$logstr\n";
print MSG2 "\n\x2d\x2d\x2d\x2d\x2d\n your HTTPD protection system\n";
close(MSG2);

system("cat alert2 | $mailprog $mailto -s $subj;rm -f alert2")
}

sub Check{
$ff = shift(@_);

if ($ff eq "a"){
    foreach $val ( @keywordz ){
	
	for ($i=0;$i<=$#newdataa;$i++){
	    
	    if ($newdataa[$i] =~ m/$val/i ){ &Alert2($accesslog,$newdataa[$i]);}
	    
	}
    
    }


} elsif ($ff eq "e"){

    foreach $val ( @keywordz ){
	
	for ($i=0;$i<=$#newdatae;$i++){
    
	    if ($newdatae[$i] =~ m/$val/i ){ &Alert2($errorlog,$newdatae[$i]); }
    
	}

    }
    
}

}

sub LookChanges{
$ff = shift(@_);

    if ($ff eq "a"){

	open(BAK,"$accessbak");
	@abak=<BAK>;
	close(BAK);
	
	open(LOG,"$accesslog");
	@alog=<LOG>;
	close(LOG);
	    
	    $l=0;
	    for ($i=0;$i<=$#abak;$i++){
		
		    if ($abak[$i] ne $alog[$i]){
			$changes[$l] = $abak[$i];
			$l++;
			}
		        
	    }
	
    } elsif ($ff eq "e"){
    
	open(BAK,"$errorbak");
	@ebak=<BAK>;
	close(BAK);
	
	open(LOG,"$errorlog");
	@elog=<LOG>;
	close(LOG);

	    $l=0;
	    for ($i=0;$i<=$#ebak;$i++){
	    
		if ($ebak[$i] ne $elog[$i]){
		    $changes[$l]= $ebak[$i];	
		    $l++;
		}
	    
	    }	

    }

}

sub AntiDeface{
$ff = shift(@_);

$newsize = `wc -l ${wwwdir}${checkfile} | awk \x7b' print \$1 '\x7d`;
chomp $newsize;
chomp $chksize;

if ($newsize < ($chksize+7) ){ &Defaced;}

open(TXT,"${wwwdir}${checkfile}");
@html =<TXT>;
close(TXT);

    foreach $val ( @html ){
	
	for ($i=0;$i<=$#defaced;$i++){
	    
	    if ($val =~ m/$defaced[$i]/i ){
		&Defaced;
	    }
	    
	}
    }
}

sub Defaced{

system("mv -fr $cgidir $movecgidir; cp -f $backupdir{$checkfile} ${wwwdir}${checkfile}");

$subj = $alert[2];

open(XAK,">hacked");
print XAK "  SITE WAS DEFACED!!! \n";
print XAK " All cgi scripts was moved to $movecgidir, backup page moved to ${wwwdir}${checkfile} \n\n";
print XAK "Here some system info:\n\n";
close(XAK);

system("ps -auxww >> hacked; w >> hacked; finger >> hacked; netstat -an >> hacked");
system("echo LOGS >> hacked; cat $accessbak >> hacked; cat $errorbak >> hacked");
system("cat hacked | $mailprog $mailto -s $subj; rm -f hacked");


}
