#include <stdio.h>
#include <fcntl.h>

int main()
{
    int fd;
    unsigned char buf[512];

    fd = open("/dev/kmem", O_RDWR);
    
    if (fd < 0)
    {
	perror("open");
	return -1;
    }

    lseek(fd, _OFFSET, 0);
    if (read(fd, &buf, 512) < 0)
    {
	perror("read");
	return -1;
    }
        
    close(fd);
    
    fd = open("./dis", O_WRONLY);
    lseek(fd, 0x74, 0);
    write(fd, &buf, 512);
    close(fd);
    
    return 0;
}

