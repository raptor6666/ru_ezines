#!/bin/bash

path=`pwd`

perl ./content/img/view.pl "${path}"
