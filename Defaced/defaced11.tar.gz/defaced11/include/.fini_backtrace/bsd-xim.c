// defaced staff ware 4 FreeBSD
/* ������� ������� �������� � ������ .fini */

#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

unsigned int offs;
unsigned char sig[] = "@(#) C";

#define BACK2   0x0a

int check_offs(int fd)
{
    unsigned int cnt;
    unsigned char a;

    lseek(fd, -5, 1);

    read(fd, &a, 1);

    for (cnt=0; cnt< 0xf000; cnt++)
    {
    if (a == 0xc3) break;
    lseek(fd, -2, 1);
    read(fd, &a, 1);
    }

    if (a != 0xc3) return 0;
    
    offs -= cnt;
    return 1;
}


int main(int argc, char *argv[])
{
    int i,fd;
    unsigned int bak;
    unsigned char a;

    if (argc < 2)
    {
    printf("usage: %s <file>\n", argv[0]);
    return 0;
    }

    if (argc > 2)
    {
    sscanf(argv[2],"%x", &offs);
    offs -= 0x08048000;
    printf("theory addr = 0x%x\n", offs);
    }

    fd = open(argv[1], O_RDONLY);

    if (fd < 0)
    {
    perror("open");
    return 0;
    }

    i = offs = 0;

    while( read(fd, &a, 1) == 1)
    {
    offs++;

    if (a == sig[i]) i++;
    else i = 0;

    if (i == 6) break;
    }

    if (i == 6)
    if (check_offs(fd)) i = 13;

    offs -= BACK2;

    if (i != 13)
    {
    printf("<.fini> not found\n");
    return 0;
    }

    printf("offset <.fini>: 0x%x\n", offs);
    close(fd);
    return 0;
}
