#
# for d8-05      .ds
#

class GammaCrypt:

      """ Encrypt/decrypt stuff """


      def dectobin(self,decimal):

          """ Decimal -> binary """

          self.binary = []
          while decimal != 0:
                self.binary.append(decimal%2)    
                decimal = decimal/2

          if len(self.binary) < 3:
                while len(self.binary) < 3:
                      self.binary.append(0)

          self.binary.reverse()      
          return self.binary


      def bintodec(self,binary):

          """ Binary -> decimal """

          self.Tmp = ''
          self.decimal = 0
          self.binLen = len(binary)

          while self.binLen > 0:

                self.Tmp += binary[self.binLen-1]
                self.binLen -= 1

          for i in range(0,len(self.Tmp)):
      
                self.decimal += int(self.Tmp[i])*(2**i)

          return self.decimal

    
      def listtostr(self,lst):

          """ List -> string """

          return ''.join([str(x) for x in lst])


      global Payload, TemPayload

      Payload = [1,0,1,0,1]  
      TemPayload = Payload[:]

      
      def gammaRoll(self):

          """ Get s0 value """

          self.toGamma = Payload[0]  

          for i in range(0,len(Payload)-1): TemPayload[i] = TemPayload[i+1]   
          return self.toGamma     


      def gammaAll(self,NotCodedWord):

          """ Get the whole gamma """

          self.Period = 0  
          self.Gamma = []

          while len(self.Gamma) != len(NotCodedWord):
           
                self.first = self.gammaRoll()  

                TemPayload[len(Payload)-1] = (self.first ^ TemPayload[len(Payload)-2])
                self.Period += 1  
                self.Gamma.append(self.first)  
                
          return self.Gamma, self.Period


      def gammaApply(self,Gamma,NotCodedWord):

          """ Applyes gamma to plain message """

          i = 0 
          self.CodedWord = []
                
          while i != len(Gamma):
      
                self.CodedWord.append(int(Gamma[i])^NotCodedWord[i])
                i += 1
 
          return self.CodedWord


if __name__ == '__main__':

      import sys
      import getopt

      (opts,args) = getopt.getopt(sys.argv[1:], 'e:d') 

      for o,a in opts: 
          if o in ['-e']: 
              plain = a 
              gamma = GammaCrypt()
              print '\nPlain text: %(plain)s' % vars()
              tmpg = gamma.dectobin(int(plain))
              print 'Plain text in binary: %s' % gamma.listtostr(tmpg)
              (buhu,vuhu) = gamma.gammaAll(plain)
              buhu = gamma.listtostr(buhu)
              print 'Gamma: %(buhu)s, period: %(vuhu)s' % vars()
              fin = gamma.listtostr(gamma.gammaApply(buhu,tmpg))
              print 'Encrypted text: %(fin)s' % vars()
          if o in ['-d']: 
              crypted = str(a) 
              gamma = GammaCrypt()
              print '\nEncrypted text: %(crypted)s' % vars()
              (buhu,vuhu) = gamma.gammaAll(crypted)
              buhu = gamma.listtostr(buhu)
              print 'Gamma: %(buhu)s, period: %(vuhu)s' % vars()
              fin = gamma.listtostr(gamma.gammaApply(buhu,crypted))
              print 'Plain text in binary: %s' % gamma.listtostr(fin)
              tmpg = gamma.bintodec(fin)
              print '\nPlain text: %(tmpg)s' % vars()
