#!/bin/sh
# for all you stupid jews who run windows, and get the real porn,
# then the coomments (#) will explain this shit to you fools.
#
# clear clears the screen, sleep 1 pauses for 1 second, and echo
# prints the shit to the screen, so the shit in  "" after echo is
# what you see, and sleep 1 and clear make it stop for a second
# then echo all the new shit to the screen!
#
# clear the screen
clear
# echo the shit
echo "O     O"
echo "|/    |>"
echo "|     |"
echo "|     |"
# puase for 1 sec
sleep 1
clear
#
#
# oh shit shes hot...b0n3r!
echo "O     O"
echo "|/    |>"
echo "|-    |"
echo "|     |"
sleep 1
clear
#
# bvvooooooop
#
echo "O     O"
echo "|/    |>"
echo "|--   |"
echo "|     |"
sleep 1
clear
echo " O    O"
echo " |/   |>"
echo " |--  |"
echo " |    |"
sleep 1
clear
#
# girls kick ass
#
echo "  O   O"
echo "  |/  |>"
echo "  |-- |"
echo "  |   |"
sleep 1
clear
#
# girls kick ass
#
echo "   O    O"
echo "   |/  /"
echo "   |--|"
echo "   |  |"
sleep 1
clear
#
# thats right hoe
#
echo "   O "
echo "   |/  ___O OHHHH"
echo "   |--|   \ "
echo "   |  |"
sleep 1
clear
#
# i is j00r daddy
#
echo "    O "
echo "    |/ ___O TAAKKK"
echo "    |-|   \ "
echo "    | | "
sleep 1
clear
#
# mmmhmmm mmmmmhmhmm 
#
echo "   O "
echo "   |/  ___O OOOOOOOHHHHH"
echo "   |--|   \ "
echo "   |  | "
sleep 1
clear
#
# this is niiiiice
#
echo "    O "
echo "    |/ ___O"
echo "    |-|   \ "
echo "    | | "
sleep 1
clear
#
# h0h0
#
echo "   O "
echo "   |/  ___O"
echo "   |--|   \ "
echo "   |  | "
sleep 1
clear
#
# yyyyyaeeeeeeeeeeeeehhhhhhhhhhaaaaaaaaaa
#
echo "    O "
echo "    |/ ___O"
echo "    |-|   \ "
echo "    | | "
sleep 1
clear
#
# ahhhhhhhhhhhhh
#
echo "   O "
echo "   |/  ___O"
echo "   |--|   \ "
echo "   |  | "
sleep 1
clear
#
# oh shit, ORGASM!
#
echo "    O "
echo "    |/ ___O"
echo "    |-|   \ "
echo "    | | "
sleep 1
clear
#
# what a hoe
#
echo "    O "
echo "    |/   ___O so when am i getting paid?"
echo "    |   |   \ "
echo "    |\  | "
sleep 1
clear
#
# fuck her skank ass
#
echo "    O WHAT BITCH!?!?"
echo "    |/   ___O "
echo "    |   |   \ "
echo "    |\  | "
sleep 1
clear
#
# a true ninja doesnt take that shit
#
echo "    O HIYA!"
echo "    |/    _  _542354_O "
echo "    |     EFD|    \ #4"
echo "    |\   | "
sleep 1
clear
#
# heh, you dfucked her, then killed her...is that a form of rape?
#
echo "    O  DIE BITCH!"
echo "    |/  "
echo "    |    "
echo "    |\  O-- -| O.|d "
# the end
#    -tak
#
# <k-rad-bob> tak you nerd
# <tak_> hhehe
# <tak_> what?
# <k-rad-bob> write how you run it
# you stupid jews, type 
# [root@b0g]# chmod +x ./porn
# [root@b0g]# ./porn 