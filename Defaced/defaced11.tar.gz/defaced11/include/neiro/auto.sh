#!/bin/sh

DPROG="./test" 		 # prog to disassemble
OFFS="0x8048330"                 # offset to code section 

IS_LIB=0     # is a shared library? comment 2 disable

echo $DPROG > ./file
echo $IS_LIB >> ./file

if [ -e "./disasm.txt" ];
then
    echo learning current neuro-net
else
    touch disasm.txt
fi;

while true
do
    ./make.sh

    if [ $IS_LIB != 0 ]
    then
	./disasm $DPROG $OFFS $IS_LIB > status
    else
	./disasm $DPROG $OFFS > status
    fi;
    
    ./check.pl $DPROG
    
    if [ -e "./complete" ];
    then
	echo "scan is done"
	exit;
    fi;
done


