  n4=(document.layers);
  n6=(document.getElementById&&!document.all);
  ie=(document.all);
  n=(n6)?15:20;
  d=(n4||ie)?'document.':'document.getElementById("';
  a=(n4||n6)?'':'all.';
  r=(n6)?'")':'';
  s=(n4)?'':'.style';
  for (i=0; i < n; i++)
  {
    if (ie||n6) document.write('<div id="stars'+i+'" style="position:absolute;width:1px;height:1px;background:#000000;font-size:1px"></div>');
    if (n4) document.write("<layer name='stars"+i+"' top=0 left=0 bgcolor=#000000 width=1 height=1></layer>");
  }
  var h,w,cy,cx;
  function screenxy()
  {
    h=(ie)?document.body.clientHeight:window.innerHeight;
    w=(ie)?document.body.clientWidth:window.innerWidth;
    cy=Math.floor((h/2));
    cx=Math.floor((w/2));
  }
  screenxy();
  window.onresize=screenxy;
  y=new Array();
  x=new Array();
  iy=new Array();
  ix=new Array();
  dir=new Array();
  v=new Array();
  vr=new Array();
  ds=new Array();
  ex=new Array();
  c=new Array();
  pos=new Array();
  hex=new Array('#000000','#111111','#222222','#333333','#444444','#555555','#666666','#777777','#888888','#999999','#aaaaaa','#bbbbbb','#cccccc','#dddddd','#eeeeee','#ffffff')
  for (i=0; i < n; i++)
  {
    iy[i]=Math.random()*h;
    ix[i]=Math.random()*w; 
    y[i]=iy[i];
    x[i]=ix[i];
    v[i]=0.3;
    vr[i]=v[i];
    ex[i]=0;
    pos[i]=0;
    c[i]=false;
  }
  function fly()
  {
    sy=(ie)?document.body.scrollTop:window.pageYOffset;
    sx=(ie)?document.body.scrollLeft:window.pageXOffset;
    for (i=0; i < n; i++)
    {
      var divs=eval(d+a+"stars"+i+r+s);
      ay=y[i]-cy;
      ax=x[i]-cx;
      dir[i]=Math.atan2(ay,ax)*180/Math.PI;
      dx=cy-y[i];
      dy=cx-x[i];
      ds[i]=Math.sqrt(dy*dy+dx*dx);
      v[i]+=ex[i];
      if (ds[i] >= h/4) ex[i]+=0.02;
      if ((ds[i] >= h/20) && (ds[i] < h/4)) ex[i]+=0.04;
      if (ds[i] <= h/20) c[i]=true;
      if (c[i])
      {
        if (pos[i] < hex.length-1) pos[i]++;
        (!n4)?divs.background=hex[pos[i]]:divs.bgColor=hex[pos[i]];
        if (pos[i] == hex.length-1) ex[i]+=0.5;
      }
      if (!c[i])
      {
        if (v[i] > 1 && v[i] < 2) (!n4)?divs.background='#333333':divs.bgColor='#333333';
        else if (v[i] >= 2 && v[i] < 3) (!n4)?divs.background='#555555':divs.bgColor='#555555';
        else if (v[i] >= 3 && v[i] < 4) (!n4)?divs.background='#888888':divs.bgColor='#888888';
        else if (v[i] >= 4 && v[i] < 5) (!n4)?divs.background='#aaaaaa':divs.bgColor='#aaaaaa';
        else if (v[i] >= 5 && v[i] < 6) (!n4)?divs.background='#cccccc':divs.bgColor='#cccccc';
        else if (v[i] >= 6 && v[i] < 7) (!n4)?divs.background='#dddddd':divs.bgColor='#dddddd';
        else if (v[i] >= 7 && v[i] < 10) (!n4)?divs.background='#ffffff':divs.bgColor='#ffffff';
      }
      if (v[i] > 13)
      {
        if (!n4){divs.fontSize=2;divs.height=2;divs.width=2;}
        else{divs.clip.height=2;divs.clip.width=2;}
      }
      if (v[i] > 30)
      {
        if (!n4){divs.fontSize=3;divs.height=3;divs.width=3}
        else{divs.clip.height=3;divs.clip.width=3}
      }
      y[i]+=v[i]*Math.sin(dir[i]*Math.PI/180);
      x[i]+=v[i]*Math.cos(dir[i]*Math.PI/180);
      if (y[i] < 0 || y[i] > h-v[i] || x[i] < 0 || x[i] > w-v[i])
      {
        iy[i]=(h/2-cy/2)+Math.random()*cy;
        ix[i]=(w/2-cx/2)+Math.random()*cx;
        y[i]=iy[i];
        x[i]=ix[i];
        v[i]=(ds[i] < 20)?0:0.03;
        ex[i]=0.05;
        pos[i]=0;
        c[i]=false;
        if (!n4) {divs.background='#000000';divs.fontSize=1;divs.height=1;divs.width=1} 
        else{divs.bgColor='#000000';divs.clip.height=1;divs.clip.width=1;}
      }
      divs.top=y[i]+sy;
      divs.left=x[i]+sx;
    }
    setTimeout('fly()',10);
  }
