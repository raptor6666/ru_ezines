BOOL log_WriteData(char* szLogMsg);
BOOL log_DeInit(void);

HANDLE hLogFile;
